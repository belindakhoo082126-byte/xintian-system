# Independent staff login: implementation checkpoint

This checkpoint replaces the ERP staff login only. It is not a deployable completion of the full Manus-removal project.

## Behavior

- `/login` is a public staff login page. `/api/auth/login` accepts same-origin JSON requests.
- Accounts reside in MySQL `staff_credentials`, linked to the existing `users` table. Roles retain the existing `admin` / `user` model; granular employee permissions are not implemented here.
- Passwords use salted Node scrypt hashes. Provisioning requires at least 12 characters.
- Sessions use random 256-bit opaque cookies; only SHA256 token hashes are stored in MySQL. Sessions expire after eight hours. Logout deletes the current session; password reset deletes that account's sessions.
- Cookie: `xintian_erp_session`, host-only, HttpOnly, SameSite=Lax and Secure in production. This separates ERP sessions from the existing membership system cookie.
- Login attempts are limited in-process to ten per IP per 15 minutes. The deployment must configure trusted proxy handling and may add edge rate limiting; multiple ERP workers would require a shared limiter.
- No public registration, default password, Manus OAuth callback, preview bearer authentication or runtime plugin remains in this login flow.
- Existing Manus users are not automatically promoted or mapped to staff accounts. The owner provisions local accounts explicitly.

## Not yet authorized for production use

1. Verify the full 0000..0051 initialization sequence on empty MySQL, then apply `drizzle/migrations/0052_local_staff_auth.sql` once.
2. Test provisioning, login, disabled accounts, expiry, logout and password reset against a real database.
3. Test login in a browser behind the final HTTPS reverse proxy. Only the intended proxy may supply trusted forwarding headers.
4. Complete Forge storage replacement and protect upload/download access. Existing file routes have not been made independent or audited in this checkpoint.
5. Replace optional Manus AI, notification, scheduling and other adapters; remove remaining environment references.
6. Correct the missing PDF font environment asset; do not skip the test.

## Provisioning interface (for later deployment)

`corepack pnpm staff:provision` reads `ERP_STAFF_USERNAME`, `ERP_STAFF_PASSWORD`, `ERP_STAFF_ROLE` (`admin` or `user`) and optional `ERP_STAFF_NAME` from the process environment. It creates an account or resets its password and role. Input must be provided using a secure interactive deployment procedure, not pasted passwords, shell command arguments, source files, or committed environment files. Requires the initialized ERP database and migration 0052. No account was created during development.

## Verification

- Frozen offline dependency install: passed after removing the Manus runtime dependency and updating its lock entries.
- TypeScript: passed.
- Production build: passed with existing large chunk warnings.
- Tests: 227 total; 226 passed, one existing PDF-font test failed because `/usr/share/fonts/opentype/noto/NotoSansCJKsc-Light.otf` is unavailable. Five new tests cover password hashing/verification, username validation, rejecting legacy/preview tokens, HTTP origin/content type and attempt limits.
- No live membership, Bot, image studio, Facebook or logistics service was modified.

The original version2 archives remain intact in the repository root. Changes exist locally until explicitly synchronized to the remote repository; this checkpoint does not imply a GitHub push or deployment.

## Local storage integration checkpoint

The generic employee upload endpoint now requires a staff session. Customer uploads use `/api/receipts/upload`, which verifies the secure order token or the legacy exact order-number/phone combination and checks order status before saving. Customer files are private, bound to an order ID, and checked again during payment submission. The legacy phone flow is retained for compatibility; replacing it with secure tokens remains a hardening task.

Public product images and authorized staff uploads use `/api/files/:id`. Financial and packing pages explicitly select private storage; PDF uploads are always private. Reads of private files require a staff session or a valid secure token for the matching order. Customer order page receipt links carry their existing order token. Staff-uploaded documents without an order binding are staff-only; customer viewing of such historical attachments and packing evidence still needs end-to-end verification and explicit order binding.

`ERP_STORAGE_DIR` selects the file directory (deployment should set an absolute path outside the source release). Default development path is `./data/files`, ignored by git. Back up this directory together with the ERP database. No backup process has been installed on the user's host yet.

`server/storage.ts` now writes locally, with private visibility by default; generated image outputs are explicitly public and Messenger payment proofs are explicitly private/order-bound. The Forge storage proxy is removed. Old `/manus-storage/*` requests return 410 and do not call Manus. Original remote assets are not silently copied or considered migrated. PDF font loading and other Manus adapters are still pending.

Upload checks include a size cap, base64 canonicalization, allowed MIME signatures, same-origin JSON, and an in-process per-IP attempt limiter. Download responses use no-store, nosniff, no-referrer and a sandbox CSP. These are not a malware scanner or a deployment capacity guarantee. Production ingress body limits, log redaction for order tokens, disk monitoring and orphan upload cleanup remain deployment tasks.

Verification: TypeScript and production build passed. Full suite: 235 tests, 234 passed; the same missing Chinese PDF-font test failed. Four new HTTP tests cover anonymous/cross-origin upload rejection, public versus private reads, customer order binding, cross-order download denial, disguised active content rejection and legacy route retirement. Tests use injected order/staff fixtures, not live MySQL. No live services were changed and this checkpoint has not been pushed to GitHub.

## PDF font checkpoint

The Noto CJK Light font and OFL license are now bundled under assets/fonts. Production and tests use the same local font loader; ERP_PDF_FONT_PATH can select another absolute local font path. No Manus font URL or system-specific test font path is needed. The PDF resource-origin allowlist now uses ERP_PUBLIC_URL (plus local development hosts), replacing Manus domain suffixes. Deployment must copy the font assets and set the correct working directory.

After the font replacement: all 235 tests passed, TypeScript passed and production build passed (existing chunk-size warning). This does not verify browser visual layout, real MySQL or external services. Remaining Forge adapters include LLM, image generation, transcription, maps, notifications, heartbeat and data API; these are not yet replaced.

## Independent service adapter checkpoint

LLM calls now require explicit LLM_BASE_URL, LLM_API_KEY and a selected model (or LLM_MODEL). The base URL includes the provider API version; chat/completions and models are resolved beneath it. No default provider or legacy Forge configuration is used. Only HTTPS without embedded credentials/query/hash is accepted, and known Manus/Forge hosts are rejected. This is an OpenAI-compatible adapter, not a tested native Gemini connection. No external key or live call was used.

The old image generation, transcription, owner-notification, heartbeat scheduling, data API and maps adapters were replaced with typed, explicit PRECONDITION_FAILED errors. No corresponding request is sent and no success is reported. Frontend maps display an unconfigured status instead of injecting a Forge script. These capabilities still need independent implementations/integration; they have not been delivered by disabling the old adapters. Core database-backed notifications are distinct from the disabled external owner notification.

Legacy image paths still occur in mall backgrounds, logos, payment instructions and database defaults. They now return 410 locally, and must be migrated or replaced before release; do not fabricate bank/QR details. Removing executable Forge calls does not prove that the full UI or business workflow is ready. Next work remains asset handling, import-order disabling, database migration verification and real integration tests.

Service-adapter validation: all 238 tests passed and production build passed. The initial type check caught a missing Google Maps type reference in the disabled UI component; the reference was restored and the final TypeScript check passed.

## Import sales retirement checkpoint

The daily navigation no longer shows import orders or CN/IB procurement. Direct import list/create/procurement pages show a disabled notice. Product and live-room creation selectors no longer offer import modes. Database tables, historical read helpers and the original source archives are retained; no customer data or historical record was deleted. Dormant legacy import code remains for compatibility and is not a claim that future restoration requires no testing.

A common RPC middleware rejects importBatches/importPreorder mutations and explicit import category/sales-mode/live-type inputs. Service functions independently reject new import products, live rooms and orders, import eligibility, XTC/XTD sequence creation, import procurement writes, and splitting an import source order. The switch is fixed off in this branch; there is no environment variable to accidentally re-enable it. Existing tests for historical number parsing remain valid.

The policy does not make all historical order actions read-only: ordinary shared payment/history functions still exist. Actual order, inventory and customer flows need empty-MySQL/browser verification before release.

Import-policy checkpoint validation: all 242 tests passed and final TypeScript check passed. No live database or host deployment has been performed. A local `manus-v2-original-archive` tag points at the original archive-only repository commit; neither the tag nor working branch has been pushed.

## Brand and payment asset checkpoint

Customer payment pages now read each payment method's configured QR image, bank name, account number, account holder and instructions. Missing values show an unconfigured status; copy controls for missing account details are disabled. Old fixed QR images and hardcoded bank details were removed from these pages. Logo rendering uses the configured company logo or an explicitly labelled bundled placeholder. Order export/preview use the same setting. Mall artwork uses existing theme colors/patterns instead of retired Manus background URLs.

Asset URL filtering rejects known Manus hosts, retired storage paths, protocol-relative URLs, embedded credentials and non-HTTPS external URLs. This is display filtering, not an asset migration: existing database images still require inventory and re-upload, and arbitrary external HTTPS assets are not guaranteed durable. No real customer/payment data was changed. Browser visual verification and real MySQL workflows remain pending.

Validation: TypeScript check passed; all 248 tests passed; production build passed with the existing bundle-size warning. This is a local branch checkpoint, not a GitHub push or host deployment.

## Listener and realtime access checkpoint

ERP now defaults to the explicit loopback listener 127.0.0.1:8003. Invalid ports or public bind addresses are rejected; startup fails if the configured port is occupied instead of silently moving to another port. Public access must use the existing reverse proxy. Host startup behavior still needs deployment verification.

The realtime sync route now authenticates staff before opening an SSE stream and returns 401 for anonymous requests or 503 when authentication is unavailable. Streams close after 60 seconds so browser reconnects recheck expired/revoked sessions; revocation is not instantaneous for an already open stream (up to 60 seconds). Response close removes the stream and its expiry timer. Real MySQL-backed login and browser reconnection remain unverified.

Six new tests cover listener validation and realtime authentication/cleanup. All 259 tests, TypeScript check and production build passed (existing bundle-size warning). No host services, database or GitHub remote were modified.
