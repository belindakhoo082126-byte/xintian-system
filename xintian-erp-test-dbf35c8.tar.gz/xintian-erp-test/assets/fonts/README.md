# Bundled PDF font

NotoSansCJKsc-Light.otf from the Noto CJK project, distributed unmodified under the accompanying SIL Open Font License 1.1.

Source: https://github.com/notofonts/noto-cjk/tree/main/Sans/OTF/SimplifiedChinese
License source: https://github.com/notofonts/noto-cjk/blob/main/Sans/LICENSE

The ERP reads the bundled font from its project working directory. Deployment must retain assets/fonts beside the release and set WorkingDirectory to the release root, or set ERP_PDF_FONT_PATH to an absolute local font path. No runtime font download is performed. Include OFL.txt whenever redistributing this font.
