import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/OrderEditPage.tsx"), "utf8");
const detailService = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");

describe("OrderEditPage repotting flowerpot synchronization", () => {
  it("uses the same shared flowerpot classifier for order plants and order flowerpots", () => {
    expect(source).toContain('import { isRepotPotItem } from "@shared/repotPotCategories"')
    expect(source).toContain('!isRepotPotItem(item) && (item.productType || "physical") === "physical"')
    expect(source).toContain('isRepotPotItem(item) && (item.productType || "physical") === "physical"')
  })

  it("returns product isPot and actual Chinese category names through order detail items", () => {
    expect(detailService).toContain("isPot: products.isPot")
    expect(detailService).toContain("categoryNameZh: categories.nameZh")
    expect(detailService).toContain(".leftJoin(categories, eq(products.categoryId, categories.id))")
  })

  it("uses the current Edit item draft for repotting and opens the same variant picker as manual orders", () => {
    expect(source).toContain("return hasItemChanges ? editItems : ((order as any).items || [])")
    expect(source).toContain("const [variantSelectionProduct, setVariantSelectionProduct]")
    expect(source).toContain("function handleProductSelection(product: any)")
    expect(source).toContain("选择商品规格")
    expect(source).toContain("resolveManualOrderVariantPrice")
    expect(source).toContain("resolveOrderItemUnitWeight({ productType: product.type, variantWeight: variant?.weight, productWeight: product.weightKg })")
    expect(source).toContain("[product.variants, product.variations, product.productVariations]")
    expect(source).toContain('setVariantSelectionProduct({ ...product, variants: resolvedVariants })')
    expect(source).toContain('选择规格（${variantCount}）')
    expect(source).toContain('originalUnitPrice: item.originalUnitPrice ? String(item.originalUnitPrice) : null')
    expect(source).toContain('const loadedOrderIdRef = useRef<number | null>(null)')
    expect(source).toContain('if (order && loadedOrderIdRef.current !== (order as any).id)')
    expect(source).toContain('loadedOrderIdRef.current = o.id')
    expect(source).toContain('const itemDraftDiffersFromOrder = useMemo')
    expect(source).toContain('const hasItemChanges = itemsModified || itemDraftDiffersFromOrder')
    expect(source).toContain('if (hasItemChanges)')
    expect(source).toContain('const [isSavingOrder, setIsSavingOrder] = useState(false)')
    expect(source).toContain('await updateDetailsMutation.mutateAsync({')
    expect(source).toContain('disabled={isSavingOrder || updateItemsMutation.isPending || updateDetailsMutation.isPending}')
  })

  it("keeps long plant and flowerpot names readable in the expanded repotting remark dialog", () => {
    expect(source).toContain('width: "min(94vw, 980px)", maxWidth: "980px"')
    expect(source).toContain('sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_5rem_2rem]')
    expect(source).toContain('[&>span]:whitespace-normal [&>span]:break-words')
    expect(source).toContain('className="h-auto whitespace-normal break-words py-2 leading-5"')
    expect(source).toContain('sm:min-w-[28rem]')
    expect(source).toContain('grid-cols-[minmax(0,1fr)_2.5rem]')
    expect(source).toContain('min-h-12 w-full items-start py-2')
    expect(source).toContain('h-10 w-10 sm:h-8 sm:w-8')
  })

  it("treats legacy order items with an empty product type as physical so saved flowerpot categories remain selectable", () => {
    expect(source).toContain('(item.productType || "physical") === "physical"')
    expect(source).toContain('isRepotPotItem(item)')
  })
})
