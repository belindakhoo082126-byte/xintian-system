import { useState, type FormEvent } from "react";

export default function StaffLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/auth/login", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username, password }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "登录失败");
      setPassword(""); window.location.replace("/");
    } catch (error) { setError(error instanceof Error ? error.message : "连接失败，请稍后再试"); }
    finally { setBusy(false); }
  }
  return <main className="min-h-screen bg-stone-50 flex items-center justify-center p-6">
    <form onSubmit={submit} className="w-full max-w-sm bg-white border rounded-xl p-8 space-y-5 shadow-sm">
      <h1 className="text-2xl font-semibold text-green-900">心田员工登录</h1>
      <label className="block">账号 <span className="text-red-600">*</span><input required autoComplete="username" maxLength={64} value={username} onChange={e => setUsername(e.target.value)} className="mt-2 w-full border rounded p-3" /></label>
      <label className="block">密码 <span className="text-red-600">*</span><input required type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} className="mt-2 w-full border rounded p-3" /></label>
      {error && <p role="alert" className="text-red-700">{error}</p>}
      <button disabled={busy} className="w-full rounded bg-green-900 text-white p-3 disabled:opacity-50">{busy ? "正在登录…" : "登录"}</button>
    </form>
  </main>;
}
