import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("OrderCreatePage 区域四", () => {
  it("保留商品搜索与订单项目编辑，但不再显示右侧添加商品按钮", () => {
    const source = readFileSync(new URL("./OrderCreatePage.tsx", import.meta.url), "utf8");

    expect(source).toContain("区域四：商品搜索与加入订单");
    expect(source).toContain("handleProductSelect(idx, v)");
    expect(source).toContain("updateManualItem(idx, \"quantity\"");
    expect(source).not.toContain("onClick={addManualItem}");
    expect(source).toContain("resolveManualOrderItemPrice");
  });

  it("多规格商品必须先显示规格选择，并在选择后保存规格标识", () => {
    const source = readFileSync(new URL("./OrderCreatePage.tsx", import.meta.url), "utf8");

    expect(source).toContain("setVariantSelectionProduct(p)");
    expect(source).toContain("选择商品规格");
    expect(source).toContain("variationId: variant?.id");
    expect(source).toContain("variationName: variant?.name");
    expect(source).toContain("availableStock: Number(variant?.stockQuantity");
    expect(source).toContain("resolveOrderItemUnitWeight({ productType: product.type, variantWeight: variant?.weight, productWeight: product.weightKg })");
  });

  it("手机端商品卡片以两栏／单栏流程展示完整操作，不再固定压缩为十二栏", () => {
    const source = readFileSync(new URL("./OrderCreatePage.tsx", import.meta.url), "utf8");

    expect(source).toContain('grid grid-cols-2 gap-3 sm:grid-cols-12 sm:gap-2 sm:items-end');
    expect(source).toContain('hidden shrink-0 sm:inline-flex');
    expect(source).toContain('col-span-2 min-w-0 sm:col-span-2');
    expect(source).toContain('h-10 w-full sm:h-9');
  });

  it("特价商品、植物和种植介质均通过共享规则传入RM150免邮门槛", () => {
    const source = readFileSync(new URL("./OrderCreatePage.tsx", import.meta.url), "utf8");

    expect(source).toContain("calculateOrderPriceBreakdown");
    expect(source).toContain("const freeShippingEligibleSubtotal = orderPriceBreakdown.freeShippingEligibleSubtotal;");
    expect(source).toContain("blocksPlantingMediumFreeShippingCheckout");
    expect(source).toContain("categoryNameZh: (product as any).categoryNameZh || null");
    expect(source).toContain("orderTotal: freeShippingEligibleSubtotal");
    expect(source).not.toContain("orderTotal: settledAmount");
  });

  it("植物与种植介质达到免邮门槛时会禁用预览和实际建单", () => {
    const source = readFileSync(new URL("./OrderCreatePage.tsx", import.meta.url), "utf8");

    expect(source).toContain("请取消种植介质或另开订单后再结账");
    expect(source).toContain("disabled={manualItems.length === 0 || hasStockShortage || blocksPlantingMediumFreeShippingCheckout}");
  });

  it("Lalamove摘要引用管理员公司承担金额并保留实际超额补收说明", () => {
    const source = readFileSync(new URL("./OrderCreatePage.tsx", import.meta.url), "utf8");

    expect(source).toContain("shippingConfiguration.lalamove.settlementNote");
    expect(source).toContain("shippingConfiguration.lalamove.companyBearingFee");
    expect(source).toContain("only the actual delivery-fee excess is collected after packing");
  });

  it("换盆备注以正式花盆分类识别区域四商品，并兼容旧isPot标记", () => {
    const source = readFileSync(new URL("./OrderCreatePage.tsx", import.meta.url), "utf8");

    expect(source).toContain('import { isRepotPotItem } from "@shared/repotPotCategories"');
    expect(source).toContain("const section4Pots = section4Items.filter(i => isRepotPotItem(i));");
    expect(source).toContain("isRepotPotItem({ categoryNameZh: product.categoryNameZh })");
  });
});
