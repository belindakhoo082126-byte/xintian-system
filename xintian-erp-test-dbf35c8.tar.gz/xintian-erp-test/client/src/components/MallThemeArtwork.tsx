import type { CSSProperties } from "react";
import type { MallTheme, ResolvedMallTheme } from "@/lib/mallTheme";

type ThemeArtworkProps = { theme: MallTheme | ResolvedMallTheme; active?: boolean };

function themeSurfaceStyle(theme: MallTheme): CSSProperties {
  return {
    backgroundColor: theme.colors.background,
    backgroundImage: theme.visual.pattern,
    borderColor: `${theme.colors.secondary}a8`,
    boxShadow: `0 12px 26px ${theme.colors.primary}18`,
  };
}

export function MallThemePreview({ theme, active = false }: ThemeArtworkProps) {
  return (
    <div className="relative h-32 overflow-hidden rounded-2xl border p-3" style={themeSurfaceStyle(theme)}>
      <div className="absolute inset-x-0 top-0 h-1.5" style={{ background: theme.visual.edge }} />
      <div className="absolute right-3 top-3 flex gap-1 text-lg opacity-70" aria-hidden="true">
        {theme.visual.motifs.slice(0, 3).map((motif, index) => <span key={`${motif}-${index}`}>{motif}</span>)}
      </div>
      <div className="absolute -bottom-4 -left-2 flex h-20 w-20 items-center justify-center rounded-full border-4 border-white/70 bg-white/55 text-4xl shadow-sm" style={{ boxShadow: `inset 0 0 0 1px ${theme.colors.secondary}` }} aria-hidden="true">
        {theme.visual.mascot.glyph}
      </div>
      <div className="absolute bottom-3 left-20 right-3">
        <p className="text-sm font-bold" style={{ color: theme.colors.font }}>主题插画预览</p>
        <p className="mt-0.5 line-clamp-2 text-[11px] leading-4" style={{ color: `${theme.colors.font}b3` }}>{theme.visual.description.zh}</p>
      </div>
      {active && <span className="absolute left-3 top-3 rounded-full px-2 py-0.5 text-[10px] font-semibold text-white" style={{ backgroundColor: theme.colors.primary }}>当前使用</span>}
    </div>
  );
}

export function MallThemeDecorations({ theme }: { theme: ResolvedMallTheme }) {
  if (theme.key === "xintian_nature") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(248,243,233,0.12) 0%, rgba(248,243,233,0.02) 42%, rgba(248,243,233,0.16) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "lavender_purple") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(253,250,255,0.1) 0%, rgba(250,247,255,0.02) 44%, rgba(244,237,255,0.16) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "sakura_pink") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,251,246,0.1) 0%, rgba(255,249,245,0.02) 44%, rgba(255,247,241,0.15) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "nature_green") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(250,252,246,0.1) 0%, rgba(248,251,244,0.02) 44%, rgba(243,248,237,0.16) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "warm_brown") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,250,242,0.1) 0%, rgba(252,246,237,0.02) 44%, rgba(248,238,224,0.17) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "christmas") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,252,244,0.1) 0%, rgba(253,249,239,0.02) 44%, rgba(248,241,225,0.17) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "cny") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,251,239,0.10) 0%, rgba(255,247,229,0.02) 44%, rgba(247,232,204,0.17) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "hari_raya") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,252,242,0.1) 0%, rgba(253,248,233,0.02) 44%, rgba(244,238,214,0.17) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "merdeka") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,252,245,0.1) 0%, rgba(255,249,240,0.02) 44%, rgba(249,241,226,0.17) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "mid_autumn") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,252,245,0.10) 0%, rgba(248,244,232,0.02) 44%, rgba(238,231,211,0.17) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "valentine") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,252,247,0.08) 0%, rgba(255,248,243,0.01) 44%, rgba(246,230,224,0.14) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "mothers_day") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,253,248,0.08) 0%, rgba(255,249,242,0.01) 44%, rgba(238,228,219,0.14) 100%)" }}
        />
      </div>
    );
  }

  if (theme.key === "custom") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: theme.visual.pattern }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(255,253,247,0.08) 0%, rgba(249,249,242,0.01) 44%, rgba(227,235,218,0.13) 100%)" }}
        />
      </div>
    );
  }

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      <div className="absolute -left-10 top-40 flex h-28 w-28 items-center justify-center rounded-full border border-white/70 text-4xl opacity-55" style={{ background: `${theme.secondary}42`, color: theme.primary, boxShadow: `0 16px 38px ${theme.primary}12` }}>{theme.visual.motifs[0]}</div>
      <div className="absolute right-4 top-28 flex items-center gap-1.5 rounded-full border border-white/80 px-3 py-2 text-xl opacity-70 shadow-sm backdrop-blur-sm" style={{ background: `${theme.background}c9`, color: theme.primary, boxShadow: `0 10px 28px ${theme.primary}12` }}>
        {theme.visual.motifs.slice(0, 3).map((motif, index) => <span key={`${motif}-${index}`}>{motif}</span>)}
      </div>
      <div className="absolute -right-8 top-[34rem] flex h-32 w-32 items-center justify-center rounded-full border border-white/70 text-5xl opacity-40" style={{ background: `${theme.secondary}4d`, color: theme.primary }}>{theme.visual.motifs[1]}</div>
      <div className="absolute bottom-44 left-[8%] flex items-center gap-2 text-4xl opacity-30" style={{ color: theme.primary }}><span>{theme.visual.motifs[2]}</span><span>{theme.visual.motifs[0]}</span></div>
    </div>
  );
}
