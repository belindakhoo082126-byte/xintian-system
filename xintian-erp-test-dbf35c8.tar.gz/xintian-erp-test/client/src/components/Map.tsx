/// <reference types="google.maps" />
interface MapViewProps {
  className?: string;
  initialCenter?: google.maps.LatLngLiteral;
  initialZoom?: number;
  onMapReady?: (map: google.maps.Map) => void;
}

export function MapView({ className }: MapViewProps) {
  return <div role="status" className={className}>地图服务尚未配置</div>;
}
