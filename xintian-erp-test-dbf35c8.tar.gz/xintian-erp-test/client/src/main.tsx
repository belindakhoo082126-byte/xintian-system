import { trpc } from "@/lib/trpc";
import { UNAUTHED_ERR_MSG } from '@shared/const';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpLink, TRPCClientError } from "@trpc/client";
import { createRoot } from "react-dom/client";
import superjson from "superjson";
import App from "./App";
import { I18nProvider } from "./contexts/I18nContext";
import { startLogin } from "./const";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Multi-device sync: refetch on window focus so data stays fresh
      // when user switches between phone/tablet/desktop
      refetchOnWindowFocus: true,
      refetchOnReconnect: true,
      // Data is considered stale after 5s — SSE events trigger immediate
      // invalidation, but this ensures freshness even if SSE drops
      staleTime: 5 * 1000,
      // Poll every 30s as a fallback to SSE push notifications
      // This catches changes even if the SSE connection is temporarily down
      refetchInterval: 30 * 1000,
      // Retry failed queries quickly to recover from transient errors
      retry: 2,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 5000),
    },
  },
});

// Cross-tab sync: when one tab mutates data, broadcast to other tabs
// so they invalidate their caches and refetch immediately
if (typeof window !== "undefined" && "BroadcastChannel" in window) {
  const channel = new BroadcastChannel("xintian-sync");
  channel.onmessage = (event) => {
    if (event.data?.type === "invalidate") {
      queryClient.invalidateQueries();
    }
  };

  // Hook into mutation cache to broadcast invalidations
  queryClient.getMutationCache().subscribe((event) => {
    if (event.type === "updated" && event.action.type === "success") {
      channel.postMessage({ type: "invalidate" });
    }
  });
}

const redirectToLoginIfUnauthorized = (error: unknown) => {
  if (!(error instanceof TRPCClientError)) return;
  if (typeof window === "undefined") return;

  const isUnauthorized = error.message === UNAUTHED_ERR_MSG;

  if (!isUnauthorized) return;

  startLogin();
};

queryClient.getQueryCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    const error = event.query.state.error;
    redirectToLoginIfUnauthorized(error);
    console.error("[API Query Error]", error);
  }
});

queryClient.getMutationCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    const error = event.mutation.state.error;
    redirectToLoginIfUnauthorized(error);
    console.error("[API Mutation Error]", error);
  }
});

const trpcClient = trpc.createClient({
  links: [
    // Dashboard starts several independent operational queries together. Keep
    // them as individual RPC requests so one delayed task queue/report query
    // cannot hold the entire batch until the gateway returns an HTML 504 page.
    httpLink({
      url: "/api/trpc",
      transformer: superjson,
      fetch(input, init) {
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
        });
      },
    }),
  ],
});

createRoot(document.getElementById("root")!).render(
  <trpc.Provider client={trpcClient} queryClient={queryClient}>
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <App />
      </I18nProvider>
    </QueryClientProvider>
  </trpc.Provider>
);
