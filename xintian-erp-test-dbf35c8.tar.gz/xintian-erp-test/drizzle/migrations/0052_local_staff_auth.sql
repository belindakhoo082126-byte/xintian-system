-- Apply after the documented 0000..0051 sequence. No existing users are removed.
CREATE TABLE `staff_credentials` (
  `userId` int NOT NULL PRIMARY KEY,
  `username` varchar(64) NOT NULL UNIQUE,
  `passwordHash` varchar(255) NOT NULL,
  `enabled` boolean NOT NULL DEFAULT true,
  FOREIGN KEY (`userId`) REFERENCES `users` (`id`)
);
CREATE TABLE `staff_sessions` (
  `tokenHash` varchar(64) NOT NULL PRIMARY KEY,
  `userId` int NOT NULL,
  `expiresAt` timestamp NOT NULL,
  INDEX `staff_sessions_user_idx` (`userId`),
  INDEX `staff_sessions_expiry_idx` (`expiresAt`),
  FOREIGN KEY (`userId`) REFERENCES `users` (`id`)
);
