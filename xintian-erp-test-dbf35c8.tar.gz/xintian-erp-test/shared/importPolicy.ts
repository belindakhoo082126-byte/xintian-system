import { TRPCError } from "@trpc/server";

export const IMPORT_DISABLED_MESSAGE = "当前心田独立版已关闭代购功能，不能新建代购商品、直播、订单或采购批次";

export function rejectImportInput(input: unknown): void {
  if (!input || typeof input !== "object" || Array.isArray(input)) return;
  const data = input as Record<string, unknown>;
  if (data.orderCategory === "import" || data.salesMode === "import_preorder" || data.liveType === "import_preorder" || data.existingOrderCategory === "import") {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: IMPORT_DISABLED_MESSAGE });
  }
}

export function rejectImportMutation(path: string, input: unknown): void {
  if (/^(importBatches|importPreorder)\./.test(path)) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: IMPORT_DISABLED_MESSAGE });
  }
  rejectImportInput(input);
}

export function rejectImportOrderNumber(prefix: string): void {
  if (["XTC", "XTD"].includes(prefix.toUpperCase())) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: IMPORT_DISABLED_MESSAGE });
  }
}
