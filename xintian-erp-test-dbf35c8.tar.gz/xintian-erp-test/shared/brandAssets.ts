// Neutral local placeholder; upload the actual brand logo in settings.
export const XINTIAN_LOGO_URL = "/assets/brand-placeholder.svg";
export function usableAssetUrl(value?: string | null): string {
  const url = value?.trim() || "";
  if (!url || url.startsWith("/manus-storage/") || url.startsWith("//")) return "";
  if (/^\/(api\/files\/|assets\/)/.test(url)) return url;
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" || parsed.username || parsed.password) return "";
    if (/(^|\.)(manus\.im|manus\.com|manus\.space|manus\.computer|butterfly-effect\.dev)$/.test(parsed.hostname)) return "";
    return url;
  } catch { return ""; }
}
export function getCompanyLogoUrl(settings: { companyLogoUrl?: string | null } | null | undefined) {
  return usableAssetUrl(settings?.companyLogoUrl) || XINTIAN_LOGO_URL;
}
