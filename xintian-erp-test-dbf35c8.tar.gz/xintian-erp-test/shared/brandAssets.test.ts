import { describe, expect, it } from "vitest";
import { getCompanyLogoUrl, usableAssetUrl, XINTIAN_LOGO_URL } from "./brandAssets";

describe("independent brand and payment assets", () => {
  it("uses the locally bundled placeholder until a company logo is configured", () => {
    expect(XINTIAN_LOGO_URL).toBe("/assets/brand-placeholder.svg");
    expect(getCompanyLogoUrl(null)).toBe(XINTIAN_LOGO_URL);
    expect(getCompanyLogoUrl({ companyLogoUrl: "/manus-storage/old-logo.png" })).toBe(XINTIAN_LOGO_URL);
  });
  it("honors owned local uploads and explicitly configured HTTPS assets", () => {
    expect(getCompanyLogoUrl({ companyLogoUrl: " /api/files/own-logo " })).toBe("/api/files/own-logo");
    expect(usableAssetUrl("https://example.com/qr.png")).toBe("https://example.com/qr.png");
  });
  it("does not substitute old cloud payment images or unsafe URLs", () => {
    for (const value of ["/manus-storage/qr.png", "https://forge.manus.im/qr.png", "//example.com/qr.png", "javascript:alert(1)", "https://user:password@example.com/qr.png"]) {
      expect(usableAssetUrl(value)).toBe("");
    }
    expect(usableAssetUrl(undefined)).toBe("");
  });
});
