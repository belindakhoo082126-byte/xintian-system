# Dedicated ERP database initialization

Status: all 20 migration files executed successfully in an isolated MySQL 8.0.46 initialization using --init-file; all 121 expected table files were created. The networked initializer, column/index equivalence and business flows are NOT yet verified. No database on the user's host has been modified.

The schema now declares 121 tables: the original 119 plus staff credentials and sessions. Twenty explicitly ordered SQL files cover their CREATE definitions. This count does not prove column, index or runtime equivalence.

## Safe default

Run `corepack pnpm db:init --plan`. It reads the SQL files in the handover's explicit order, confirms CREATE coverage for schema table names and prints SHA256 hashes. It does not connect to a database. Historical sequence gaps are not filled with invented files; the incomplete Drizzle journal is not used. The old automatic `db:push` command now exits with an explanation instead of generating and applying an unreviewed migration.

## Later application on a dedicated empty database

An operator must first create a separate ERP database and least-privileged account, then configure DATABASE_URL and ERP_DATABASE_NAME in a private environment file. ERP_DATABASE_NAME must exactly match the database in DATABASE_URL. Never use the membership or image-studio database. Connection URL query/hash options are intentionally rejected by this initializer; remote TLS database support requires a reviewed extension before use.

`corepack pnpm db:init --apply` checks that the target contains no tables or views before making any schema changes. It creates `_erp_init_log`, records each file's hash and status, and stops immediately on a SQL failure. It does not drop or empty an existing database, and it does not automatically resume a partial initialization.

MySQL DDL may commit implicitly. A failed migration can leave partial changes; this tool does not promise transactional rollback. Inspect the isolated test database before retrying. Do not delete existing tables to bypass the empty check. Rehearse with a fresh dedicated test database and retain the failed initialization log for diagnosis.

After schema creation, verify schema columns/indexes/defaults, provision a test employee, and test login/logout/expiry/password reset, product creation, stock receipt, normal ordering, payment proof, shipment and refund. No default password is created. A complete business-flow and browser validation is still required before production.

The import-related historical SQL is retained for schema compatibility and original read/history helpers. It does not enable import sales or add development scope for that feature.

## Offline MySQL rehearsal — 2026-10-18

An extracted Ubuntu MySQL 8.0.46 runtime was used only in temporary test directories. Normal server startup could not create a Unix socket in this execution environment, so no application/database connection was available. A fresh `--initialize-insecure --init-file` rehearsal executed the same SQL transformation used by the initializer, in the explicit migration order. This method does not test connection permissions, the migration log, runtime queries, login or order transactions.

The first SQL execution failed on Drizzle's `--> statement-breakpoint` metadata. These markers are not valid MySQL comments; the initializer now removes them before execution while retaining original file hashes for auditing. A second fresh rehearsal using the final helper exited successfully without SQL errors. Its 121 `.ibd` filenames exactly matched the 121 schema table names, with none missing or unexpected. This is table-creation evidence, not a column/index comparison or a production readiness claim.

A regression test covers delimiter removal and preservation of ordinary SQL comments. All 249 tests and the TypeScript check passed. The original SQL source files remain unchanged. Before deployment, still run the actual `db:init --apply` against a dedicated empty database with a restricted ERP account, verify refusal against a nonempty target, and complete authentication and business-flow checks.

## Read-only column audit — 2026-10-18

The offline rehearsal exported `information_schema.COLUMNS` metadata from MySQL. Comparing all 1,788 columns across 121 tables against Drizzle's runtime table definitions found zero differences for column names, SQL types, nullability, primary-key membership and auto-increment. Defaults, secondary/unique indexes, foreign keys, character sets/collations and runtime behavior are outside this check.

`corepack pnpm db:audit --live` performs only a parameterized metadata SELECT against the explicitly named dedicated ERP database. It requires the same DATABASE_URL / ERP_DATABASE_NAME match as initialization and never writes schema or application data. `_erp_init_log` is excluded. This live connection path remains untested in the socket-restricted execution environment.

For offline metadata, `corepack pnpm db:audit --columns /absolute/path/to/columns.tsv` accepts six tab-separated fields without a header: TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_KEY, EXTRA. Preserve empty final fields. A difference or invalid metadata returns a nonzero exit status; no connection credentials are printed. The complete rehearsal metadata passed this command. Four regression cases check exact equivalence, missing/extra columns, structural mismatches and enum case sensitivity. Full suite: 253 passing tests; TypeScript check passed.
