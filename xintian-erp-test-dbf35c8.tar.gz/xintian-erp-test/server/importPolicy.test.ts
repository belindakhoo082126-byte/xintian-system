import { describe, expect, it } from "vitest";
import { rejectImportInput, rejectImportMutation, rejectImportOrderNumber } from "../shared/importPolicy";
import { createProduct, createOrderFromLiveCapture, generateOrderNumber } from "./db";
import { appRouter } from "./routers";

describe("disabled import sales", () => {
  it("permits local sales inputs and regular order prefixes", () => {
    expect(() => rejectImportInput({ salesMode: "normal", orderCategory: "local", liveType: "normal" })).not.toThrow();
    expect(() => rejectImportOrderNumber("XT")).not.toThrow();
    expect(() => rejectImportMutation("orders.create", { orderCategory: "local" })).not.toThrow();
  });
  it("rejects every explicit import mode and import procurement mutation", () => {
    for (const input of [{ orderCategory: "import" }, { salesMode: "import_preorder" }, { liveType: "import_preorder" }]) {
      expect(() => rejectImportInput(input)).toThrow("关闭代购");
    }
    expect(() => rejectImportMutation("importBatches.create", {})).toThrow("关闭代购");
    expect(() => rejectImportMutation("importPreorder.create", {})).toThrow("关闭代购");
    for (const prefix of ["XTD", "XTC"]) expect(() => rejectImportOrderNumber(prefix)).toThrow("关闭代购");
  });
  it("blocks internal new import work before attempting database access", async () => {
    await expect(generateOrderNumber("XTD")).rejects.toThrow("关闭代购");
    await expect(createProduct({ name: "test", orderCategory: "import" } as any)).rejects.toThrow("关闭代购");
    await expect(createOrderFromLiveCapture({ liveType: "import_preorder" } as any)).rejects.toThrow("关闭代购");
  });
  it("enforces the policy through the real RPC middleware", async () => {
    const caller = appRouter.createCaller({ user: null, req: { headers: {} }, res: {} } as any);
    await expect(caller.products.create({ orderCategory: "import" } as any)).rejects.toMatchObject({ code: "PRECONDITION_FAILED" });
  });
});
