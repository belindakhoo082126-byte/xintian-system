import type { Express, Request } from "express";
import { LocalFileStore } from "./localFileStore";
import { authenticateStaff } from "./_core/localAuth";
import { getOrderBySecureToken, queryOrderByNumber } from "./db";
import path from "node:path";

export const fileStore = () => new LocalFileStore(path.resolve(process.env.ERP_STORAGE_DIR || "./data/files"));
export const fileUrl = (id: string) => `/api/files/${id}`;

function decodeUpload(body: any, privateOnly: boolean) {
  const match = typeof body?.file === "string" && body.file.match(/^data:([a-z0-9.+-]+\/[a-z0-9.+-]+);base64,([A-Za-z0-9+/]*={0,2})$/i);
  if (!match || match[2].length > 28 * 1024 * 1024) throw new Error("Invalid file");
  const data = Buffer.from(match[2], "base64");
  if (data.toString("base64") !== match[2]) throw new Error("Invalid encoding");
  const type = match[1].toLowerCase();
  const matchesType =
    (type === "image/png" && data.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) ||
    (type === "image/jpeg" && data[0] === 255 && data[1] === 216 && data[2] === 255) ||
    (type === "image/webp" && data.toString("ascii", 0, 4) === "RIFF" && data.toString("ascii", 8, 12) === "WEBP") ||
    (type === "image/gif" && /^GIF8[79]a$/.test(data.toString("ascii", 0, 6))) ||
    (type === "application/pdf" && data.toString("ascii", 0, 5) === "%PDF-") ||
    (!privateOnly && type === "video/mp4" && data.toString("ascii", 4, 8) === "ftyp");
  if (!matchesType || data.length > (privateOnly ? 10 : 20) * 1024 * 1024) throw new Error("Unsupported file");
  return { data, contentType: type, filename: typeof body.filename === "string" ? body.filename : "upload" };
}

type OrderAccess = { id: number; physicalStatus?: string | null };
type Dependencies = {
  store: LocalFileStore;
  staff: (req: Request) => Promise<unknown>;
  tokenOrder: (number: string, token: string) => Promise<OrderAccess | null | undefined>;
  phoneOrder: (number: string, phone: string) => Promise<OrderAccess | null | undefined>;
};

export function registerFileRoutes(app: Express, dependencies?: Dependencies) {
  const deps = dependencies ?? { store: fileStore(), staff: authenticateStaff, tokenOrder: getOrderBySecureToken, phoneOrder: queryOrderByNumber };
  const attempts = new Map<string, { count: number; expires: number }>();
  const upload = (customer: boolean) => async (req: Request, res: import("express").Response) => {
    const origin = req.get("origin");
    if (!req.is("application/json") || origin !== `${req.protocol}://${req.get("host")}`) {
      res.status(403).json({ error: "请从心田页面上传文件" }); return;
    }
    const now = Date.now(); attempts.forEach((entry, key) => { if (entry.expires <= now) attempts.delete(key); });
    const ip = req.ip || "unknown";
    const entry = attempts.get(ip) || { count: 0, expires: now + 15 * 60 * 1000 };
    if (entry.count >= 60 || (!attempts.has(ip) && attempts.size >= 10000)) { res.status(429).json({ error: "上传过于频繁，请稍后重试" }); return; }
    entry.count++; attempts.set(ip, entry);
    try {
      let orderId: number | undefined;
      if (customer) {
        const { orderNumber, token, contactNumber } = req.body ?? {};
        if (typeof orderNumber !== "string" || orderNumber.length > 50) { res.status(403).json({ error: "订单验证失败" }); return; }
        const order = typeof token === "string" && token.length >= 32 && token.length <= 128
          ? await deps.tokenOrder(orderNumber, token)
          : typeof contactNumber === "string" && contactNumber.length <= 50
            ? await deps.phoneOrder(orderNumber, contactNumber) : null;
        if (!order || !["pending", "partial_payment", "receipt_uploaded"].includes(order.physicalStatus || "")) {
          res.status(403).json({ error: "订单验证失败或当前状态不允许上传" }); return;
        }
        orderId = order.id;
      } else if (!await deps.staff(req)) { res.status(401).json({ error: "请先登录" }); return; }
      let file;
      try { file = decodeUpload(req.body, customer); }
      catch { res.status(400).json({ error: "仅支持有效的JPG、PNG、WebP、GIF、PDF文件；员工可上传MP4。凭证限10MB，其他限20MB" }); return; }
      const visibility = customer || req.body.purpose === "private" || file.contentType === "application/pdf" ? "private" : "public";
      const saved = await deps.store.put(file.data, { ...file, visibility, orderId });
      res.set("Cache-Control", "no-store").json({ key: saved.id, url: fileUrl(saved.id) });
    } catch { res.status(503).json({ error: "文件服务暂不可用，请稍后重试" }); }
  };
  app.post("/api/upload", upload(false));
  app.post("/api/receipts/upload", upload(true));
  app.get("/api/files/:id", async (req, res) => {
    try {
      const stored = await deps.store.read(req.params.id);
      if (stored.metadata.visibility !== "public" && !await deps.staff(req)) {
        const { orderNumber, token } = req.query;
        const order = typeof orderNumber === "string" && orderNumber.length <= 50 && typeof token === "string" && token.length >= 32 && token.length <= 128
          ? await deps.tokenOrder(orderNumber, token) : null;
        if (!order || order.id !== stored.metadata.orderId) { res.status(404).end(); return; }
      }
      res.set({ "Content-Type": stored.metadata.contentType, "X-Content-Type-Options": "nosniff", "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "sandbox; default-src 'none'" });
      res.set("Content-Disposition", `inline; filename*=UTF-8''${encodeURIComponent(stored.metadata.filename)}`);
      res.send(stored.data);
    } catch { res.status(404).end(); }
  });
  // Legacy objects must be migrated explicitly, never fetched from a Manus service.
  app.get("/manus-storage/*", (_req, res) => { res.status(410).send("旧文件尚未迁移"); });
}

export async function assertReceiptBelongsToOrder(url: string, orderId: number) {
  const match = url.match(/^\/api\/files\/([a-f0-9-]{36})$/);
  if (!match) throw new Error("付款凭证必须来自系统上传服务");
  const { metadata } = await fileStore().read(match[1]);
  if (metadata.visibility !== "private" || metadata.orderId !== orderId) throw new Error("付款凭证与订单不匹配");
}
