import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { mkdir, open, realpath, rename, rm } from "node:fs/promises";
import path from "node:path";

export type StoredFile = {
  id: string;
  filename: string;
  contentType: string;
  size: number;
  visibility: "public" | "private";
  createdAt: string;
  orderId?: number;
};

const validId = (id: string) => /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(id);

/** Filesystem only: HTTP callers must authorize access before returning data. */
export class LocalFileStore {
  constructor(private root: string, private maxBytes = 20 * 1024 * 1024) {
    if (!path.isAbsolute(root)) throw new Error("Storage root must be absolute");
  }

  private async directory() {
    await mkdir(this.root, { recursive: true, mode: 0o700 });
    // Deployment controls the root and its parents; reject a symlink root.
    const canonical = await realpath(this.root);
    if (canonical !== path.resolve(this.root)) throw new Error("Storage root must not contain symlinks");
    return canonical;
  }

  async put(data: Buffer, options: { filename: string; contentType: string; visibility?: "public" | "private"; orderId?: number }): Promise<StoredFile> {
    if (!data.length || data.length > this.maxBytes) throw new Error("File size outside allowed range");
    if (!/^[a-z0-9.+-]+\/[a-z0-9.+-]+$/i.test(options.contentType)) throw new Error("Invalid content type");
    const root = await this.directory();
    const id = randomUUID();
    const file: StoredFile = {
      id, filename: path.basename(options.filename.replace(/\\/g, "/")).replace(/[\x00-\x1f\x7f]/g, "").slice(0, 200) || "file",
      contentType: options.contentType, size: data.length,
      orderId: options.orderId, visibility: options.visibility ?? "private", createdAt: new Date().toISOString(),
    };
    const directory = path.join(root, id);
    await mkdir(directory, { mode: 0o700 });
    try {
      const handle = await open(path.join(directory, "data"), "wx", 0o600);
      try { await handle.writeFile(data); await handle.sync(); } finally { await handle.close(); }
      const metadata = await open(path.join(directory, "metadata.tmp"), "wx", 0o600);
      try { await metadata.writeFile(JSON.stringify(file)); await metadata.sync(); } finally { await metadata.close(); }
      await rename(path.join(directory, "metadata.tmp"), path.join(directory, "metadata.json"));
      return file;
    } catch (error) {
      await rm(directory, { recursive: true, force: true }); throw error;
    }
  }

  async read(id: string): Promise<{ metadata: StoredFile; data: Buffer }> {
    if (!validId(id)) throw new Error("Invalid file identifier");
    const root = await this.directory();
    const directory = path.join(root, id);
    if (await realpath(directory) !== directory) throw new Error("Symlink file directory rejected");
    const readRegular = async (name: string, limit: number) => {
      const handle = await open(path.join(directory, name), constants.O_RDONLY | constants.O_NOFOLLOW);
      try {
        const stat = await handle.stat();
        if (!stat.isFile() || stat.size > limit) throw new Error("Invalid stored file");
        return await handle.readFile();
      } finally { await handle.close(); }
    };
    const metadata = JSON.parse((await readRegular("metadata.json", 4096)).toString()) as StoredFile;
    if (metadata.id !== id || !["public", "private"].includes(metadata.visibility)) throw new Error("Invalid file metadata");
    const data = await readRegular("data", this.maxBytes);
    if (data.length !== metadata.size) throw new Error("Stored file size mismatch");
    return { metadata, data };
  }
}
