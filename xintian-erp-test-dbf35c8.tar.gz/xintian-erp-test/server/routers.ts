import { assertReceiptBelongsToOrder } from "./fileRoutes";
import { revokeStaffSession } from "./_core/localAuth";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { parse as parseCookie } from "cookie";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, adminProcedure, protectedProcedure, shippingProcedure, router } from "./_core/trpc";
import { hasRepeatedVariantKeyword } from "../shared/variantDrafts";
import { getCompanyLogoUrl } from "../shared/brandAssets";
import { normalizeNotificationLogChannel } from "../shared/notificationLogChannel";
import { calculateLalamoveActualCustomerBalance, calculateLalamoveCheckoutCustomerShipping, calculateWestMalaysiaShippingBreakdown, LALAMOVE_COMPANY_BEARING } from "../shared/shippingV22";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { eq } from "drizzle-orm";
import { variants } from "../drizzle/schema";
import { sendTelegramJoinFlow, sendMembershipFlow, getUserProfile, sendTextMessage } from "./messenger";
import { retryFailedAiLogDelivery } from "./aiLogRetry";
import { runTest, rerunTest, runRegression } from "./aiTestRunner";
import type { RegressionQuestionInput, BaselineResult } from "./aiTestRunner";
import {
  classifyIntent,
  createDraftOrder,
  approveDraftOrder,
  rejectDraftOrder,
  markDraftOrderInvalid,
  createOrderChangeRequest,
  approveOrderChangeRequest,
  rejectOrderChangeRequest,
  markOrderChangeRequestInvalid,
  generateHandoverSummary,
  queryOrderShipping,
  reserveInventory,
  releaseInventory,
  convertInventory,
} from "./businessAi";
import { draftOrders, orderChangeRequests, reservationRecords, orderPayments, orders } from "../drizzle/schema";
import { and, desc, eq as eqB } from "drizzle-orm";
import * as parceldaily from "./parceldaily";
import * as parcelking from "./parcelking";
import { ParcelKingError } from "./parcelking";
import * as shippingProvider from "./shippingProvider";
import { evaluateMarketingCampaign } from "./marketingEngine";
import { runMarketingAutomationRule } from "./marketingAutomationService";
import { createHeartbeatJob, deleteHeartbeatJob, updateHeartbeatJob } from "./_core/heartbeat";
import { generateCustomerCarePackPdf } from "./carePackPdf";

const PACKING_SHIPPING_ERROR_MESSAGES: Record<string, string> = {
  PACKING_ORDER_NOT_FOUND: "订单不存在或已被删除",
  PACKING_ORDER_NOT_READY_FOR_FULL_SHIPMENT: "订单当前状态不可完整发货",
  PACKING_ORDER_NOT_READY_FOR_PARTIAL_SHIPMENT: "订单当前状态不可部分发货",
  PACKING_PACKAGE_REQUIRED: "请至少添加一个包裹",
  PACKING_ITEM_REQUIRED: "请至少选择一个待发商品",
  PACKING_ITEM_NOT_IN_ORDER: "所选商品不属于此订单",
  PACKING_ITEM_ALREADY_SHIPPED: "所选商品已在其他包裹中发出",
};

function rethrowPackingShippingError(error: unknown): never {
  const message = error instanceof Error ? PACKING_SHIPPING_ERROR_MESSAGES[error.message] : undefined;
  if (message) {
    throw new TRPCError({ code: "BAD_REQUEST", message });
  }
  throw error;
}

/**
 * Auto-notify customer of order status change.
 * Priority: Facebook Messenger → WhatsApp (fallback).
 * Records the notification status in the order.
 */
async function autoNotifyCustomer(orderId: number, message: string, psid?: string, whatsapp?: string): Promise<{ platform: string; status: string; error?: string }> {
  // Try Facebook Messenger first
  if (psid) {
    try {
      await sendTextMessage(psid, message);
      return { platform: "facebook", status: "sent" };
    } catch (fbErr) {
      // Fall through to WhatsApp
    }
  }
  // Try WhatsApp as fallback (placeholder — actual WhatsApp API integration needed)
  if (whatsapp) {
    // WhatsApp sending would go here
    return { platform: "whatsapp", status: "pending", error: "WhatsApp API not yet configured" };
  }
  return { platform: "none", status: "failed", error: "No contact method available" };
}

/**
 * 手动发货与自动发货共用的客户通知审计：物流写入已成功后才执行，
 * 通知渠道失败只记录状态，不得撤销已完成的发货操作。
 */
async function recordManualShipmentNotification(
  orderId: number,
  packages: Array<{ courier: string; trackingNumber?: string }>,
  isPartial = false,
): Promise<void> {
  try {
    const order = await db.getOrderById(orderId);
    if (!order) return;
    const customer = await db.getCustomerById(order.customerId);
    if (!customer) return;

    const trackingNumbers = packages.map((pkg) => pkg.trackingNumber).filter((value): value is string => Boolean(value));
    const couriers = Array.from(new Set(packages.map((pkg) => pkg.courier).filter(Boolean))).join("、") || "物流公司";
    const shippingMessage = `老板娘/老板您好，我们已为您${isPartial ? "部分发货" : "发货"}啦，收到包裹如有问题记得48小时内发图/视频给我们哦，追踪号码：${trackingNumbers.length ? trackingNumbers.join("、") : "请以快递公司更新为准"}，快递公司：${couriers}`;
    const notice = await autoNotifyCustomer(orderId, shippingMessage, customer.messengerId || undefined, customer.phoneNumber || undefined);
    const noticeStatus = notice.status === "sent" ? "sent" : notice.status === "pending" ? "pending" : "failed";
    await db.updateOrderNotificationStatus(orderId, noticeStatus, notice.error || null);
    await db.createNotificationLog({
      orderId,
      customerId: order.customerId,
      type: "shipping_notification",
      channel: normalizeNotificationLogChannel(notice.platform),
      message: shippingMessage,
      status: noticeStatus,
      errorMessage: notice.error || null,
    });
  } catch (error) {
    // 发货已落库；仅记录通知链路自身的意外错误，不能将订单误判为未发货。
    console.error("[Shipping] Failed to record manual shipment notification", error);
  }
}

async function appendOrderCarePackLinkToCheckoutMessage(input: {
  orderId: number;
  message: string;
  baseUrl: string;
  channel: string;
  actorName?: string | null;
}) {
  const settings = await db.getCarePackSettings();
  const ensured = settings.finalizationTrigger === "checkout"
    ? await db.finalizeOrderCarePack(input.orderId, "checkout", input.actorName || null)
    : await db.ensureOrderCarePack(input.orderId, input.actorName || null);
  const careLink = `${input.baseUrl}${db.buildCarePackPath(ensured.token)}`;
  await db.recordCarePackDeliveryEvent({
    carePackId: ensured.pack.id,
    action: "checkout_attached",
    actorType: "system",
    actorName: input.actorName || null,
    channel: input.channel,
    metadata: { linkPath: db.buildCarePackPath(ensured.token) },
  });
  return `${input.message}\n\n商品养护／使用知识包：\n${careLink}`;
}

export const appRouter = router({
  system: systemRouter,

  // ===========================================================================
  // Marketing Center (营销中心)
  // Activities configure entitlement rules only. Actual order application must
  // continue through the existing order and inventory services.
  // ===========================================================================
  marketing: router({
    listCampaigns: adminProcedure.query(async () => db.listMarketingCampaigns()),
    getCampaign: adminProcedure
      .input(z.object({ campaignId: z.number().int().positive() }))
      .query(async ({ input }) => db.getMarketingCampaign(input.campaignId)),
    createCampaign: adminProcedure
      .input(z.object({
        campaignCode: z.string().trim().min(2).max(50),
        name: z.string().trim().min(1).max(255),
        description: z.string().max(5000).nullable().optional(),
        status: z.enum(["draft", "scheduled", "active", "paused", "ended"]).optional(),
        startAt: z.date().nullable().optional(),
        endAt: z.date().nullable().optional(),
        orderCategories: z.array(z.string().min(1).max(50)).max(20).optional(),
        orderSources: z.array(z.string().min(1).max(50)).max(20).optional(),
        customerAudience: z.enum(["all", "member", "non_member", "new_customer", "segment"]).optional(),
        customerSegmentId: z.number().int().positive().nullable().optional(),
        showInMall: z.boolean().optional(),
        allowMemberPriceStack: z.boolean().optional(),
        allowBundlePriceStack: z.boolean().optional(),
        allowCouponStack: z.boolean().optional(),
        allowPointsEarn: z.boolean().optional(),
        perCustomerLimit: z.number().int().positive().nullable().optional(),
        perOrderLimit: z.number().int().positive().nullable().optional(),
        usageLimit: z.number().int().positive().nullable().optional(),
      }))
      .mutation(async ({ ctx, input }) => ({ campaignId: await db.createMarketingCampaign({ ...input, createdBy: ctx.user.openId }) })),
    updateCampaign: adminProcedure
      .input(z.object({
        campaignId: z.number().int().positive(),
        campaignCode: z.string().trim().min(2).max(50).optional(),
        name: z.string().trim().min(1).max(255).optional(),
        description: z.string().max(5000).nullable().optional(),
        status: z.enum(["draft", "scheduled", "active", "paused", "ended"]).optional(),
        startAt: z.date().nullable().optional(),
        endAt: z.date().nullable().optional(),
        orderCategories: z.array(z.string().min(1).max(50)).max(20).optional(),
        orderSources: z.array(z.string().min(1).max(50)).max(20).optional(),
        customerAudience: z.enum(["all", "member", "non_member", "new_customer", "segment"]).optional(),
        customerSegmentId: z.number().int().positive().nullable().optional(),
        showInMall: z.boolean().optional(),
        allowMemberPriceStack: z.boolean().optional(),
        allowBundlePriceStack: z.boolean().optional(),
        allowCouponStack: z.boolean().optional(),
        allowPointsEarn: z.boolean().optional(),
        perCustomerLimit: z.number().int().positive().nullable().optional(),
        perOrderLimit: z.number().int().positive().nullable().optional(),
        usageLimit: z.number().int().positive().nullable().optional(),
      }))
      .mutation(async ({ input }) => {
        const { campaignId, ...patch } = input;
        await db.updateMarketingCampaign(campaignId, patch);
        return { success: true } as const;
      }),
    createRule: adminProcedure
      .input(z.object({
        campaignId: z.number().int().positive(),
        ruleType: z.enum(["quantity_gift", "nth_item_discount", "order_threshold", "spin_eligibility", "add_on", "product_discount", "category_discount", "clearance", "live_lottery", "member_offer"]),
        name: z.string().trim().min(1).max(255),
        description: z.string().max(5000).nullable().optional(),
        status: z.enum(["draft", "active", "paused", "ended"]).optional(),
        priority: z.number().int().min(0).max(10000).optional(),
        stackable: z.boolean().optional(),
        config: z.record(z.string(), z.unknown()),
        usageLimit: z.number().int().positive().nullable().optional(),
        scopes: z.array(z.object({
          scopeType: z.enum(["trigger_product", "eligible_product", "eligible_category", "gift_product", "add_on_product"]),
          productId: z.number().int().positive().nullable().optional(),
          categoryId: z.number().int().positive().nullable().optional(),
          quantity: z.number().int().positive().max(10000).optional(),
        }).refine((scope) => scope.productId != null || scope.categoryId != null, "范围必须选择商品或分类")).max(200).optional(),
      }))
      .mutation(async ({ input }) => ({ ruleId: await db.createMarketingRule(input) })),
    updateRule: adminProcedure
      .input(z.object({
        ruleId: z.number().int().positive(),
        ruleType: z.enum(["quantity_gift", "nth_item_discount", "order_threshold", "spin_eligibility", "add_on", "product_discount", "category_discount", "clearance", "live_lottery", "member_offer"]).optional(),
        name: z.string().trim().min(1).max(255).optional(),
        description: z.string().max(5000).nullable().optional(),
        status: z.enum(["draft", "active", "paused", "ended"]).optional(),
        priority: z.number().int().min(0).max(10000).optional(),
        stackable: z.boolean().optional(),
        config: z.record(z.string(), z.unknown()).optional(),
        usageLimit: z.number().int().positive().nullable().optional(),
        scopes: z.array(z.object({
          scopeType: z.enum(["trigger_product", "eligible_product", "eligible_category", "gift_product", "add_on_product"]),
          productId: z.number().int().positive().nullable().optional(),
          categoryId: z.number().int().positive().nullable().optional(),
          quantity: z.number().int().positive().max(10000).optional(),
        }).refine((scope) => scope.productId != null || scope.categoryId != null, "范围必须选择商品或分类")).max(200).optional(),
      }))
      .mutation(async ({ input }) => {
        const { ruleId, ...patch } = input;
        await db.updateMarketingRule(ruleId, patch);
        return { success: true } as const;
      }),
    deleteRule: adminProcedure
      .input(z.object({ ruleId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await db.deleteMarketingRule(input.ruleId);
        return { success: true } as const;
      }),
    preview: adminProcedure
      .input(z.object({
        campaignId: z.number().int().positive(),
        cart: z.array(z.object({ productId: z.number().int().positive(), categoryId: z.number().int().positive().nullable().optional(), quantity: z.number().int().positive(), unitPrice: z.number().nonnegative(), unitCost: z.number().nonnegative().optional() })).min(1),
        isMemberPriceApplied: z.boolean().optional(),
        isBundlePriceApplied: z.boolean().optional(),
        couponApplied: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        const campaign = await db.getMarketingCampaign(input.campaignId);
        if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "营销活动不存在" });
        return evaluateMarketingCampaign(campaign as any, input.cart, input);
      }),
    mallPreview: publicProcedure
      .input(z.object({
        cart: z.array(z.object({ productId: z.number().int().positive(), categoryId: z.number().int().positive().nullable().optional(), quantity: z.number().int().positive(), unitPrice: z.number().nonnegative(), unitCost: z.number().nonnegative().optional() })).max(100),
        isMemberPriceApplied: z.boolean().optional(),
        isBundlePriceApplied: z.boolean().optional(),
        couponApplied: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        const campaigns = (await db.getActiveMarketingCampaigns())
          .filter((campaign) => campaign.showInMall)
          .map((campaign) => ({
            id: campaign.id,
            name: campaign.name,
            description: campaign.description,
            result: evaluateMarketingCampaign(campaign as any, input.cart, input),
          }))
          .filter((campaign) => campaign.result.eligible);
        return campaigns;
      }),
    listLotteryEntries: adminProcedure
      .input(z.object({ campaignId: z.number().int().positive(), limit: z.number().int().min(1).max(500).optional() }))
      .query(async ({ input }) => db.listMarketingLotteryEntries(input.campaignId, input.limit)),
    createLotteryPrize: adminProcedure
      .input(z.object({
        campaignId: z.number().int().positive(),
        name: z.string().trim().min(1).max(255),
        prizeType: z.enum(["physical_product", "coupon", "points", "membership_days", "free_shipping", "no_prize"]),
        productId: z.number().int().positive().nullable().optional(),
        productQuantity: z.number().int().positive().max(10000).optional(),
        couponCode: z.string().trim().max(100).nullable().optional(),
        pointsValue: z.number().int().min(0).max(1000000).optional(),
        membershipDays: z.number().int().min(0).max(3650).optional(),
        probabilityWeight: z.number().int().min(1).max(1000000).optional(),
        quantityLimit: z.number().int().positive().max(1000000).nullable().optional(),
      }).superRefine((value, context) => {
        if (value.prizeType === "physical_product" && !value.productId) context.addIssue({ code: z.ZodIssueCode.custom, path: ["productId"], message: "实体奖品必须选择商品" });
      }))
      .mutation(async ({ input }) => ({ prizeId: await db.createMarketingLotteryPrize(input) })),
    listAvailableLotteryPrizes: adminProcedure
      .input(z.object({ campaignId: z.number().int().positive() }))
      .query(async ({ input }) => db.listAvailableMarketingLotteryPrizes(input.campaignId)),
    drawLotteryPrize: adminProcedure
      .input(z.object({ entryId: z.number().int().positive() }))
      .mutation(async ({ input }) => db.drawMarketingLotteryPrize(input)),
    claimLotteryPhysicalPrize: adminProcedure
      .input(z.object({ drawId: z.number().int().positive(), orderId: z.number().int().positive(), unitPrice: z.number().nonnegative().optional() }))
      .mutation(async ({ input }) => db.claimMarketingLotteryPhysicalPrize(input)),
    listSegments: adminProcedure.query(async () => db.listMarketingSegments()),
    createSegment: adminProcedure
      .input(z.object({
        name: z.string().trim().min(1).max(255),
        description: z.string().max(5000).nullable().optional(),
        filterConfig: z.record(z.string(), z.unknown()),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => ({ segmentId: await db.createMarketingSegment({ ...input, createdBy: ctx.user.openId }) })),
    updateSegment: adminProcedure
      .input(z.object({
        segmentId: z.number().int().positive(),
        name: z.string().trim().min(1).max(255).optional(),
        description: z.string().max(5000).nullable().optional(),
        filterConfig: z.record(z.string(), z.unknown()).optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { segmentId, ...patch } = input;
        await db.updateMarketingSegment(segmentId, patch);
        return { success: true } as const;
      }),
    listMessageTemplates: adminProcedure.query(async () => db.listMarketingMessageTemplates()),
    createMessageTemplate: adminProcedure
      .input(z.object({
        name: z.string().trim().min(1).max(255),
        channel: z.enum(["messenger", "manual_copy"]).optional(),
        subject: z.string().max(255).nullable().optional(),
        content: z.string().trim().min(1).max(5000),
        buttonLabel: z.string().max(100).nullable().optional(),
        buttonUrl: z.string().url().max(500).nullable().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => ({ templateId: await db.createMarketingMessageTemplate({ ...input, createdBy: ctx.user.openId }) })),
    updateMessageTemplate: adminProcedure
      .input(z.object({
        templateId: z.number().int().positive(),
        name: z.string().trim().min(1).max(255).optional(),
        channel: z.enum(["messenger", "manual_copy"]).optional(),
        subject: z.string().max(255).nullable().optional(),
        content: z.string().trim().min(1).max(5000).optional(),
        buttonLabel: z.string().max(100).nullable().optional(),
        buttonUrl: z.string().url().max(500).nullable().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { templateId, ...patch } = input;
        await db.updateMarketingMessageTemplate(templateId, patch);
        return { success: true } as const;
      }),
    listAutomationRules: adminProcedure.query(async () => db.listMarketingAutomationRules()),
    createAutomationRule: adminProcedure
      .input(z.object({
        campaignId: z.number().int().positive().nullable().optional(),
        name: z.string().trim().min(1).max(255),
        triggerType: z.enum(["segment", "campaign_start", "campaign_ending", "restock", "lottery_eligible", "manual_batch"]),
        segmentId: z.number().int().positive().nullable().optional(),
        templateId: z.number().int().positive(),
        scheduleType: z.enum(["once", "cron", "event"]).optional(),
        scheduledAt: z.date().nullable().optional(),
        filterConfig: z.record(z.string(), z.unknown()).nullable().optional(),
      }))
      .mutation(async ({ ctx, input }) => ({ ruleId: await db.createMarketingAutomationRule({ ...input, createdBy: ctx.user.openId }) })),
    updateAutomationRule: adminProcedure
      .input(z.object({
        ruleId: z.number().int().positive(),
        campaignId: z.number().int().positive().nullable().optional(),
        name: z.string().trim().min(1).max(255).optional(),
        triggerType: z.enum(["segment", "campaign_start", "campaign_ending", "restock", "lottery_eligible", "manual_batch"]).optional(),
        segmentId: z.number().int().positive().nullable().optional(),
        templateId: z.number().int().positive().optional(),
        status: z.enum(["paused", "active", "ended"]).optional(),
        scheduleType: z.enum(["once", "cron", "event"]).optional(),
        scheduledAt: z.date().nullable().optional(),
        filterConfig: z.record(z.string(), z.unknown()).nullable().optional(),
      }))
      .mutation(async ({ input }) => {
        const { ruleId, ...patch } = input;
        await db.updateMarketingAutomationRule(ruleId, patch);
        return { success: true } as const;
      }),
    previewAutomationRun: adminProcedure
      .input(z.object({ ruleId: z.number().int().positive(), customerIds: z.array(z.number().int().positive()).max(500).optional(), limit: z.number().int().min(1).max(500).optional() }))
      .mutation(async ({ input }) => runMarketingAutomationRule({ ...input, dryRun: true })),
    preflightAutomationRule: adminProcedure
      .input(z.object({ ruleId: z.number().int().positive(), customerIds: z.array(z.number().int().positive()).max(500).optional(), limit: z.number().int().min(1).max(500).optional() }))
      .mutation(async ({ input }) => {
        const rule = await db.getMarketingAutomationRuleById(input.ruleId);
        if (!rule) throw new TRPCError({ code: "NOT_FOUND", message: "营销自动规则不存在" });
        const template = await db.getMarketingMessageTemplateById(rule.templateId);
        const contentComplete = Boolean(template?.isActive && template.content.trim());
        const warnings: string[] = [];
        if (!template) warnings.push("找不到关联的营销消息模板，请重新选择模板。");
        else if (!template.isActive) warnings.push("关联消息模板目前未启用，自动发送会被阻止。");
        else if (!template.content.trim()) warnings.push("消息模板没有内容，无法建立发送任务。");

        if (!contentComplete) {
          return {
            ruleId: rule.id,
            canEnable: false,
            targetCustomers: 0,
            automaticMessenger: 0,
            manualFollowUp: 0,
            content: { complete: false, templateName: template?.name ?? null, channel: template?.channel ?? null },
            compliance: { hasAutomaticMessengerWindow: false, requiresManualFollowUp: false },
            warnings,
          };
        }

        const preview = await runMarketingAutomationRule({ ...input, dryRun: true, allowPausedDryRun: true });
        const targetCustomers = preview.queued + preview.manualCopy;
        if (targetCustomers === 0) warnings.push("目前没有符合分群或筛选条件的客户；启用后不会发送任何消息。");
        if (preview.manualCopy > 0) warnings.push(`${preview.manualCopy} 位客户不在 Messenger 24 小时互动窗口内，只会保留人工发送文案。`);
        return {
          ruleId: rule.id,
          canEnable: true,
          targetCustomers,
          automaticMessenger: preview.queued,
          manualFollowUp: preview.manualCopy,
          content: { complete: true, templateName: template?.name ?? null, channel: template?.channel ?? null },
          compliance: { hasAutomaticMessengerWindow: preview.queued > 0, requiresManualFollowUp: preview.manualCopy > 0 },
          warnings,
        };
      }),
    runAutomationNow: adminProcedure
      .input(z.object({ ruleId: z.number().int().positive(), customerIds: z.array(z.number().int().positive()).max(500).optional(), limit: z.number().int().min(1).max(500).optional() }))
      .mutation(async ({ input }) => runMarketingAutomationRule(input)),
    scheduleAutomationRule: adminProcedure
      .input(z.object({
        ruleId: z.number().int().positive(),
        cron: z.string().trim().regex(/^\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+$/, "排程必须使用 6 段 UTC cron 格式"),
        scheduledAt: z.date().nullable().optional(),
        scheduleType: z.enum(["once", "cron"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const rule = await db.getMarketingAutomationRuleById(input.ruleId);
        if (!rule) throw new TRPCError({ code: "NOT_FOUND", message: "营销自动规则不存在" });
        const template = await db.getMarketingMessageTemplateById(rule.templateId);
        if (!template?.isActive || !template.content.trim()) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "启用前检查未通过：关联营销模板不存在、未启用或没有内容" });
        }
        const preflight = await runMarketingAutomationRule({ ruleId: rule.id, dryRun: true, allowPausedDryRun: true, limit: 100 });
        const sessionToken = parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
        const description = `营销自动规则：${rule.name}。仅规则处于启用状态时执行。`;
        const existingFilterConfig = rule.filterConfig && typeof rule.filterConfig === "object" && !Array.isArray(rule.filterConfig) ? rule.filterConfig : {};
        const filterConfig = { ...existingFilterConfig, scheduleCron: input.cron, scheduleTimezone: "UTC" };
        const updateRule = async () => db.updateMarketingAutomationRule(rule.id, {
          status: "active",
          scheduleType: input.scheduleType ?? "cron",
          scheduledAt: input.scheduledAt ?? null,
          filterConfig,
        });
        if (rule.scheduleCronTaskUid) {
          const job = await updateHeartbeatJob(rule.scheduleCronTaskUid, { cron: input.cron, path: "/api/scheduled/marketing-automation", method: "POST", payload: {}, description, enable: true }, sessionToken);
          await updateRule();
          return { taskUid: rule.scheduleCronTaskUid, nextExecutionAt: job.nextExecutionAt ?? null, preflight };
        }
        const job = await createHeartbeatJob({
          name: `marketing-automation-${rule.id}`,
          cron: input.cron,
          path: "/api/scheduled/marketing-automation",
          method: "POST",
          payload: {},
          description,
        }, sessionToken);
        await db.updateMarketingAutomationRule(rule.id, { status: "active", scheduleType: input.scheduleType ?? "cron", scheduledAt: input.scheduledAt ?? null, scheduleCronTaskUid: job.taskUid, filterConfig });
        return { taskUid: job.taskUid, nextExecutionAt: job.nextExecutionAt ?? null, preflight };
      }),
    pauseAutomationRule: adminProcedure
      .input(z.object({ ruleId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const rule = await db.getMarketingAutomationRuleById(input.ruleId);
        if (!rule) throw new TRPCError({ code: "NOT_FOUND", message: "营销自动规则不存在" });
        if (rule.scheduleCronTaskUid) {
          const sessionToken = parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
          await updateHeartbeatJob(rule.scheduleCronTaskUid, { enable: false }, sessionToken);
        }
        await db.updateMarketingAutomationRule(rule.id, { status: "paused" });
        return { success: true } as const;
      }),
    deleteAutomationSchedule: adminProcedure
      .input(z.object({ ruleId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const rule = await db.getMarketingAutomationRuleById(input.ruleId);
        if (!rule) throw new TRPCError({ code: "NOT_FOUND", message: "营销自动规则不存在" });
        if (rule.scheduleCronTaskUid) {
          const sessionToken = parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
          await deleteHeartbeatJob(rule.scheduleCronTaskUid, sessionToken);
        }
        await db.updateMarketingAutomationRule(rule.id, { status: "paused", scheduleCronTaskUid: null });
        return { success: true } as const;
      }),
    effectSummary: adminProcedure.query(async () => db.getMarketingEffectSummary()),
    listMessageDeliveries: adminProcedure
      .input(z.object({ limit: z.number().int().min(1).max(500).optional() }).optional())
      .query(async ({ input }) => db.listMarketingMessageDeliveries(input?.limit || 100)),
    simulateKeywordMatch: adminProcedure
      .input(z.object({ comment: z.string().trim().min(1).max(1000) }))
      .query(async ({ input }) => {
        const keywords = db.parseCommentKeywords(input.comment);
        const { matched, unmatched } = await db.matchKeywordsToProducts(keywords);
        const triggered = matched.length > 0;
        return {
          comment: input.comment,
          keywords,
          matched,
          unmatched,
          triggered,
          preview: {
            publicReply: triggered ? "会进入该直播／帖子既有的公开回复规则；实际回复仍受活动与渠道配置控制。" : "没有匹配商品关键词，不会触发公开回复。",
            privateMessage: triggered ? "会进入既有私聊触发规则；实际自动私聊仍须符合 Messenger 24 小时互动窗口。" : "不会触发私聊。",
            orderAction: triggered ? "会进入既有捉单资格与库存检查；本模拟不会建立订单、预留库存或发送任何消息。" : "不会建立订单。",
          },
        };
      }),
  }),

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      await revokeStaffSession(ctx.req);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    updateLanguage: protectedProcedure
      .input(z.object({ language: z.enum(["zh", "en"]) }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        await db.updateUserLanguage(ctx.user.openId, input.language);
        return { success: true } as const;
      }),
  }),

  // ===========================================================================
  // Products
  // ===========================================================================
  products: router({
    list: adminProcedure
      .input(z.object({
        type: z.enum(["physical", "membership", "gift"]).optional(),
        search: z.string().optional(),
        isListed: z.boolean().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getProducts(input || {});
      }),

    stockMovements: adminProcedure
      .input(z.object({
        productId: z.number(),
        variantId: z.number().optional(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getInventoryMovementLogs({
          productId: input.productId,
          variantId: input.variantId,
          dateFrom: input.dateFrom ? new Date(input.dateFrom) : undefined,
          dateTo: input.dateTo ? new Date(input.dateTo) : undefined,
        });
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await db.getProductById(input.id);
        if (!product) throw new Error("Product not found");
        return product;
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        type: z.enum(["physical", "membership", "gift"]),
        categoryId: z.number().optional(),
        description: z.string().optional(),
        coverImageUrl: z.string().optional(),
        cost: z.string().optional(),
        regularPrice: z.string().optional(),
        memberPrice: z.string().optional(),
        originalPrice: z.string().optional(),
        specialPrice: z.string().optional(),
        weightKg: z.string().optional(),
        stockQuantity: z.number().optional(),
        isPreOrder: z.boolean().optional(),
        isListed: z.boolean().optional(),
        isSpecialItem: z.boolean().optional(),
        allowFreeShipping: z.boolean().optional(),
        categories: z.string().optional(),
        keywords: z.string().optional(),
        videoUrl: z.string().optional(),
        membershipIntro: z.string().optional(),
        telegramFlowLink: z.string().optional(),
        facebookFlowId: z.string().optional(),
        allowStandalonePurchase: z.boolean().optional(),
        allowMixedCheckout: z.boolean().optional(),
        allowImportOrder: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createProduct(input as any);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        type: z.enum(["physical", "membership", "gift"]).optional(),
        categoryId: z.number().optional(),
        description: z.string().optional(),
        coverImageUrl: z.string().optional(),
        cost: z.string().optional(),
        regularPrice: z.string().optional(),
        memberPrice: z.string().optional(),
        originalPrice: z.string().optional(),
        specialPrice: z.string().optional(),
        weightKg: z.string().optional(),
        stockQuantity: z.number().optional(),
        isPreOrder: z.boolean().optional(),
        isListed: z.boolean().optional(),
        isSpecialItem: z.boolean().optional(),
        allowFreeShipping: z.boolean().optional(),
        categories: z.string().optional(),
        keywords: z.string().optional(),
        videoUrl: z.string().optional(),
        membershipIntro: z.string().optional(),
        telegramFlowLink: z.string().optional(),
        facebookFlowId: z.string().optional(),
        allowStandalonePurchase: z.boolean().optional(),
        allowMixedCheckout: z.boolean().optional(),
        allowImportOrder: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateProduct(id, data as any);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProduct(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Product Categories (Legacy - kept for backward compatibility)
  // ===========================================================================
  productCategoriesLegacy: router({
    list: adminProcedure
      .input(z.object({ activeOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getProductCategories(input?.activeOnly);
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        parentId: z.number().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createProductCategory(input as any);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        parentId: z.number().optional(),
        sortOrder: z.number().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateProductCategory(id, data as any);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProductCategory(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Phase 1: Categories (商品分类 - 新版)
  // ===========================================================================
  categories: router({
    list: adminProcedure
      .input(z.object({ activeOnly: z.boolean().optional(), storeOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        if (input?.storeOnly) {
          return await db.getStoreCategories();
        }
        if (input?.activeOnly) {
          return await db.getActiveCategories();
        }
        return await db.getAllCategories();
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const category = await db.getCategoryById(input.id);
        if (!category) throw new Error('分类不存在');
        const productCount = await db.countProductsInCategory(input.id);
        return { ...category, productCount };
      }),

    create: adminProcedure
      .input(z.object({
        nameZh: z.string().min(1),
        nameEn: z.string().min(1),
        descZh: z.string().optional(),
        descEn: z.string().optional(),
        showInStore: z.boolean().optional(),
        sortOrder: z.number().optional(),
        imageUrl: z.string().optional(),
        iconUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createCategory(input);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        nameZh: z.string().optional(),
        nameEn: z.string().optional(),
        descZh: z.string().optional(),
        descEn: z.string().optional(),
        status: z.enum(['active', 'inactive']).optional(),
        showInStore: z.boolean().optional(),
        sortOrder: z.number().optional(),
        imageUrl: z.string().optional(),
        iconUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCategory(id, data);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteCategory(input.id);
      }),

    reorder: adminProcedure
      .input(z.object({ items: z.array(z.object({ id: z.number(), sortOrder: z.number() })) }))
      .mutation(async ({ input }) => {
        await db.reorderCategories(input.items);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Phase 1: Units (销售单位)
  // ===========================================================================
  units: router({
    list: adminProcedure.query(async () => {
      return await db.getAllUnits();
    }),

    create: adminProcedure
      .input(z.object({
        nameZh: z.string().min(1),
        nameEn: z.string().min(1),
        isDefault: z.boolean().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createUnit(input);
      }),
  }),

  // ===========================================================================
  // Phase 1: Products V2 (Admin - 三层 API: Admin / Public / Member Link)
  // ===========================================================================
  productsV2: router({
    // --- Admin API ---
    list: adminProcedure
      .input(z.object({
        search: z.string().optional(),
        categoryId: z.number().optional(),
        status: z.enum(['draft', 'active', 'inactive', 'out_of_stock']).optional(),
        productMode: z.enum(['simple', 'variant']).optional(),
        visibility: z.enum(['public', 'link_only', 'hidden']).optional(),
        type: z.enum(['physical', 'membership', 'gift']).optional(),
        isFeatured: z.boolean().optional(),
        importEligibility: z.enum(['eligible', 'ineligible']).optional(),
        stockFilter: z.enum(['low', 'out', 'anomaly']).optional(),
        stockThreshold: z.number().int().min(1).optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getProductsEnhanced(input || {});
      }),

    orderDetails: adminProcedure
      .input(z.object({
        productId: z.number().int().positive(),
        type: z.enum(['ordered', 'paid', 'completed']),
      }))
      .query(async ({ input }) => {
        return await db.getProductOrderDetails(input.productId, input.type);
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await db.getProductByIdEnhanced(input.id);
        if (!product) throw new Error('商品不存在');
        return product;
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        type: z.enum(['physical', 'membership', 'gift']),
        productMode: z.enum(['simple', 'variant']),
        initialVariants: z.array(z.object({
          name: z.string().min(1),
          keyword: z.string().min(1),
          sellingPrice: z.string().optional(),
          compareAtPrice: z.string().optional(),
          memberPrice: z.string().optional(),
          weight: z.string().optional(),
          status: z.enum(['active', 'inactive', 'hidden']).optional(),
          sortOrder: z.number().optional(),
          imageUrl: z.string().optional(),
        })).optional(),
        categoryId: z.number().optional(),
        unitId: z.number().optional(),
        keyword: z.string().min(1),
        sku: z.string().optional(),
        status: z.enum(['draft', 'active', 'inactive', 'out_of_stock']).optional(),
        visibility: z.enum(['public', 'link_only', 'hidden']).optional(),
        priceVisibility: z.enum(['show', 'hide', 'member_link']).optional(),
        shortDescZh: z.string().optional(),
        shortDescEn: z.string().optional(),
        fullDescZh: z.string().optional(),
        fullDescEn: z.string().optional(),
        careZh: z.string().optional(),
        careEn: z.string().optional(),
        sellingPrice: z.string().optional(),
        compareAtPrice: z.string().optional(),
        memberPrice: z.string().optional(),
        currentCost: z.string().optional(),
        specialPrice: z.string().optional(),
        dimensions: z.any().optional(),
        weightKg: z.string().optional(),
        stockQuantity: z.number().optional(),
        isFeatured: z.boolean().optional(),
        featuredSortOrder: z.number().optional(),
        membershipIntro: z.string().optional(),
        telegramFlowLink: z.string().optional(),
        allowStandalonePurchase: z.boolean().optional(),
        allowMixedCheckout: z.boolean().optional(),
        allowImportOrder: z.boolean().optional(),
        notes: z.string().optional(),
        coverImageUrl: z.string().optional(),
        images: z.string().optional(),
        videoUrl: z.string().optional(),
        description: z.string().optional(),
        isSpecial: z.boolean().optional(),
        allowPresale: z.boolean().optional(),
        allowStandaloneShipping: z.boolean().optional(),
        standaloneShippingMethod: z.enum(['fixed_fee', 'free_shipping']).optional(),
        standaloneShippingFee: z.string().optional(),
        lightDesc: z.string().optional(),
        waterDesc: z.string().optional(),
        fertilizerDesc: z.string().optional(),
        pruningDesc: z.string().optional(),
        syncToMall: z.boolean().optional(),
        mallSortOrder: z.number().optional(),
        isPot: z.boolean().optional(),
        potCapacity: z.string().optional(),
        productImages: z.array(z.string()).optional(),
        // V4: Wholesale & Agent
        wholesalePrice: z.number().optional(),
        agentPrice: z.number().optional(),
        moq: z.number().optional(),
        visibleTo: z.string().optional(),
        specialPriceStartDate: z.string().optional(),
        specialPriceEndDate: z.string().optional(),
        keywordChannels: z.string().optional(),
        aiTags: z.string().optional(),
        aiSellingPoints: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        // Check keyword conflict
        const conflict = await db.checkKeywordConflict(input.keyword);
        if (!conflict.available) {
          throw new Error(`关键词「${input.keyword}」已被商品「${conflict.conflictWith?.name}」使用`);
        }
        if (input.initialVariants && hasRepeatedVariantKeyword(input.initialVariants.map((variant) => variant.keyword))) {
          throw new Error("草稿规格关键词不可重复");
        }
        return await db.createProductEnhanced(input);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        type: z.enum(['physical', 'membership', 'gift']).optional(),
        productMode: z.enum(['simple', 'variant']).optional(),
        categoryId: z.number().optional(),
        unitId: z.number().optional(),
        keyword: z.string().optional(),
        status: z.enum(['draft', 'active', 'inactive', 'out_of_stock']).optional(),
        visibility: z.enum(['public', 'link_only', 'hidden']).optional(),
        priceVisibility: z.enum(['show', 'hide', 'member_link']).optional(),
        shortDescZh: z.string().optional(),
        shortDescEn: z.string().optional(),
        fullDescZh: z.string().optional(),
        fullDescEn: z.string().optional(),
        careZh: z.string().optional(),
        careEn: z.string().optional(),
        sellingPrice: z.string().optional(),
        compareAtPrice: z.string().optional(),
        memberPrice: z.string().optional(),
        currentCost: z.string().optional(),
        specialPrice: z.string().optional(),
        dimensions: z.any().optional(),
        weightKg: z.string().optional(),
        stockQuantity: z.number().optional(),
        allowOversold: z.boolean().optional(),
        isFeatured: z.boolean().optional(),
        featuredSortOrder: z.number().optional(),
        membershipIntro: z.string().optional(),
        telegramFlowLink: z.string().optional(),
        allowStandalonePurchase: z.boolean().optional(),
        allowMixedCheckout: z.boolean().optional(),
        allowImportOrder: z.boolean().optional(),
        notes: z.string().optional(),
        coverImageUrl: z.string().optional(),
        images: z.string().optional(),
        videoUrl: z.string().optional(),
        description: z.string().optional(),
        isSpecial: z.boolean().optional(),
        allowPresale: z.boolean().optional(),
        allowStandaloneShipping: z.boolean().optional(),
        standaloneShippingMethod: z.enum(['fixed_fee', 'free_shipping']).optional(),
        standaloneShippingFee: z.string().optional(),
        lightDesc: z.string().optional(),
        waterDesc: z.string().optional(),
        fertilizerDesc: z.string().optional(),
        pruningDesc: z.string().optional(),
        syncToMall: z.boolean().optional(),
        mallSortOrder: z.number().optional(),
        isPot: z.boolean().optional(),
        potCapacity: z.string().optional(),
        productImages: z.array(z.string()).optional(),
        // V4: Wholesale & Agent
        wholesalePrice: z.number().optional(),
        agentPrice: z.number().optional(),
        moq: z.number().optional(),
        visibleTo: z.string().optional(),
        specialPriceStartDate: z.string().optional(),
        specialPriceEndDate: z.string().optional(),
        keywordChannels: z.string().optional(),
        aiTags: z.string().optional(),
        aiSellingPoints: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        // Check keyword conflict if keyword is being updated
        if (data.keyword) {
          const conflict = await db.checkKeywordConflict(data.keyword, id);
          if (!conflict.available) {
            throw new Error(`关键词「${data.keyword}」已被商品「${conflict.conflictWith?.name}」使用`);
          }
        }
        await db.updateProductEnhanced(id, data);
        return { success: true };
      }),

    setStatus: adminProcedure
      .input(z.object({ id: z.number(), status: z.enum(['draft', 'active', 'inactive', 'out_of_stock']) }))
      .mutation(async ({ input }) => {
        await db.updateProductEnhanced(input.id, { status: input.status });
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteProductEnhanced(input.id);
      }),

    duplicate: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const product = await db.getProductByIdEnhanced(input.id);
        if (!product) throw new Error('商品不存在');
        // Generate new keyword and SKU
        const newKeyword = `${product.keyword}_COPY`;
        const conflict = await db.checkKeywordConflict(newKeyword);
        if (!conflict.available) {
          throw new Error(`复制关键词「${newKeyword}」冲突，请手动修改`);
        }
        const result = await db.createProductEnhanced({
          name: `${product.name} (副本)`,
          type: product.type as any,
          productMode: product.productMode as any,
          categoryId: product.categoryId ?? undefined,
          unitId: product.unitId ?? undefined,
          keyword: newKeyword,
          status: 'draft',
          visibility: product.visibility as any,
          priceVisibility: product.priceVisibility as any,
          shortDescZh: product.shortDescZh ?? undefined,
          shortDescEn: product.shortDescEn ?? undefined,
          fullDescZh: product.fullDescZh ?? undefined,
          fullDescEn: product.fullDescEn ?? undefined,
          careZh: product.careZh ?? undefined,
          careEn: product.careEn ?? undefined,
          sellingPrice: product.sellingPrice ?? undefined,
          compareAtPrice: product.compareAtPrice ?? undefined,
          memberPrice: product.memberPrice ?? undefined,
          currentCost: product.currentCost ?? undefined,
          specialPrice: product.specialPrice ?? undefined,
          dimensions: product.dimensions,
          weightKg: product.weightKg ?? undefined,
          stockQuantity: 0,
          isFeatured: false,
          notes: product.notes ?? undefined,
          coverImageUrl: product.coverImageUrl ?? undefined,
          description: product.description ?? undefined,
        });
        return { id: result.id, sku: result.sku };
      }),

    checkKeyword: adminProcedure
      .input(z.object({ keyword: z.string().min(1), excludeProductId: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.checkKeywordConflict(input.keyword, input.excludeProductId);
      }),

    checkVariantKeyword: adminProcedure
      .input(z.object({ productId: z.number(), keyword: z.string().min(1), excludeVariantId: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.checkVariantKeywordConflict(input.productId, input.keyword, input.excludeVariantId);
      }),

    // --- Public API (价格隔离: 不返回 memberPrice / estimatedCost / currentCost / sku / notes) ---
    publicList: publicProcedure
      .input(z.object({
        categoryId: z.number().optional(),
        search: z.string().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getPublicProducts(input || {});
      }),

    publicGetById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await db.getPublicProductById(input.id);
        if (!product) throw new Error('商品不存在或未上架');
        return product;
      }),

    publicGetByKeyword: publicProcedure
      .input(z.object({ keyword: z.string().min(1) }))
      .query(async ({ input }) => {
        const product = await db.getPublicProductByKeyword(input.keyword);
        if (!product) throw new Error('关键词未匹配到商品');
        return product;
      }),

    // --- Member Link API (Token 验证后返回含 memberPrice) ---
    memberGetByToken: publicProcedure
      .input(z.object({ token: z.string().min(1) }))
      .query(async ({ input }) => {
        const product = await db.getMemberLinkByToken(input.token);
        if (!product) throw new Error('链接无效或已过期');
        return product;
      }),
  }),

  // ===========================================================================
  // Phase 1: Variants (商品规格)
  // ===========================================================================
  variants: router({
    create: adminProcedure
      .input(z.object({
        productId: z.number(),
        name: z.string().min(1),
        keyword: z.string().min(1),
        sku: z.string().optional(),
        sellingPrice: z.string().optional(),
        compareAtPrice: z.string().optional(),
        memberPrice: z.string().optional(),
        estimatedCost: z.string().optional(),
        currentCost: z.string().optional(),
        weight: z.string().optional(),
        dimensions: z.any().optional(),
        status: z.enum(['active', 'inactive', 'hidden']).optional(),
        visibility: z.enum(['public', 'link_only', 'hidden']).optional(),
        sortOrder: z.number().optional(),
        imageUrl: z.string().optional(),
        stockQuantity: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        // Check variant keyword conflict within the same product
        const conflict = await db.checkVariantKeywordConflict(input.productId, input.keyword);
        if (!conflict.available) {
          throw new Error(`规格关键词「${input.keyword}」已被规格「${conflict.conflictWith?.name}」使用`);
        }
        return await db.createVariant(input);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        keyword: z.string().optional(),
        sellingPrice: z.string().optional(),
        compareAtPrice: z.string().optional(),
        memberPrice: z.string().optional(),
        estimatedCost: z.string().optional(),
        currentCost: z.string().optional(),
        weight: z.string().optional(),
        dimensions: z.any().optional(),
        status: z.enum(['active', 'inactive', 'hidden']).optional(),
        visibility: z.enum(['public', 'link_only', 'hidden']).optional(),
        sortOrder: z.number().optional(),
        imageUrl: z.string().optional(),
        stockQuantity: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        // Check keyword conflict if keyword is being updated
        if (data.keyword) {
          // Need productId for conflict check - get the variant first
          const db2 = await db.getDb();
          if (db2) {
            const variantRow = await db2.select().from(variants).where(eq(variants.id, id)).limit(1);
            if (variantRow.length > 0) {
              const conflict = await db.checkVariantKeywordConflict(variantRow[0].productId, data.keyword, id);
              if (!conflict.available) {
                throw new Error(`规格关键词「${data.keyword}」已被规格「${conflict.conflictWith?.name}」使用`);
              }
            }
          }
        }
        await db.updateVariant(id, data);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteVariant(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Phase 1: Member Links (安全会员购买链接)
  // ===========================================================================
  memberLinks: router({
    generate: adminProcedure
      .input(z.object({ productId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.generateMemberLink(input.productId);
      }),

    list: adminProcedure
      .input(z.object({ productId: z.number() }))
      .query(async ({ input }) => {
        return await db.getMemberLinksByProductId(input.productId);
      }),

    deactivate: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deactivateMemberLink(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Phase 1: Product Images (商品图片管理)
  // ===========================================================================
  productImages: router({
    add: adminProcedure
      .input(z.object({
        productId: z.number(),
        url: z.string().min(1),
        fileKey: z.string().min(1),
        sortOrder: z.number().optional(),
        isMain: z.boolean().optional(),
        altText: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.addProductImage(input);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProductImage(input.id);
        return { success: true };
      }),

    updateOrder: adminProcedure
      .input(z.object({ id: z.number(), sortOrder: z.number(), isMain: z.boolean().optional() }))
      .mutation(async ({ input }) => {
        await db.updateProductImageOrder(input.id, input.sortOrder, input.isMain);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Phase 1: Product Videos (商品影片管理)
  // ===========================================================================
  productVideos: router({
    add: adminProcedure
      .input(z.object({
        productId: z.number(),
        url: z.string().min(1),
        fileKey: z.string().min(1),
        sortOrder: z.number().optional(),
        isMain: z.boolean().optional(),
        thumbnailUrl: z.string().optional(),
        duration: z.number().optional(),
        altText: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.addProductVideo(input);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProductVideo(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Phase 1: Product Attributes (商品属性管理)
  // ===========================================================================
  productAttributes: router({
    add: adminProcedure
      .input(z.object({
        productId: z.number(),
        attributeName: z.string().min(1),
        attributeValue: z.string().min(1),
        sortOrder: z.number().optional(),
        isFilterable: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.addProductAttribute(input);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProductAttribute(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Suppliers (进货供应商)
  // ===========================================================================
  suppliers: router({
    list: adminProcedure
      .input(z.object({ activeOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getSuppliers(input?.activeOnly);
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const supplier = await db.getSupplierById(input.id);
        if (!supplier) throw new Error("Supplier not found");
        return supplier;
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        contactPerson: z.string().optional(),
        phoneNumber: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
        bankAccount: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createSupplier(input as any);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        contactPerson: z.string().optional(),
        phoneNumber: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
        bankAccount: z.string().optional(),
        notes: z.string().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateSupplier(id, data as any);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteSupplier(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Purchase Orders (进货单)
  // ===========================================================================
  purchaseOrders: router({
    list: adminProcedure
      .input(z.object({
        supplierId: z.number().optional(),
        status: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getPurchaseOrders(input || {});
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const po = await db.getPurchaseOrderById(input.id);
        if (!po) throw new Error("Purchase order not found");
        const items = await db.getPurchaseOrderItems(input.id);
        return { ...po, items };
      }),

    items: adminProcedure
      .input(z.object({ poId: z.number() }))
      .query(async ({ input }) => {
        return await db.getPurchaseOrderItems(input.poId);
      }),

    selectionOptions: adminProcedure.query(async () => {
      return await db.getPurchaseProductSelectionOptions();
    }),

    create: adminProcedure
      .input(z.object({
        supplierId: z.number(),
        poNumber: z.string().optional(),
        notes: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number().min(1),
          unitCost: z.string(),
          subtotal: z.string(),
          // V2.1: Variant-level purchase support
          variantName: z.string().optional(),
          variantKeyword: z.string().optional(),
          sellingPrice: z.string().optional(),
        })),
      }))
      .mutation(async ({ input }) => {
        return await db.createPurchaseOrder(input);
      }),

    receive: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.receivePurchaseOrder(input.id);
      }),

    lastProductCost: adminProcedure
      .input(z.object({ productId: z.number(), supplierId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLatestSupplierProductCost(input.productId, input.supplierId);
      }),

    quickRestock: adminProcedure
      .input(z.object({
        productId: z.number(),
        supplierId: z.number(),
        quantity: z.number().int().min(1),
        remark: z.string().max(1000).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.quickRestockProduct({
          ...input,
          adjustedBy: ctx.user.name || "admin",
        });
      }),
  }),

  // ===========================================================================
  // Business Reports (经营报告)
  // ===========================================================================
  reports: router({
    // Legacy: monthly profit report
    monthlyProfit: adminProcedure
      .input(z.object({
        year: z.number(),
        month: z.number().min(1).max(12),
      }))
      .query(async ({ input }) => {
        return await db.getMonthlyProfitReport(input.year, input.month);
      }),
    // Business overview: 12 data cards
    overview: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getBusinessOverview(dateRange);
      }),
    // TOP10: Best selling by quantity
    topByQuantity: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getTopProductsByQuantity(dateRange);
      }),
    // TOP10: Best selling by revenue
    topByRevenue: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getTopProductsByRevenue(dateRange);
      }),
    // TOP10: Most profitable products
    topByProfit: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getTopProductsByProfit(dateRange);
      }),
    // TOP10: Top customers by paid amount
    topCustomers: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getTopCustomersBySpending(dateRange);
      }),
    // Sales & Payment sub-report
    salesPayment: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getSalesPaymentReport(dateRange);
      }),
    salesPaymentFinancialSummary: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getSalesPaymentFinancialSummary(dateRange);
      }),
    // Auditable cash ledger: approved receipts and completed refunds by transaction date.
    paymentRecords: adminProcedure
      .input(z.object({
        from: z.coerce.date(),
        to: z.coerce.date(),
        type: z.enum(["all", "payment", "refund"]).optional(),
      }))
      .query(async ({ input }) => {
        return await db.getPaymentRecords(input);
      }),
    // Product Sales sub-report
    productSales: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getProductSalesReport(dateRange);
      }),
    // Customer Spending sub-report
    customerSpending: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getCustomerSpendingReport(dateRange);
      }),
    // Purchase & Inventory sub-report
    purchaseInventory: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getPurchaseInventoryReport(dateRange);
      }),
    // Refund records
    refunds: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getRefundRecords(dateRange);
      }),
    // V2.1: Special price product profit analysis
    specialPriceProfit: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getSpecialPriceProductProfit(dateRange);
      }),
    // V4: Wholesale & Agent report
    wholesaleAgent: adminProcedure
      .input(z.object({
        preset: z.string(),
        customStart: z.string().optional(),
        customEnd: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const dateRange = db.getDateRange(input.preset, input.customStart, input.customEnd);
        return await db.getWholesaleAgentReport(dateRange);
      }),
    // V4: Customer type statistics
    customerTypeStats: adminProcedure
      .query(async () => {
        return await db.getCustomerTypeStats();
      }),
  }),

  // ===========================================================================
  // Refund Management（退款管理）
  // ===========================================================================
  refunds: router({
    list: adminProcedure
      .input(z.object({ status: z.enum(['pending', 'processed', 'awaiting_return', 'rejected', 'cancelled']).optional() }).optional())
      .query(async ({ input }) => db.getRefundManagementRecords(input?.status)),
    searchEligibleOrders: adminProcedure
      .input(z.object({ search: z.string().trim().max(100).optional() }).optional())
      .query(async ({ input }) => db.searchRefundEligibleOrders(input?.search)),
    getOrderDetail: adminProcedure
      .input(z.object({ orderId: z.number().int().positive() }))
      .query(async ({ input }) => db.getRefundOrderDetail(input.orderId)),
    create: adminProcedure
      .input(z.object({
        orderId: z.number().int().positive(),
        requestedAmount: z.number().positive(),
        refundMethod: z.enum(['credit', 'tng_qr', 'duitnow_qr', 'bank_transfer', 'cash', 'other']),
        refundReason: z.string().trim().max(255).optional(),
        refundReasonCode: z.enum(['out_of_stock', 'quality_issue', 'wrong_or_missing_item', 'shipping_damage', 'overcharged_shipping', 'delivery_delay', 'cancelled_item', 'other']).optional(),
        issueDescription: z.string().trim().max(5000).optional(),
        customerRefundDetails: z.string().trim().max(5000).optional(),
        customerRefundQrUrl: z.string().trim().max(500).optional(),
        attachmentUrls: z.string().max(10000).optional(),
        internalNotes: z.string().trim().max(5000).optional(),
        items: z.array(z.object({
          orderItemId: z.number().int().positive().optional(), productId: z.number().int().positive().optional(),
          productName: z.string().trim().min(1).max(255), productSku: z.string().max(100).nullable().optional(),
          refundQuantity: z.number().int().positive(), unitPrice: z.number().min(0), unitCost: z.number().min(0), refundAmount: z.number().min(0),
          inventoryTreatment: z.enum(['return_to_sale', 'write_off', 'none', 'pending_return']),
        })).max(100),
      }))
      .mutation(async ({ ctx, input }) => db.createRefundRequest({ ...input, requestedBy: ctx.user.name || ctx.user.openId })),
    complete: adminProcedure
      .input(z.object({ refundId: z.number().int().positive(), actualAmount: z.number().positive(), receiptUrl: z.string().max(1000).optional() }))
      .mutation(async ({ ctx, input }) => {
        const result = await db.completeRefundRequest({ ...input, processedBy: ctx.user.name || ctx.user.openId });
        // 退款主交易完成后才发送通知；通知失败绝不回滚已完成的退款。
        let detail: Awaited<ReturnType<typeof db.getRefundOrderDetail>> | null = null;
        let message = `您好，您的退款申请已处理完成。\n退款编号：${result.refundNumber}\n实际退款金额：RM${input.actualAmount.toFixed(2)}\n退款方式：${result.refundMethod}\n如有疑问请联系我们，谢谢。`;
        try {
          detail = await db.getRefundOrderDetail(result.orderId);
          const orderNumber = detail?.order?.orderNumber || "-";
          message = `您好，您的订单 ${orderNumber} 退款申请已处理完成。\n退款编号：${result.refundNumber}\n实际退款金额：RM${input.actualAmount.toFixed(2)}\n退款方式：${result.refundMethod}\n如有疑问请联系我们，谢谢。`;
          const notice = await autoNotifyCustomer(
            result.orderId,
            message,
            detail?.customer?.messengerId || undefined,
            detail?.customer?.whatsappPhone || undefined,
          );
          await db.createNotificationLog({
            orderId: result.orderId,
            customerId: detail?.order?.customerId || null,
            type: "refund_complete",
            channel: normalizeNotificationLogChannel(notice.platform),
            message,
            status: notice.status,
            errorMessage: notice.error || null,
          });
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          try {
            await db.createNotificationLog({
              orderId: result.orderId,
              customerId: detail?.order?.customerId || null,
              type: "refund_complete",
              channel: detail?.customer?.whatsappPhone ? "whatsapp" : "messenger",
              message,
              status: "failed",
              errorMessage: `退款完成通知发送失败：${errorMessage}`,
            });
          } catch (logError) {
            console.warn("[Refund] Customer completion notification failure audit could not be recorded:", logError);
          }
          console.warn("[Refund] Customer completion notification failed:", error);
        }
        return result;
      }),
    finalizeReturnItem: adminProcedure
      .input(z.object({ refundItemId: z.number().int().positive(), inventoryTreatment: z.enum(['return_to_sale', 'write_off']) }))
      .mutation(async ({ ctx, input }) => db.finalizeRefundReturnItem({ ...input, processedBy: ctx.user.name || ctx.user.openId })),
    reject: adminProcedure
      .input(z.object({ refundId: z.number().int().positive(), reason: z.string().trim().max(1000).optional() }))
      .mutation(async ({ ctx, input }) => db.rejectRefundRequest({ ...input, processedBy: ctx.user.name || ctx.user.openId })),
    cancel: adminProcedure
      .input(z.object({ refundId: z.number().int().positive(), reason: z.string().trim().max(1000).optional() }))
      .mutation(async ({ ctx, input }) => db.cancelRefundRequest({ ...input, processedBy: ctx.user.name || ctx.user.openId })),
    correctInventoryTreatment: adminProcedure
      .input(z.object({
        refundItemId: z.number().int().positive(),
        inventoryTreatment: z.enum(['return_to_sale', 'write_off']),
        reason: z.string().trim().min(1).max(1000),
      }))
      .mutation(async ({ ctx, input }) => db.correctProcessedRefundInventoryTreatment({ ...input, processedBy: ctx.user.name || ctx.user.openId })),
  }),

  // ===========================================================================
  // Orders
  // ===========================================================================
  orders: router({
    list: adminProcedure
      .input(z.object({
        physicalStatus: z.string().optional(),
        membershipStatus: z.string().optional(),
        orderType: z.string().optional(),
        search: z.string().optional(),
        todayOnly: z.boolean().optional(),
        orderNature: z.string().optional(),
        orderCategory: z.string().optional(),
        isSpecialOrder: z.boolean().optional(),
        specialOrderStatus: z.string().optional(),
        specialOrderType: z.string().optional(),
        importStatus: z.string().optional(),
        salesChannel: z.string().optional(),
        hasRemark: z.boolean().optional(),
        notificationStatus: z.string().optional(),
        crossChannelMergeToday: z.boolean().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getOrders(input || {});
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const order = await db.getOrderById(input.id);
        if (!order) throw new Error("Order not found");
        const items = await db.getOrderItems(input.id);
        return { ...order, items };
      }),

    create: adminProcedure
      .input(z.object({
        customerId: z.number(),
        facebookName: z.string().optional(),
        facebookId: z.string().optional(),
        messengerId: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          productName: z.string(),
          productType: z.enum(["physical", "membership", "gift"]),
          quantity: z.number().min(1),
          unitPrice: z.string(),
          subtotal: z.string(),
          variationId: z.number().optional(),
          variationName: z.string().optional(),
          priceType: z.string().optional(),
          unitCost: z.string().optional(),
          originalUnitPrice: z.string().optional(),
        })),
        shippingAddress: z.string().optional(),
        shippingMethod: z.string().optional(),
        paymentMethodId: z.number().optional(),
        paymentMethodName: z.string().optional(),
        salesChannel: z.string().optional(),
        orderNature: z.string().optional(),
        orderSource: z.string().optional(),
        orderCategory: z.string().optional(),
        sourceName: z.string().optional(),
        liveRoomId: z.number().optional(),
        // V2.2: Promotion / discount / extra charge / credit
        promotionId: z.number().optional(),
        promotionName: z.string().optional(),
        promotionDiscount: z.string().optional(),
        discountAmount: z.string().optional(),
        discountReason: z.string().optional(),
        extraCharge: z.string().optional(),
        extraChargeDescription: z.string().optional(),
        creditUsed: z.string().optional(),
        // V2.2: Recipient info
        recipientName: z.string().optional(),
        recipientPhone: z.string().optional(),
        addressLine1: z.string().optional(),
        addressLine2: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        postcode: z.string().optional(),
        country: z.string().optional(),
        remark: z.string().optional(),
        remarkCategory: z.string().optional(),
        remarkDeliveryDate: z.string().optional(),
        repottingData: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await db.createOrderWithSplit(input);
        if (result.orderId) {
          await db.logOrderOperation(result.orderId, "create", `Order created by ${ctx.user?.name || "admin"}`, null, ctx.user?.name || "admin");
          // V2.0.43/V2.0.55: Save remark to order_remarks if provided
          if (input.remark && input.remark.trim()) {
            await db.createOrderRemark({
              orderId: result.orderId,
              type: "internal",
              content: input.remark.trim(),
              createdBy: ctx.user?.name || "admin",
              remarkCategory: (input.remarkCategory as "repotting" | "desired_delivery_date" | "select_tree" | "other") || "other",
              desiredDeliveryDate: input.remarkDeliveryDate || undefined,
              repottingData: input.repottingData || undefined,
            }).catch(() => {});
          } else if (input.remarkCategory === "desired_delivery_date" && input.remarkDeliveryDate) {
            // V2.0.72: Save desired_delivery_date even without text remark (date is enough)
            await db.createOrderRemark({
              orderId: result.orderId,
              type: "internal",
              content: input.remarkDeliveryDate,
              createdBy: ctx.user?.name || "admin",
              remarkCategory: "desired_delivery_date",
              desiredDeliveryDate: input.remarkDeliveryDate,
            }).catch(() => {});
          } else if (input.repottingData && input.remarkCategory === "repotting") {
            // V2.0.60: Save repotting data even without text remark
            await db.createOrderRemark({
              orderId: result.orderId,
              type: "internal",
              content: "换盆安排",
              createdBy: ctx.user?.name || "admin",
              remarkCategory: "repotting",
              repottingData: input.repottingData,
            }).catch(() => {});
          }
        }
        return result;
      }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        physicalStatus: z.string().optional(),
        membershipStatus: z.string().optional(),
        courierCompany: z.string().optional(),
        trackingNumber: z.string().optional(),
        receiptUrl: z.string().optional(),
        paymentMethodId: z.number().optional(),
        paymentMethodName: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
                const { id, ...data } = input;
        await db.updateOrderStatus(id, data);
        return { success: true };
      }),

    // V2.2: Update order details (for OrderEditPage)
    updateDetails: adminProcedure
      .input(z.object({
        id: z.number(),
        shippingAddress: z.string().optional(),
        shippingMethod: z.string().optional(),
        orderNature: z.string().optional(),
        orderSource: z.string().optional(),
        orderCategory: z.string().optional(),
        recipientName: z.string().optional(),
        recipientPhone: z.string().optional(),
        recipientCity: z.string().optional(),
        recipientState: z.string().optional(),
        recipientPostcode: z.string().optional(),
        recipientCountry: z.string().optional(),
        discountAmount: z.string().optional(),
        discountReason: z.string().optional(),
        extraCharge: z.string().optional(),
        extraChargeDescription: z.string().optional(),
        creditUsed: z.string().optional(),
        promotionId: z.number().optional(),
        promotionName: z.string().optional(),
        promotionDiscount: z.string().optional(),
        shippingFee: z.string().optional(),
        totalAmount: z.string().optional(),
        physicalStatus: z.string().optional(),
        importStatus: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        await db.updateOrderDetails(id, data);
        // Build a meaningful description based on what actually changed
        const changes: string[] = [];
        if (data.physicalStatus) changes.push(`status → ${data.physicalStatus}`);
        if (data.importStatus) changes.push(`import status → ${data.importStatus}`);
        if (data.discountAmount !== undefined) changes.push(`discount → RM${data.discountAmount || "0"}`);
        if (data.discountReason !== undefined) changes.push(`discount reason → ${data.discountReason || "(none)"}`);
        if (data.extraCharge !== undefined) changes.push(`extra charge → RM${data.extraCharge || "0"}`);
        if (data.extraChargeDescription !== undefined) changes.push(`extra charge desc → ${data.extraChargeDescription || "(none)"}`);
        if (data.shippingFee !== undefined) changes.push(`shipping fee → RM${data.shippingFee || "0"}`);
        if (data.shippingAddress !== undefined) changes.push(`shipping address updated`);
        if (data.shippingMethod !== undefined) changes.push(`shipping method → ${data.shippingMethod}`);
        if (data.recipientName !== undefined) changes.push(`recipient name → ${data.recipientName || "(none)"}`);
        if (data.recipientPhone !== undefined) changes.push(`recipient phone → ${data.recipientPhone || "(none)"}`);
        if (data.totalAmount !== undefined) changes.push(`total → RM${data.totalAmount || "0"}`);
        const desc = changes.length > 0 ? `Admin更新订单：${changes.join("， ")}` : `Order details updated by ${ctx.user?.name || "admin"}`;
        await db.logOrderOperation(id, "edit", desc, null, ctx.user?.name || "admin");
        return { success: true };
      }),

    split: adminProcedure
      .input(z.object({
        orderId: z.number().int().positive(),
        items: z.array(z.object({
          orderItemId: z.number().int().positive(),
          quantity: z.number().int().positive(),
        })).min(1).max(100),
        newOrderAllocatedPayment: z.number().finite().min(0).optional(),
        newOrderAllocatedCredit: z.number().finite().min(0).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return db.splitUnpaidPhysicalOrder({
          ...input,
          operator: ctx.user?.name || ctx.user?.openId || "admin",
        });
      }),

    mergeCandidates: adminProcedure
      .input(z.object({ sourceOrderId: z.number().int().positive() }))
      .query(({ input }) => db.getManualOrderMergeCandidates(input.sourceOrderId)),

    merge: adminProcedure
      .input(z.object({
        sourceOrderId: z.number().int().positive(),
        targetOrderId: z.number().int().positive(),
        creditDisposition: z.enum(["carry_forward", "return_to_source"]).optional(),
      }))
      .mutation(({ input, ctx }) => db.mergeUnpaidLocalOrders({
        ...input,
        operator: ctx.user?.name || ctx.user?.openId || "admin",
      })),

    // V2.0.92: Update order items (add/edit/delete) with auto recalculation
    updateItems: adminProcedure
      .input(z.object({
        orderId: z.number(),
        items: z.array(z.object({
          id: z.number().optional(),
          productId: z.number().nullable().optional(),
          productName: z.string(),
          productSku: z.string().nullable().optional(),
          quantity: z.number(),
          unitPrice: z.string(),
          variationId: z.number().nullable().optional(),
          variationName: z.string().nullable().optional(),
          itemSource: z.string().optional(),
          priceType: z.string().optional(),
          originalUnitPrice: z.string().nullable().optional(),
        })),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.updateOrderItems(input.orderId, input.items, ctx.user?.name || "admin");
      }),
    // V2.2: Special order follow-up stats
    followUpStats: adminProcedure.query(async () => {
      return await db.getSpecialOrderFollowUpStats();
    }),
    // V2.2: Special order follow-up list
    followUpList: adminProcedure.input(z.object({
      limit: z.number().optional(),
    })).query(async ({ input }) => {
      return await db.getSpecialOrderFollowUpList(input.limit);
    }),

    // V2.1: Order payments (多次汇款)
    getPayments: adminProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input }) => {
        return await db.getOrderPayments(input.orderId);
      }),

    addPayment: adminProcedure
      .input(z.object({
        orderId: z.number(),
        amount: z.string(),
        paymentMethod: z.string().optional(),
        receiptUrl: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.addOrderPayment({
          orderId: input.orderId,
          amount: input.amount,
          paymentMethod: input.paymentMethod,
          receiptUrl: input.receiptUrl,
          operatorName: ctx.user?.name || "admin",
          notes: input.notes,
          paymentSource: 'admin_manual',
        });
        return { success: true };
      }),

    // V2.1.11: Review payment (approve/reject)
    reviewPayment: adminProcedure
      .input(z.object({
        paymentId: z.number(),
        action: z.enum(['approve', 'reject']),
        rejectReason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.reviewPayment({
          paymentId: input.paymentId,
          action: input.action,
          rejectReason: input.rejectReason,
          reviewerName: ctx.user?.name || "admin",
        });
        return { success: true };
      }),

    // V2.1.15: Edit payment record
    editPayment: adminProcedure
      .input(z.object({
        paymentId: z.number(),
        amount: z.string().optional(),
        paymentMethod: z.string().optional(),
        receiptUrl: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.editOrderPayment({
          paymentId: input.paymentId,
          amount: input.amount,
          paymentMethod: input.paymentMethod,
          receiptUrl: input.receiptUrl,
          notes: input.notes,
          operatorName: ctx.user?.name || "admin",
        });
        return { success: true };
      }),

    // V2.1.15: Add refund
    addRefund: adminProcedure
      .input(z.object({
        orderId: z.number(),
        amount: z.string(),
        refundMethod: z.string(),
        receiptUrl: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.addOrderRefund({
          orderId: input.orderId,
          amount: input.amount,
          refundMethod: input.refundMethod,
          receiptUrl: input.receiptUrl,
          notes: input.notes,
          operatorName: ctx.user?.name || "admin",
        });
        return { success: true };
      }),

    // V2.1.15: Get order refunds
    getRefunds: adminProcedure
      .input(z.object({
        orderId: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getOrderRefunds(input.orderId);
      }),

    // V2.1.18: Process overpayment (Credit / TNG / Cash)
    processOverpayment: adminProcedure
      .input(z.object({
        orderId: z.number(),
        amount: z.string(),
        method: z.enum(['credit', 'tng', 'cash', 'bank_transfer', 'other']),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.processOverpayment({
          orderId: input.orderId,
          amount: input.amount,
          method: input.method,
          notes: input.notes,
          operatorName: ctx.user?.name || "admin",
        });
      }),

    // V2.1.19: Special Status Management
    getSpecialStatuses: adminProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input }) => {
        return await db.getOrderSpecialStatuses(input.orderId);
      }),

    createSpecialStatus: adminProcedure
      .input(z.object({
        orderId: z.number(),
        type: z.enum(['pending_shipping', 'pending_refund', 'company_bear', 'logistics_error', 'incomplete_info', 'notification_failed', 'stock_exception', 'overdue', 'over_payment', 'amount_changed', 'amount_anomaly', 'other']),
        reason: z.string().optional(),
        amount: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createOrderSpecialStatus({
          orderId: input.orderId,
          type: input.type,
          reason: input.reason,
          amount: input.amount,
          source: 'manual',
          createdBy: ctx.user?.name || 'admin',
        });
      }),

    resolveSpecialStatus: adminProcedure
      .input(z.object({
        specialStatusId: z.number(),
        resolutionMethod: z.enum(['credit', 'tng', 'cash', 'bank_transfer', 'other', 'data_corrected', 'company_bear', 'false_positive']),
        resolutionRemark: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.resolveOrderSpecialStatus({
          specialStatusId: input.specialStatusId,
          resolutionMethod: input.resolutionMethod,
          resolutionRemark: input.resolutionRemark,
          resolvedBy: ctx.user?.name || 'admin',
        });
      }),

    migrateSpecialStatuses: adminProcedure
      .mutation(async () => {
        return await db.migrateSpecialOrdersToTable();
      }),

    // V2.1: Cancel order with reason
    cancelOrder: adminProcedure
      .input(z.object({
        id: z.number(),
        reason: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.cancelOrderWithReason(input.id, input.reason, ctx.user?.name || "admin");
        return { success: true };
      }),

    // V3.2: Update special status (set / remove)
    updateSpecialStatus: adminProcedure
      .input(z.object({
        orderId: z.number(),
        action: z.enum(["set", "remove"]),
        specialOrderType: z.string().optional(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const adminName = ctx.user?.name || "admin";
        const { sql } = await import("drizzle-orm");
        if (input.action === "remove") {
          await db.executeRaw(sql`UPDATE orders SET isSpecialOrder = 0, specialOrderStatus = 'resolved', specialOrderReason = ${input.reason || ''}, specialOrderBy = ${adminName}, specialOrderUpdatedAt = NOW() WHERE id = ${input.orderId}`);
        } else {
          if (!input.specialOrderType) throw new Error("specialOrderType is required for set action");
          await db.executeRaw(sql`UPDATE orders SET isSpecialOrder = 1, specialOrderType = ${input.specialOrderType}, specialOrderStatus = 'pending', specialOrderSource = 'manual', specialOrderReason = ${input.reason || ''}, specialOrderBy = ${adminName}, specialOrderUpdatedAt = NOW() WHERE id = ${input.orderId}`);
        }
        await db.logOrderOperation(input.orderId, "special_status", `Special status ${input.action === "set" ? "set to " + input.specialOrderType : "removed"} by ${adminName}${input.reason ? ": " + input.reason : ""}`, null, adminName);
        return { success: true };
      }),

    // V2.1: Order operation logs
    getOperationLogs: adminProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input }) => {
        return await db.getOrderOperationLogs(input.orderId);
      }),

    // V2.1: Search products for order creation (名称/编号/关键词/SKU)
    searchProductsForOrder: adminProcedure
      .input(z.object({ query: z.string(), orderCategory: z.enum(["local", "import"]).optional() }))
      .query(async ({ input }) => {
        return await db.getProductsForOrder({ search: input.query, orderCategory: input.orderCategory });
      }),

    // V2.1: Get order detail with items, payments, and logs
    getDetail: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const order = await db.getOrderById(input.id);
        if (!order) throw new Error("Order not found");
        const items = await db.getOrderItems(input.id);
        const payments = await db.getOrderPayments(input.id);
        const logs = await db.getOrderOperationLogs(input.id);
        const packages = await db.getOrderPackages(input.id);
        const latestLabelPackage = [...packages].reverse().find((pkg: any) => pkg.shippingLabelUrl);
        return {
          ...order,
          // AWB原始链接持续保存在包裹记录；订单区域8展示最近可用标签，避免新增重复存储。
          shippingLabelUrl: latestLabelPackage?.shippingLabelUrl || null,
          items,
          payments,
          logs,
        };
      }),

    // V2.1: Compare shipping quotes from multiple providers
    compareShippingQuotes: adminProcedure
      .input(z.object({
        fromPostcode: z.string(),
        toPostcode: z.string(),
        weightKg: z.number(),
      }))
      .query(async ({ input }) => {
        const results: any[] = [];

        // Try ParcelDaily
        try {
          const quote = await parceldaily.getQuote({
            fromPostcode: input.fromPostcode,
            toPostcode: input.toPostcode,
            kg: input.weightKg,
          });
          const couriers = parceldaily.extractCourierPrices(quote);
          for (const c of couriers) {
            results.push({ provider: "ParcelDaily", ...c });
          }
        } catch (e: any) {
          // Skip if ParcelDaily fails
        }

        // Try ParcelKing
        if (parcelking.isParcelKingConfigured()) {
          try {
            const pkResult = await parcelking.priceQuery({
              from_postcode: input.fromPostcode,
              to_postcode: input.toPostcode,
              parcel_weight_kg: input.weightKg,
            });
            if (pkResult && pkResult.services) {
              for (const s of pkResult.services) {
                results.push({
                  provider: "ParcelKing",
                  courier: s.service_name,
                  price: s.total_price,
                  estDelivery: s.estimated_days || null,
                });
              }
            }
          } catch (e: any) {
            // Skip ParcelKing if it fails entirely
          }
        }

        return { success: true, quotes: results };
      }),

    // V2.2: AI Smart Parse customer address
    aiSmartParse: adminProcedure
      .input(z.object({ text: z.string() }))
      .query(async ({ input }) => {
        return await db.aiSmartParse(input.text);
      }),

    // V2.2: Use customer credit
    useCredit: adminProcedure
      .input(z.object({
        customerId: z.number(),
        amount: z.number(),
        orderId: z.number(),
      }))
      .mutation(async ({ input }) => {
        return await db.useCustomerCredit(input.customerId, input.amount, input.orderId);
      }),

    // V2.2: Refund customer credit
    refundCredit: adminProcedure
      .input(z.object({
        customerId: z.number(),
        amount: z.number(),
        orderId: z.number(),
      }))
      .mutation(async ({ input }) => {
        return await db.refundCustomerCredit(input.customerId, input.amount, input.orderId);
      }),

    // V2.2: Calculate West Malaysia shipping
    calculateShipping: adminProcedure
      .input(z.object({
        totalWeight: z.number(),
        orderTotal: z.number(),
        shippingMethod: z.enum(["west_malaysia", "east_malaysia", "east_malaysia_poslaju", "east_malaysia_shopee", "lalamove", "self_pickup"]).optional(),
      }))
      .query(async ({ input }) => {
        const method = input.shippingMethod || "west_malaysia";
        const config = await db.getControlledShippingConfiguration();
        if (method === "east_malaysia_poslaju") {
          return { shippingFee: config.eastMalaysiaPosLaju.checkoutPrepaidFee, isFreeShipping: false, threshold: 0, shippingMethod: method, settlementNote: config.eastMalaysiaPosLaju.settlementNote };
        } else if (method === "east_malaysia_shopee" || method === "east_malaysia") {
          return { shippingFee: config.eastMalaysiaShopee.checkoutPrepaidFee, isFreeShipping: config.eastMalaysiaShopee.checkoutPrepaidFee === 0, threshold: 0, shippingMethod: method, settlementNote: config.eastMalaysiaShopee.settlementNote };
        } else if (method === "self_pickup") {
          return { shippingFee: 0, isFreeShipping: false, threshold: 0, shippingMethod: method };
        } else if (method === "lalamove") {
          return {
            shippingFee: calculateLalamoveCheckoutCustomerShipping(config.lalamove.companyBearingFee),
            isFreeShipping: false,
            threshold: 0,
            shippingMethod: method,
            companyBearing: config.lalamove.companyBearingFee,
            settlementNote: config.lalamove.settlementNote,
          };
        }
        // West Malaysia (default)
        const result = calculateWestMalaysiaShippingBreakdown(input.totalWeight, input.orderTotal, config.westMalaysia);
        return { shippingFee: result.shippingFee, isFreeShipping: result.freeShipping, extraWeightCharge: result.extraWeightCharge, threshold: config.westMalaysia.freeShippingThreshold, shippingMethod: method };
      }),
    // V2.0.33: Send checkout link to Messenger
    sendCheckout: adminProcedure
      .input(z.object({ orderId: z.number(), customMessage: z.string().optional() }))
      .mutation(async ({ input }) => {
        const order = await db.getOrderById(input.orderId);
        if (!order) throw new Error("Order not found");
        if (!order.checkoutLink) throw new Error("Checkout link not generated");
        if (!order.messengerId) throw new Error("No Messenger ID for this order");
        try {
          const { sendTextMessage } = await import("./messenger");
          const mallSettings = await db.getMallSettings();
          const baseUrl = (mallSettings as any)?.domain ? `https://${(mallSettings as any).domain}` : "https://www.xintian.com.my";
          const fullLink = `${baseUrl}${order.checkoutLink}`;
          const settings = await db.getSystemSettings();
          const template = (settings as any)?.checkoutMessageTemplate ||
            "您好，感恩您的支持 ❤️\n\n目前还没收到您的汇款及确认信息。\n\n请您点击以下链接查询您的订单（{orderNumber}）：\n\n{link}\n\n进入订单后，除了可以查询订单，也可以继续到商城加单 ❤️\n\n西马消费满 RM150（特价商品除外），10kg 内即可享受免邮优惠。";
          let message = (input.customMessage || template)
            .replace(/\{link\}/g, fullLink)
            .replace(/\{orderNumber\}/g, order.orderNumber || "");
          message = await appendOrderCarePackLinkToCheckoutMessage({ orderId: input.orderId, message, baseUrl, channel: "messenger" });
          await sendTextMessage(order.messengerId, message);
          await db.updateOrderNotificationStatus(input.orderId, "sent", null);
          // V2.0.50: Log notification history
          await db.createNotificationLog({
            orderId: input.orderId,
            type: "checkout_reminder",
            channel: "messenger",
            message: message.substring(0, 1000),
            status: "sent",
            sentAt: new Date(),
          }).catch(() => {});
          return { success: true };
        } catch (error: any) {
          await db.updateOrderNotificationStatus(input.orderId, "failed", error.message || "Unknown error");
          // V2.0.50: Log failed notification
          await db.createNotificationLog({
            orderId: input.orderId,
            type: "checkout_reminder",
            channel: "messenger",
            message: (input.customMessage || "").substring(0, 1000),
            status: "failed",
            errorMessage: error.message || "Unknown error",
          }).catch(() => {});
          throw new Error(`Failed to send: ${error.message}`);
        }
      }),
    // V2.0.33: Batch send checkout links to all pending orders
    batchSendCheckout: adminProcedure
      .input(z.object({
        status: z.string().optional(),
        source: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        // V2.0.49: Send to ALL unpaid orders (pending), regardless of notification status (support multiple sends)
        const allOrders = await db.getOrders({
          physicalStatus: "pending",
          hasRemark: undefined,
        });
        const pendingOrders = allOrders as any[];
        const results = { sent: 0, failed: 0, skipped: 0, total: pendingOrders.length, failedOrders: [] as any[] };
        const settings = await db.getSystemSettings();
        const template = (settings as any)?.checkoutMessageTemplate ||
          "您好，感恩您的支持 ❤️\n\n目前还没收到您的汇款及确认信息。\n\n请您点击以下链接查询您的订单（{orderNumber}）：\n\n{link}\n\n进入订单后，除了可以查询订单，也可以继续到商城加单 ❤️\n\n西马消费满 RM150（特价商品除外），10kg 内即可享受免邮优惠。";
        let isFirstSend = true;
        for (const order of pendingOrders) {
          if (!order.messengerId || !order.checkoutLink) {
            results.skipped++;
            continue;
          }
          // V2.0.50: 1-second interval between sends to avoid API rate limiting
          if (!isFirstSend) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          isFirstSend = false;
          const { sendTextMessage } = await import("./messenger");
          const mallSettings = await db.getMallSettings();
          const baseUrl = (mallSettings as any)?.domain ? `https://${(mallSettings as any).domain}` : "https://www.xintian.com.my";
          const fullLink = `${baseUrl}${order.checkoutLink}`;
          let message = template
            .replace(/\{link\}/g, fullLink)
            .replace(/\{orderNumber\}/g, order.orderNumber || "");
          message = await appendOrderCarePackLinkToCheckoutMessage({ orderId: order.id, message, baseUrl, channel: "messenger" });
          try {
            await sendTextMessage(order.messengerId, message);
            await db.updateOrderNotificationStatus(order.id, "sent", null);
            // V2.0.50: Log notification history
            await db.createNotificationLog({
              orderId: order.id,
              type: "checkout_reminder",
              channel: "messenger",
              message: message.substring(0, 1000),
              status: "sent",
              sentAt: new Date(),
            }).catch(() => {});
            results.sent++;
          } catch (error: any) {
            await db.updateOrderNotificationStatus(order.id, "failed", error.message || "Unknown error");
            // V2.0.50: Log failed notification
            await db.createNotificationLog({
              orderId: order.id,
              type: "checkout_reminder",
              channel: "messenger",
              message: message.substring(0, 1000),
              status: "failed",
              errorMessage: error.message || "Unknown error",
            }).catch(() => {});
            results.failed++;
            results.failedOrders.push({ id: order.id, orderNumber: order.orderNumber, customerName: order.facebookName || order.customerName || "Unknown", error: error.message || "Unknown error" });
          }
        }
        return results;
      }),
    // V2.0.48: Batch send checkout links to selected orders
    batchSendSelected: adminProcedure
      .input(z.object({
        orderIds: z.array(z.number()).min(1, "请至少选择一张订单"),
      }))
      .mutation(async ({ input }) => {
        const results = { sent: 0, failed: 0, skipped: 0, total: input.orderIds.length, failedOrders: [] as any[] };
        const settings = await db.getSystemSettings();
        const template = (settings as any)?.checkoutMessageTemplate ||
          "您好，感恩您的支持 ❤️\n\n目前还没收到您的汇款及确认信息。\n\n请您点击以下链接查询您的订单（{orderNumber}）：\n\n{link}\n\n进入订单后，除了可以查询订单，也可以继续到商城加单 ❤️\n\n西马消费满 RM150（特价商品除外），10kg 内即可享受免邮优惠。";
        let isFirstSendSelected = true;
        for (const orderId of input.orderIds) {
          const order = await db.getOrderById(orderId);
          if (!order || !order.checkoutLink || !order.messengerId) {
            results.skipped++;
            continue;
          }
          // V2.0.50: 1-second interval between sends to avoid API rate limiting
          if (!isFirstSendSelected) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          isFirstSendSelected = false;
          const { sendTextMessage } = await import("./messenger");
          const mallSettings = await db.getMallSettings();
          const baseUrl = (mallSettings as any)?.domain ? `https://${(mallSettings as any).domain}` : "https://www.xintian.com.my";
          const fullLink = `${baseUrl}${order.checkoutLink}`;
          let message = template
            .replace(/\{link\}/g, fullLink)
            .replace(/\{orderNumber\}/g, order.orderNumber || "");
          message = await appendOrderCarePackLinkToCheckoutMessage({ orderId, message, baseUrl, channel: "messenger" });
          try {
            await sendTextMessage(order.messengerId, message);
            await db.updateOrderNotificationStatus(orderId, "sent", null);
            // V2.0.50: Log notification history
            await db.createNotificationLog({
              orderId: orderId,
              type: "checkout_reminder",
              channel: "messenger",
              message: message.substring(0, 1000),
              status: "sent",
              sentAt: new Date(),
            }).catch(() => {});
            results.sent++;
          } catch (error: any) {
            await db.updateOrderNotificationStatus(orderId, "failed", error.message || "Unknown error");
            // V2.0.50: Log failed notification
            await db.createNotificationLog({
              orderId: orderId,
              type: "checkout_reminder",
              channel: "messenger",
              message: message.substring(0, 1000),
              status: "failed",
              errorMessage: error.message || "Unknown error",
            }).catch(() => {});
            results.failed++;
            results.failedOrders.push({ id: orderId, orderNumber: order.orderNumber, customerName: order.facebookName || "Unknown", error: error.message || "Unknown error" });
          }
        }
        return results;
      }),
    // V2.0.33: Resend checkout link
    resendCheckout: adminProcedure
      .input(z.object({ orderId: z.number(), customMessage: z.string().optional() }))
      .mutation(async ({ input }) => {
        const order = await db.getOrderById(input.orderId);
        if (!order) throw new Error("Order not found");
        if (!order.checkoutLink) throw new Error("Checkout link not generated");
        if (!order.messengerId) throw new Error("No Messenger ID for this order");
        try {
          const { sendTextMessage } = await import("./messenger");
          const mallSettings = await db.getMallSettings();
          const baseUrl = (mallSettings as any)?.domain ? `https://${(mallSettings as any).domain}` : "https://www.xintian.com.my";
          const fullLink = `${baseUrl}${order.checkoutLink}`;
          const settings = await db.getSystemSettings();
          const template = (settings as any)?.checkoutMessageTemplate ||
            "您好，感恩您的支持 ❤️\n\n目前还没收到您的汇款及确认信息。\n\n请您点击以下链接查询您的订单（{orderNumber}）：\n\n{link}\n\n进入订单后，除了可以查询订单，也可以继续到商城加单 ❤️\n\n西马消费满 RM150（特价商品除外），10kg 内即可享受免邮优惠。";
          let message = (input.customMessage || template)
            .replace(/\{link\}/g, fullLink)
            .replace(/\{orderNumber\}/g, order.orderNumber || "");
          message = await appendOrderCarePackLinkToCheckoutMessage({ orderId: input.orderId, message, baseUrl, channel: "messenger" });
          await sendTextMessage(order.messengerId, message);
          await db.updateOrderNotificationStatus(input.orderId, "sent", null);
          // V2.0.50: Log notification history
          await db.createNotificationLog({
            orderId: input.orderId,
            type: "checkout_reminder",
            channel: "messenger",
            message: message.substring(0, 1000),
            status: "sent",
            sentAt: new Date(),
          }).catch(() => {});
          return { success: true };
        } catch (error: any) {
          await db.updateOrderNotificationStatus(input.orderId, "failed", error.message || "Unknown error");
          // V2.0.50: Log failed notification
          await db.createNotificationLog({
            orderId: input.orderId,
            type: "checkout_reminder",
            channel: "messenger",
            message: (input.customMessage || "").substring(0, 1000),
            status: "failed",
            errorMessage: error.message || "Unknown error",
          }).catch(() => {});
          throw new Error(`Failed to send: ${error.message}`);
        }
      }),
  }),
  // ===========================================================================
  // Membership Fee Reviews
  // ===========================================================================
  membership: router({
    listReviews: adminProcedure
      .input(z.object({
        status: z.string().optional(),
        flowStatus: z.string().optional(),
        membershipStatus: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getMembershipReviews(input || {});
      }),

    getReviewById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const review = await db.getMembershipReviewById(input.id);
        if (!review) throw new Error("Review not found");
        return review;
      }),

    getReviewByOrderId: adminProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input }) => {
        return await db.getMembershipReviewByOrderId(input.orderId);
      }),

    createReview: adminProcedure
      .input(z.object({
        orderId: z.number(),
        receiptFileUrl: z.string(),
        flowTemplateId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createMembershipReview(input);
        // Order stays pending (待汇款) - review is an internal task, not a business status
        // If order was rejected, set back to pending so customer can re-upload
        await db.updateOrderStatus(input.orderId, {
          membershipStatus: "pending",
          receiptUrl: input.receiptFileUrl,
        });
        return { success: true };
      }),

    approveFee: adminProcedure
      .input(z.object({
        reviewId: z.number(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const review = await db.getMembershipReviewById(input.reviewId);
        if (!review) throw new Error("Review not found");

        // Step 1: Mark review as approved
        await db.approveMembershipFee(input.reviewId, ctx.user.id, input.notes);

        // Step 2: Update order membership status to fee_confirmed
        await db.updateOrderStatus(review.orderId, {
          membershipStatus: "fee_confirmed",
        });

        // Step 3: Attempt to send Flow via Messenger
        try {
          // Get the flow template - prefer review's assigned template, otherwise find by name
          let template = review.flowTemplateId ? await db.getFlowTemplateById(review.flowTemplateId) : null;

          // If no template assigned, find the membership success flow by name (NOT fallback to first active)
          if (!template) {
            const allTemplates = await db.getFlowTemplates(true);
            template = allTemplates.find(t => 
              t.name.includes("会员") && t.name.includes("付款成功") ||
              t.name.includes("会员") && t.name.includes("Flow")
            ) || null;
          }

          // Also verify the template is active
          if (template && !template.isActive) {
            template = null;
          }

          if (template) {
            const messageContent = template.messageContent;
            const imageUrl = template.imageUrl || "";
            const audioUrl = template.audioUrl || "";

            // Get the order to find customer's Messenger PSID
            const order = await db.getOrderById(review.orderId);
            const customer = order?.customerId ? await db.getCustomerById(order.customerId) : null;
            const psid = customer?.messengerId || order?.messengerId || "";

            let flowResult: { success: boolean; messageId?: string; error?: string } = { success: false, error: "No PSID available" };

            if (psid) {
              // Send via real Messenger API - text, optional tutorial image, then optional voice greeting.
              flowResult = await sendTelegramJoinFlow(
                psid,
                "", // No button link - link is in the message text
                messageContent,
                "", // No button name
                imageUrl, // Pass image URL for sending
                audioUrl // Pass optional voice greeting after the tutorial image
              );
            } else {
              console.warn("[Membership] No Messenger PSID found for customer, cannot send Flow automatically");
            }

            // Log the send attempt
            await db.createFlowSendLog({
              reviewId: input.reviewId,
              flowTemplateId: template.id,
              stepOrder: 1,
              status: flowResult.success ? "sent" : "failed",
              messageContent,
              sentAt: new Date(),
              errorMessage: flowResult.error,
            } as any);

            if (flowResult.success) {
              // Update review flow status
              await db.updateFlowStatus(input.reviewId, {
                flowStatus: "sent",
                flowSentAt: new Date(),
              });

              // Flow sent successfully → completed (已完成)
              await db.updateOrderStatus(review.orderId, {
                membershipStatus: "completed",
              });

              return {
                success: true,
                flowSent: true,
                message: "会员费已确认，Messenger Flow 已自动发送",
                messageContent,
              };
            } else {
              await db.updateFlowStatus(input.reviewId, {
                flowStatus: "failed",
                flowErrorMessage: flowResult.error || "Messenger API send failed",
              });

              // Flow failed → manual_follow_up (待人工发送)
              await db.updateOrderStatus(review.orderId, {
                membershipStatus: "manual_follow_up",
              });

              return {
                success: true,
                flowSent: false,
                message: `会员费已确认，但 Flow 发送失败: ${flowResult.error}`,
              };
            }
          } else {
            // No membership flow template found or it's disabled
            await db.updateFlowStatus(input.reviewId, {
              flowStatus: "failed",
              flowErrorMessage: "会员付款成功Flow尚未设置/未启用",
            });

            // No flow configured → manual_follow_up (待人工发送)
            await db.updateOrderStatus(review.orderId, {
              membershipStatus: "manual_follow_up",
            });

            return {
              success: true,
              flowSent: false,
              message: "会员费已确认，但会员付款成功Flow尚未设置/未启用，请在Flow管理中创建并启用名为「会员付款成功Flow」的模板",
            };
          }
        } catch (error: any) {
          await db.updateFlowStatus(input.reviewId, {
            flowStatus: "failed",
            flowErrorMessage: error.message,
          });

          // Error → manual_follow_up (待人工发送)
          await db.updateOrderStatus(review.orderId, {
            membershipStatus: "manual_follow_up",
          });

          return {
            success: true,
            flowSent: false,
            message: `会员费已确认，但 Flow 发送失败: ${error.message}`,
          };
        }
      }),

    rejectFee: adminProcedure
      .input(z.object({
        reviewId: z.number(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const review = await db.getMembershipReviewById(input.reviewId);
        if (!review) throw new Error("Review not found");

        await db.rejectMembershipFee(input.reviewId, ctx.user.id, input.notes);

        // Set order membership status to rejected (已拒绝) - customer can re-upload
        await db.updateOrderStatus(review.orderId, {
          membershipStatus: "rejected",
        });

        return { success: true };
      }),

    resendFlow: adminProcedure
      .input(z.object({
        reviewId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const review = await db.getMembershipReviewById(input.reviewId);
        if (!review) throw new Error("Review not found");

        let template = review.flowTemplateId ? await db.getFlowTemplateById(review.flowTemplateId) : null;
        if (!template) {
          const allTemplates = await db.getFlowTemplates(true);
          template = allTemplates.find(t => 
            t.name.includes("会员") && t.name.includes("付款成功") ||
            t.name.includes("会员") && t.name.includes("Flow")
          ) || null;
        }
        if (template && !template.isActive) template = null;

        if (!template) throw new Error("会员付款成功Flow尚未设置/未启用，请在Flow管理中创建并启用");

        // Get customer PSID
        const order = await db.getOrderById(review.orderId);
        const customer = order?.customerId ? await db.getCustomerById(order.customerId) : null;
        const psid = customer?.messengerId || order?.messengerId || "";

        let flowResult: { success: boolean; messageId?: string; error?: string } = { success: false, error: "No PSID available" };

        if (psid) {
          flowResult = await sendTelegramJoinFlow(
            psid,
            "",
            template.messageContent,
            "",
            template.imageUrl || ""
          );
        }

        await db.createFlowSendLog({
          reviewId: input.reviewId,
          flowTemplateId: template.id,
          stepOrder: 1,
          status: flowResult.success ? "sent" : "failed",
          messageContent: template.messageContent,
          sentAt: new Date(),
          errorMessage: flowResult.error,
        } as any);

        if (flowResult.success) {
          await db.updateFlowStatus(input.reviewId, {
            flowStatus: "sent",
            flowSentAt: new Date(),
            flowErrorMessage: undefined,
          });

          // Resend success → completed (已完成)
          await db.updateOrderStatus(review.orderId, {
            membershipStatus: "completed",
          });

          return {
            success: true,
            message: "Flow 已重新发送",
            messageContent: template.messageContent,
          };
        } else {
          await db.updateFlowStatus(input.reviewId, {
            flowStatus: "failed",
            flowErrorMessage: flowResult.error,
          });

          // Resend failed → stay manual_follow_up (待人工发送)
          await db.updateOrderStatus(review.orderId, {
            membershipStatus: "manual_follow_up",
          });

          return {
            success: false,
            message: `Flow 重发失败: ${flowResult.error}`,
          };
        }
      }),

    markMembershipCompleted: adminProcedure
      .input(z.object({ reviewId: z.number() }))
      .mutation(async ({ input }) => {
        const review = await db.getMembershipReviewById(input.reviewId);
        if (!review) throw new Error("Review not found");

        // Admin manually marks as completed (after manual sending)
        await db.updateOrderStatus(review.orderId, {
          membershipStatus: "completed",
        });
        return { success: true };
      }),

    markNeedsFollowUp: adminProcedure
      .input(z.object({
        reviewId: z.number(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const review = await db.getMembershipReviewById(input.reviewId);
        if (!review) throw new Error("Review not found");

        await db.markNeedsManualFollowUp(input.reviewId, input.notes);
        await db.updateOrderStatus(review.orderId, {
          membershipStatus: "manual_follow_up",
        });
        return { success: true };
      }),

    cancelMembershipOrder: adminProcedure
      .input(z.object({
        reviewId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const review = await db.getMembershipReviewById(input.reviewId);
        if (!review) throw new Error("Review not found");

        await db.updateOrderStatus(review.orderId, {
          membershipStatus: "cancelled",
        });
        return { success: true };
      }),

    getFlowLogs: adminProcedure
      .input(z.object({ reviewId: z.number() }))
      .query(async ({ input }) => {
        return await db.getFlowSendLogsByReviewId(input.reviewId);
      }),
  }),

  // ===========================================================================
  // Flow Templates
  // ===========================================================================
  flows: router({
    list: adminProcedure
      .input(z.object({ activeOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getFlowTemplates(input?.activeOnly);
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const template = await db.getFlowTemplateById(input.id);
        if (!template) throw new Error("Flow template not found");
        const steps = await db.getFlowStepsByTemplateId(input.id);
        return { ...template, steps };
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        messageContent: z.string().min(1),
        imageUrl: z.string().optional(),
        videoUrl: z.string().optional(),
        audioUrl: z.string().optional(),
        buttonName: z.string().optional(),
        buttonLink: z.string().optional(),
        reminderEnabled: z.boolean().optional(),
        reminderDelayHours: z.number().optional(),
        reminderMessage: z.string().optional(),
        reminderMaxCount: z.number().optional(),
        followUpEnabled: z.boolean().optional(),
        followUpDelayHours: z.number().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createFlowTemplate(input as any);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        messageContent: z.string().optional(),
        imageUrl: z.string().optional(),
        videoUrl: z.string().optional(),
        audioUrl: z.string().optional(),
        buttonName: z.string().optional(),
        buttonLink: z.string().optional(),
        reminderEnabled: z.boolean().optional(),
        reminderDelayHours: z.number().optional(),
        reminderMessage: z.string().optional(),
        reminderMaxCount: z.number().optional(),
        followUpEnabled: z.boolean().optional(),
        followUpDelayHours: z.number().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateFlowTemplate(id, data as any);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteFlowTemplate(input.id);
        return { success: true };
      }),

    // Flow Steps
    listSteps: adminProcedure
      .input(z.object({ templateId: z.number() }))
      .query(async ({ input }) => {
        return await db.getFlowStepsByTemplateId(input.templateId);
      }),

    createStep: adminProcedure
      .input(z.object({
        flowTemplateId: z.number(),
        stepOrder: z.number(),
        stepName: z.string().min(1),
        messageType: z.enum(["text", "image", "video", "audio", "button", "contact_support"]),
        messageContent: z.string().optional(),
        mediaUrl: z.string().optional(),
        buttonName: z.string().optional(),
        buttonLink: z.string().optional(),
        delaySeconds: z.number().optional(),
        conditionType: z.enum(["always", "if_not_clicked", "if_clicked"]).optional(),
        conditionValue: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createFlowStep(input as any);
      }),

    updateStep: adminProcedure
      .input(z.object({
        id: z.number(),
        stepOrder: z.number().optional(),
        stepName: z.string().optional(),
        messageType: z.enum(["text", "image", "video", "audio", "button", "contact_support"]).optional(),
        messageContent: z.string().optional(),
        mediaUrl: z.string().optional(),
        buttonName: z.string().optional(),
        buttonLink: z.string().optional(),
        delaySeconds: z.number().optional(),
        conditionType: z.enum(["always", "if_not_clicked", "if_clicked"]).optional(),
        conditionValue: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateFlowStep(id, data as any);
        return { success: true };
      }),

    deleteStep: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteFlowStep(input.id);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Customers
  // ===========================================================================
  customers: router({
    list: adminProcedure
      .input(z.object({ search: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getCustomers(input?.search);
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const customer = await db.getCustomerById(input.id);
        if (!customer) throw new Error("Customer not found");
        return customer;
      }),

    findOrCreate: adminProcedure
      .input(z.object({
        facebookId: z.string().optional(),
        facebookName: z.string().optional(),
        messengerId: z.string().optional(),
        name: z.string().optional(),
        phoneNumber: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        postalCode: z.string().optional(),
        country: z.string().optional(),
        shopLinkIdentifier: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.findOrCreateCustomer(input);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        facebookId: z.string().optional(),
        facebookName: z.string().optional(),
        messengerId: z.string().optional(),
        phoneNumber: z.string().optional(),
        whatsappPhone: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        postalCode: z.string().optional(),
        country: z.string().optional(),
        displayName: z.string().optional(),
        isBlacklisted: z.boolean().optional(),
        blacklistReason: z.string().optional(),
        notes: z.string().optional(),
        membershipLevel: z.enum(["regular", "member", "vip"]).optional(),
        pointsBalance: z.number().optional(),
        customerType: z.enum(["retail", "wholesale", "agent"]).optional(),
        accountEmail: z.string().optional(),
        canLogin: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCustomer(id, data as any);
        return { success: true };
      }),

    getOrders: adminProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCustomerOrders(input.customerId);
      }),

    findDuplicates: adminProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input }) => {
        return await db.findPotentialDuplicateCustomers(input.customerId);
      }),

    getMergePreview: adminProcedure
      .input(z.object({ sourceId: z.number(), targetId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCustomerMergePreview(input.sourceId, input.targetId);
      }),

    merge: adminProcedure
      .input(z.object({
        sourceId: z.number(),
        targetId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.mergeCustomers(input.sourceId, input.targetId, ctx.user.id);
      }),

    getMergeSuggestions: adminProcedure
      .input(z.object({ status: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getMergeSuggestions(input?.status);
      }),

    // V2.0.78: Adjust customer credit (add/deduct) — reason is now required
    adjustCredit: adminProcedure
      .input(z.object({
        customerId: z.number(),
        amount: z.string(),
        reason: z.string().min(1, "原因必填"),
      }))
      .mutation(async ({ input, ctx }) => {
        const amount = parseFloat(input.amount);
        if (isNaN(amount) || amount === 0) throw new Error("Invalid amount");
        return await db.adjustCustomerCredit(input.customerId, amount, input.reason, ctx.user.id, ctx.user.name || undefined);
      }),

    // V2.0.78: Get customer credit ledger
    getCreditLedger: adminProcedure
      .input(z.object({
        customerId: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getCustomerCreditLedger(input.customerId);
      }),

    // V2.0.81: Get customer timeline
    getTimeline: adminProcedure
      .input(z.object({
        customerId: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getCustomerTimeline(input.customerId);
      }),

    // V2.0.78: Set blacklist status — use db helper for audit trail
    setBlacklist: adminProcedure
      .input(z.object({
        customerId: z.number(),
        isBlacklisted: z.boolean(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.toggleCustomerBlacklist(input.customerId, input.isBlacklisted, input.reason || "", ctx.user.name || `Admin #${ctx.user.id}`);
        return { success: true };
      }),
  }),

  // ===========================================================================
  // Messenger (Facebook integration)
  // ===========================================================================
  messenger: router({
    // Test sending a message to a PSID
    testSend: adminProcedure
      .input(z.object({
        psid: z.string(),
        message: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          const result = await sendTextMessage(
            input.psid,
            input.message || "测试消息：心田系统 Messenger 集成测试成功！"
          );
          return { success: true, result };
        } catch (error: any) {
          return { success: false, error: error?.response?.data?.error?.message || error?.message };
        }
      }),

    // Get user profile by PSID
    getProfile: adminProcedure
      .input(z.object({ psid: z.string() }))
      .query(async ({ input }) => {
        return await getUserProfile(input.psid);
      }),

    // Send custom message to a customer
    sendCustomMessage: adminProcedure
      .input(z.object({
        customerId: z.number(),
        message: z.string(),
        imageUrl: z.string().optional(),
        buttonText: z.string().optional(),
        buttonUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const customer = await db.getCustomerById(input.customerId);
        if (!customer) throw new Error("Customer not found");
        const psid = customer.messengerId;
        if (!psid) throw new Error("Customer has no Messenger ID");

        try {
          if (input.imageUrl) {
            // Send image with caption
            const { sendMediaMessage } = await import("./messenger");
            await sendMediaMessage(psid, "image", input.imageUrl, input.message);
          } else {
            await sendTextMessage(psid, input.message);
          }

          if (input.buttonText && input.buttonUrl) {
            const { sendButtonMessage } = await import("./messenger");
            await sendButtonMessage(psid, "请点击以下按钮", [
              { title: input.buttonText, url: input.buttonUrl },
            ]);
          }

          return { success: true };
        } catch (error: any) {
          return { success: false, error: error?.response?.data?.error?.message || error?.message };
        }
      }),

    // Get Facebook connection status
    status: adminProcedure.query(async () => {
      return {
        pageId: process.env.FB_PAGE_ID || "",
        appId: process.env.FB_APP_ID || "",
        hasPageAccessToken: !!process.env.FB_PAGE_ACCESS_TOKEN,
        hasAppSecret: !!process.env.FB_APP_SECRET,
        hasCatalogToken: !!process.env.FB_CATALOG_ACCESS_TOKEN,
        webhookUrl: "/api/facebook/webhook",
        verifyToken: process.env.FB_VERIFY_TOKEN || "",
      };
    }),
  }),

  // ===========================================================================
  // System Settings (系统设置)
  // ===========================================================================
  settings: router({
    // Company profile & system settings
    get: adminProcedure.query(async () => {
      return await db.getSystemSettings();
    }),
    update: adminProcedure.input(z.object({
      companyName: z.string().nullable().optional(),
      companyLogoUrl: z.string().nullable().optional(),
      companyAddress: z.string().nullable().optional(),
      companyPhone: z.string().nullable().optional(),
      companyEmail: z.string().nullable().optional(),
      companyWebsite: z.string().nullable().optional(),
      businessRegNo: z.string().nullable().optional(),
      defaultShipFromAddress: z.string().nullable().optional(),
      defaultShipFromPhone: z.string().nullable().optional(),
      defaultShipFromName: z.string().nullable().optional(),
      defaultShipFromPostcode: z.string().nullable().optional(),
      defaultShipFromState: z.string().nullable().optional(),
      defaultShipFromCity: z.string().nullable().optional(),
      currency: z.string().optional(),
      timezone: z.string().optional(),
      orderPrefix: z.string().optional(),
      localOrderPrefix: z.string().optional(),
      importOrderPrefix: z.string().optional(),
      orderNumberPadding: z.number().optional(),
      poPrefix: z.string().optional(),
      poNumberPadding: z.number().optional(),
      customerPrefix: z.string().optional(),
      customerNumberPadding: z.number().optional(),
      skuPrefix: z.string().optional(),
      skuNumberPadding: z.number().optional(),
      notifyOnNewOrder: z.boolean().optional(),
      notifyOnPayment: z.boolean().optional(),
      notifyOnShipment: z.boolean().optional(),
      notifyEmail: z.string().nullable().optional(),
      requireStaffLogin: z.boolean().optional(),
      autoCompleteDays: z.number().optional(),
      liveCommentFooter: z.string().nullable().optional(),
      checkoutMessageTemplate: z.string().nullable().optional(),
      liveWinNoticeTemplate: z.string().nullable().optional(),
    })).mutation(async ({ input }) => {
      return await db.updateSystemSettings(input);
    }),
  }),

  // ===========================================================================
  // Shipping Rules (运费规则)
  // ===========================================================================
  shippingRules: router({
    checkoutConfiguration: publicProcedure.query(async () => {
      return await db.getControlledShippingConfiguration();
    }),
    controlled: adminProcedure.query(async () => {
      return await db.getControlledShippingConfiguration();
    }),
    updateControlled: adminProcedure.input(z.object({
      westMalaysia: z.object({
        freeShippingThreshold: z.number().nonnegative(),
        includedWeightKg: z.number().positive(),
        baseFeeBelowThreshold: z.number().nonnegative(),
        additionalKgFee: z.number().nonnegative(),
      }),
      eastMalaysiaPosLaju: z.object({
        checkoutPrepaidFee: z.number().nonnegative(),
        settlementNote: z.string().min(1).max(500),
      }),
      eastMalaysiaShopee: z.object({
        checkoutPrepaidFee: z.number().nonnegative(),
        settlementNote: z.string().min(1).max(500),
      }),
      lalamove: z.object({
        companyBearingFee: z.number().nonnegative(),
        settlementNote: z.string().min(1).max(500),
      }),
    })).mutation(async ({ input, ctx }) => {
      return await db.updateControlledShippingConfiguration(input, ctx.user.name ?? ctx.user.openId);
    }),
    list: adminProcedure.query(async () => {
      return await db.getShippingRules();
    }),
    update: adminProcedure.input(z.object({
      id: z.number(),
      displayName: z.string().optional(),
      freeShippingThreshold: z.number().nullable().optional(),
      freeShippingMaxWeight: z.number().nullable().optional(),
      additionalKgPrice: z.number().nullable().optional(),
      defaultCourier: z.string().nullable().optional(),
      maxCalculateWeight: z.number().nullable().optional(),
      specialInstruction: z.string().nullable().optional(),
      isEnabled: z.boolean().optional(),
      sortOrder: z.number().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateShippingRule(id, data);
    }),
    create: adminProcedure.input(z.object({
      zone: z.enum(["west_malaysia", "east_malaysia", "self_pickup", "lalamove"]),
      displayName: z.string(),
      freeShippingThreshold: z.number().nullable().optional(),
      freeShippingMaxWeight: z.number().nullable().optional(),
      additionalKgPrice: z.number().nullable().optional(),
      defaultCourier: z.string().nullable().optional(),
      maxCalculateWeight: z.number().nullable().optional(),
      specialInstruction: z.string().nullable().optional(),
      isEnabled: z.boolean().optional(),
      sortOrder: z.number().optional(),
    })).mutation(async ({ input }) => {
      return await db.createShippingRule(input);
    }),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteShippingRule(input.id);
      return { success: true };
    }),
  }),

  // ===========================================================================
  // Shipping Providers (物流供应商)
  // ===========================================================================
  shippingProviders: router({
    list: adminProcedure.query(async () => {
      const providers = await db.getShippingProviders();
      // Don't expose credentials to frontend
      return providers.map(p => ({
        ...p,
        credentials: undefined,
      }));
    }),
    update: adminProcedure.input(z.object({
      providerKey: z.string(),
      isEnabled: z.boolean().optional(),
      environment: z.enum(["sandbox", "production"]).optional(),
      supportedCouriers: z.string().optional(),
    })).mutation(async ({ input }) => {
      const { providerKey, ...data } = input;
      return await db.updateShippingProvider(providerKey, data);
    }),
    // Test connection for a provider
    testConnection: adminProcedure.input(z.object({
      providerKey: z.string(),
    })).mutation(async ({ input }) => {
      if (input.providerKey === "parceldaily") {
        if (!parceldaily.isParcelDailyConfigured()) {
          return { success: false, error: "ParcelDaily credentials not configured" };
        }
        try {
          const info = await parceldaily.checkAccountInfo();
          if (info.data) {
            // Update balance in DB
            await db.updateShippingProvider("parceldaily", {
              accountBalance: info.data.credit.toString() as any,
              lastSyncAt: new Date() as any,
            });
            return {
              success: true,
              balance: info.data.credit,
              package: info.data.topupPackage,
              expiresIn: info.data.expiresIn,
            };
          }
          return { success: false, error: info.error?.message || "Unknown error" };
        } catch (error: any) {
          return { success: false, error: error.message };
        }
      }
      return { success: false, error: "Unknown provider" };
    }),
  }),

  // ===========================================================================
  // ParcelDaily Operations (ParcelDaily 物流操作)
  // ===========================================================================
  parceldaily: router({
    // Check account info / balance
    accountInfo: adminProcedure.query(async () => {
      if (!parceldaily.isParcelDailyConfigured()) {
        return { success: false, error: "Not configured" };
      }
      try {
        const info = await parceldaily.checkAccountInfo();
        if (info.data) {
          // Update balance in DB so the UI shows it
          await db.updateShippingProvider("parceldaily", {
            accountBalance: info.data.credit.toString() as any,
            lastSyncAt: new Date() as any,
          });
        }
        return { success: true, data: info.data };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),
    // Check postcode
    checkPostcode: adminProcedure.input(z.object({
      postcode: z.string(),
    })).query(async ({ input }) => {
      try {
        const result = await parceldaily.checkPostcode(input.postcode);
        return { success: true, data: result.success };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),
    // Get shipping quote
    getQuote: adminProcedure.input(z.object({
      fromPostcode: z.string(),
      toPostcode: z.string(),
      weightKg: z.number(),
    })).query(async ({ input }) => {
      try {
        const quote = await parceldaily.getQuote({
          fromPostcode: input.fromPostcode,
          toPostcode: input.toPostcode,
          kg: input.weightKg,
        });
        const couriers = parceldaily.extractCourierPrices(quote);
        return { success: true, couriers, raw: quote.success };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),
    // Create shipment for an order
    createShipment: adminProcedure.input(z.object({
      orderId: z.number(),
      courier: z.string(),
      weightKg: z.number(),
      price: z.number().optional(),
    })).mutation(async ({ input, ctx }) => {
      try {
        // Get order details
        const order = await db.getOrderById(input.orderId);
        if (!order) throw new Error("Order not found");

        // Get customer details for delivery address
        const customer = await db.getCustomerById(order.customerId);
        if (!customer) throw new Error("Customer not found");

        // Get system settings for pickup address
        const settings = await db.getSystemSettings();
        if (!settings?.defaultShipFromPostcode) {
          throw new Error("Default shipping address not configured in system settings");
        }

        const pickupAddress = {
          fullName: settings.defaultShipFromName || settings.companyName || "Sender",
          phone: settings.defaultShipFromPhone || "",
          line1: settings.defaultShipFromAddress || "",
          city: settings.defaultShipFromCity || "",
          postcode: settings.defaultShipFromPostcode,
          state: settings.defaultShipFromState || "",
          country: "Malaysia",
        };

        const deliveryAddress = {
          fullName: customer.name || customer.facebookName || "Recipient",
          phone: customer.phoneNumber || "",
          line1: customer.address || order.shippingAddress || "",
          city: customer.city || "",
          postcode: customer.postalCode || "",
          state: customer.state || "",
          country: customer.country || "Malaysia",
        };

        const result = await shippingProvider.parcelDailyProvider.createShipment({
          courier: input.courier,
          pickupAddress,
          deliveryAddress,
          weightKg: input.weightKg,
          price: input.price || 0,
          content: "Goods",
          contentValue: parseFloat(order.totalAmount?.toString() || "0"),
          reference: order.orderNumber,
        });

        // Save shipment record
        const shipment = await db.createShipment({
          orderId: input.orderId,
          providerKey: "parceldaily",
          courier: input.courier,
          providerOrderId: result.providerOrderId,
          actualWeight: input.weightKg.toString() as any,
          status: "created",
          rawResponse: JSON.stringify(result.rawResponse),
        });

        return { success: true, shipment };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),
    // Checkout shipment (pay and get tracking number)
    checkoutShipment: adminProcedure.input(z.object({
      shipmentId: z.number(),
    })).mutation(async ({ input }) => {
      try {
        // Get shipment from DB by ID - use a direct query
        const dbAny = db as any;
        const shipment = await dbAny.getShipmentById?.(input.shipmentId);
        if (!shipment) {
          throw new Error("Shipment not found");
        }

        const result = await shippingProvider.parcelDailyProvider.checkoutShipment(shipment.providerOrderId);

        // Update shipment with tracking number
        const updated = await db.updateShipment(input.shipmentId, {
          trackingNumber: result.trackingNumber,
          consignmentNoteUrl: result.consignmentNoteUrl || null,
          shippingCost: result.shippingCost.toString() as any,
          status: "checked_out",
          checkedOutAt: new Date() as any,
        });

        // Update order status to shipped
        await db.updateOrderStatus(shipment.orderId, {
          physicalStatus: "shipped",
          trackingNumber: result.trackingNumber,
          courierCompany: shipment.courier,
        });

        return { success: true, shipment: updated, trackingNumber: result.trackingNumber };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),
    // Get consignment note URL
    getConsignmentNote: adminProcedure.input(z.object({
      shipmentId: z.number(),
    })).query(async ({ input }) => {
      try {
        const dbAny2 = db as any;
        const shipment = await dbAny2.getShipmentById?.(input.shipmentId);
        if (!shipment) throw new Error("Shipment not found");

        const result = await parceldaily.getConsignmentNote(shipment.providerOrderId);
        return { success: true, url: result.url };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),
  }),

  // ===========================================================================
  // ParcelKing Operations (Parcel King 物流操作)
  // ===========================================================================
  parcelking: router({
    // Check if ParcelKing is configured
    isConfigured: adminProcedure.query(async () => {
      return { configured: parcelking.isParcelKingConfigured(), testMode: parcelking.isTestMode() };
    }),

    // Get e-wallet balance
    getBalance: adminProcedure.query(async () => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const balance = await parcelking.getBalance();
        return { success: true, balance: balance.result.balance, currency: balance.result.currency };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    // List available courier services
    getServices: adminProcedure.query(async () => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured", services: [] };
      }
      try {
        const services = await parcelking.getServices();
        return { success: true, services };
      } catch (error: any) {
        return { success: false, error: error.message, services: [] };
      }
    }),

    // Query shipping prices
    priceQuery: adminProcedure.input(z.object({
      fromPostcode: z.string(),
      toPostcode: z.string(),
      weightKg: z.number(),
      parcelValue: z.number().optional(),
    })).query(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured", services: [] };
      }
      try {
        const result = await parcelking.priceQuery({
          from_postcode: input.fromPostcode,
          to_postcode: input.toPostcode,
          parcel_weight_kg: input.weightKg,
          parcel_value: input.parcelValue,
        });
        return { success: true, services: result.services, weightUsedKg: result.weightUsedKg, totalParcels: result.totalParcels, isMps: result.isMps };
      } catch (error: any) {
        return { success: false, error: error.message, services: [] };
      }
    }),

    // Create a shipment for a specific package (auto tracking + label)
    createShipment: adminProcedure.input(z.object({
      orderId: z.number(),
      serviceId: z.number(),
      weightKg: z.number(),
      content: z.string().optional(),
      contentValue: z.number().optional(),
      handoverMethod: z.enum(["pickup", "dropoff"]).optional(),
      pickupTime: z.number().optional(),
      pickupTimeRangeId: z.number().optional(),
    })).mutation(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Parcel King API key not configured" });
      }
      try {
        // Get order + customer + system settings for addresses
        const order = await db.getOrderById(input.orderId);
        if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在" });

        const settings = await db.getSystemSettings();
        if (!settings || !settings.defaultShipFromAddress) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "系统设置中缺少发货地址，请先在系统设置中填写默认发货地址" });
        }

        const customer = await db.getCustomerById(order.customerId);
        if (!customer) throw new TRPCError({ code: "NOT_FOUND", message: "客户不存在" });

        const senderPhone = parcelking.normalizePhone(settings.defaultShipFromPhone || settings.companyPhone || "");
        const recipientPhone = parcelking.normalizePhone(customer.phoneNumber || "");

        const response = await parcelking.createOrder({
          service_id: input.serviceId,
          sender: {
            name: settings.defaultShipFromName || settings.companyName || "Store",
            phone: settings.defaultShipFromPhone || settings.companyPhone || "",
            dial_code: senderPhone.dial_code,
            mobile: senderPhone.mobile,
            line1: settings.defaultShipFromAddress || settings.companyAddress || "",
            city: settings.defaultShipFromCity || "",
            postcode: settings.defaultShipFromPostcode || "",
            state: settings.defaultShipFromState || "",
            country: "Malaysia",
          },
          recipient: {
            name: customer.name || customer.displayName || "Customer",
            phone: customer.phoneNumber || "",
            dial_code: recipientPhone.dial_code,
            mobile: recipientPhone.mobile,
            line1: order.shippingAddress || customer.address || "",
            city: customer.city || "",
            postcode: customer.postalCode || "",
            state: customer.state || "",
            country: "Malaysia",
          },
          parcel: {
            weight_kg: input.weightKg,
            name: input.content || "Goods",
            declared_value: input.contentValue,
          },
          delivery_options: input.handoverMethod ? {
            handover_method: input.handoverMethod,
            pickup_time: input.pickupTime,
            pickup_time_range_id: input.pickupTimeRangeId,
          } : undefined,
          reference: order.orderNumber,
        });

        const trackingNo = response.result.tracking_no;
        const labelUrl = response.result.label_url || null;
        const shippingCost = response.result.final_amount || 0;

        return {
          success: true,
          trackingNumber: trackingNo,
          labelUrl,
          shippingCost,
          testMode: response.result.test_mode,
        };
      } catch (error: any) {
        if (error instanceof ParcelKingError) {
          throw new TRPCError({
            code: error.statusCode >= 500 ? "INTERNAL_SERVER_ERROR" : "BAD_REQUEST",
            message: error.message,
          });
        }
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: error.message });
      }
    }),

    // Get order details / tracking from ParcelKing
    getOrderDetails: adminProcedure.input(z.object({
      trackingNo: z.string(),
    })).query(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const details = await parcelking.getOrderDetails(input.trackingNo);
        return { success: true, details: details.result };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    // Get live tracking timeline
    getTracking: adminProcedure.input(z.object({
      trackingNo: z.string(),
    })).query(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const tracking = await parcelking.getTracking(input.trackingNo);
        return { success: true, tracking: tracking.result };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    // Cancel an order
    cancelOrder: adminProcedure.input(z.object({
      trackingNo: z.string(),
    })).mutation(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const result = await parcelking.cancelOrder(input.trackingNo);
        return { success: true, result: result.result };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    // Re-download shipping label
    downloadLabel: adminProcedure.input(z.object({
      trackingNo: z.string(),
    })).query(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const url = await parcelking.getShippingLabelUrl(input.trackingNo);
        return { success: true, url };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    // Re-sync tracking status from ParcelKing
    resyncTracking: adminProcedure.input(z.object({
      trackingNo: z.string(),
      packageId: z.number(),
    })).mutation(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const tracking = await parcelking.getTracking(input.trackingNo);
        const timeline = tracking.result.timeline || [];
        const latest = timeline[timeline.length - 1];

        // Update package status based on tracking events
        let newStatus = "shipped";
        if (latest?.description?.toLowerCase().includes("deliver")) {
          newStatus = "delivered";
        }

        const dbAny = db as any;
        if (dbAny.updatePackageStatus) {
          await dbAny.updatePackageStatus(input.packageId, newStatus);
        }

        return { success: true, timeline, latestEvent: latest, newStatus };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    // Get SPX pickup slots
    getSpxPickupSlots: adminProcedure.query(async () => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured", slots: [] };
      }
      try {
        const slots = await parcelking.getSpxPickupSlots();
        return { success: true, slots };
      } catch (error: any) {
        return { success: false, error: error.message, slots: [] };
      }
    }),
  }),

  // ===========================================================================
  // Payment Methods (付款方式设定)
  // ===========================================================================
  paymentMethods: router({
    list: adminProcedure.query(async () => {
      return await db.getPaymentMethods(true);
    }),
    
    listEnabled: publicProcedure.query(async () => {
      return await db.getPaymentMethods(false);
    }),
    
    getById: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getPaymentMethodById(input.id);
    }),
    
    create: adminProcedure.input(z.object({
      name: z.string(),
      type: z.enum(["qr_code", "bank_transfer", "cash", "other"]),
      qrImageUrl: z.string().optional(),
      bankName: z.string().optional(),
      accountHolder: z.string().optional(),
      accountNumber: z.string().optional(),
      paymentInstruction: z.string().optional(),
      remark: z.string().optional(),
      isEnabled: z.boolean().default(true),
      displayOrder: z.number().default(0),
    })).mutation(async ({ input }) => {
      return await db.createPaymentMethod(input);
    }),
    
    update: adminProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(),
      type: z.enum(["qr_code", "bank_transfer", "cash", "other"]).optional(),
      qrImageUrl: z.string().nullable().optional(),
      bankName: z.string().nullable().optional(),
      accountHolder: z.string().nullable().optional(),
      accountNumber: z.string().nullable().optional(),
      paymentInstruction: z.string().nullable().optional(),
      remark: z.string().nullable().optional(),
      isEnabled: z.boolean().optional(),
      displayOrder: z.number().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updatePaymentMethod(id, data);
    }),
    
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deletePaymentMethod(input.id);
      return { success: true };
    }),
  }),

  // ===========================================================================
  // Order Status Workflow (订单状态流转)
  // ===========================================================================
  orderWorkflow: router({
    getStatusLogs: adminProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getOrderStatusLogs(input.orderId);
    }),
    
    transition: adminProcedure.input(z.object({
      orderId: z.number(),
      toStatus: z.enum(["pending", "receipt_uploaded", "partial_payment", "hold_order", "packing", "shipped", "partial_shipped", "completed", "cancelled"]),
      notes: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const changedBy = ctx.user?.name || ctx.user?.openId || "admin";
      const result = await db.transitionOrderStatus(input.orderId, input.toStatus, changedBy, input.notes);
      return result;
    }),
    
    confirmPayment: adminProcedure.input(z.object({
      orderId: z.number(),
      hasHoldOrder: z.boolean(),
      notes: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const changedBy = ctx.user?.name || ctx.user?.openId || "admin";
      const toStatus = input.hasHoldOrder ? "hold_order" : "packing";
      const result = await db.transitionOrderStatus(input.orderId, toStatus, changedBy, input.notes || "Payment confirmed");
      return result;
    }),
  }),

  // ===========================================================================
  // Hold Orders (保留订单)
  // ===========================================================================
  holdOrders: router({
    getInfo: adminProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getHoldOrderInfo(input.orderId);
    }),
    
    getActiveByCustomer: adminProcedure.input(z.object({ customerId: z.number() })).query(async ({ input }) => {
      return await db.getActiveHoldOrdersByCustomer(input.customerId);
    }),
    
    create: adminProcedure.input(z.object({
      orderId: z.number(),
      holdType: z.enum(["wait_next_live", "scheduled_shipping", "wait_stock", "other"]),
      scheduledShippingDate: z.number().optional(),
      allowAutoMerge: z.boolean().default(true),
      holdRemark: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const holdBy = ctx.user?.name || ctx.user?.openId || "admin";
      const holdOrder = await db.createHoldOrderInfo({
        orderId: input.orderId,
        holdType: input.holdType,
        scheduledShippingDate: input.scheduledShippingDate ? new Date(input.scheduledShippingDate) : null,
        allowAutoMerge: input.allowAutoMerge,
        holdRemark: input.holdRemark || null,
        holdBy,
      });
      await db.transitionOrderStatus(input.orderId, "hold_order", holdBy, "Hold order created");
      return holdOrder;
    }),
    
    release: adminProcedure.input(z.object({
      orderId: z.number(),
    })).mutation(async ({ input, ctx }) => {
      const releasedBy = ctx.user?.name || ctx.user?.openId || "admin";
      await db.releaseHoldOrder(input.orderId, releasedBy);
      // Transition to packing
      await db.transitionOrderStatus(input.orderId, "packing", releasedBy, "Hold released");
      return { success: true };
    }),
    
    findMergeable: adminProcedure.input(z.object({ customerId: z.number() })).query(async ({ input }) => {
      return await db.findMergeableHoldOrder(input.customerId);
    }),
  }),

  // ===========================================================================
  // Notification Logs (通知记录)
  // ===========================================================================
  notifications: router({
    list: adminProcedure.input(z.object({ orderId: z.number().optional() })).query(async ({ input }) => {
      return await db.getNotificationLogs(input.orderId);
    }),
    
    create: adminProcedure.input(z.object({
      orderId: z.number().optional(),
      customerId: z.number().optional(),
      type: z.string(),
      channel: z.enum(["messenger", "whatsapp", "email", "system"]).default("messenger"),
      message: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.createNotificationLog(input);
    }),
    aiCenter: adminProcedure.query(async () => {
      return await db.getAiNotificationCenter();
    }),
    handleAiFailure: adminProcedure.input(z.object({
      notificationLogId: z.number().int().positive(),
      action: z.enum(["manual_sent", "resolved", "ignored"]),
      note: z.string().max(1000).optional(),
    })).mutation(async ({ input, ctx }) => {
      return await db.handleAiNotificationFailure({ ...input, handledBy: ctx.user.name || ctx.user.email || "Admin" });
    }),
  }),

  // ===========================================================================
  // Mall Admin (商城管理 - Admin)
  // ===========================================================================
  mallAdmin: router({
    // Settings
    getSettings: adminProcedure.query(async () => {
      return await db.getMallSettings() || await db.createMallSettingsIfNotExists();
    }),
    updateSettings: adminProcedure.input(z.object({
      id: z.number(),
      shopName: z.string().optional(),
      domain: z.string().nullable().optional(),
      logoUrl: z.string().nullable().optional(),
      faviconUrl: z.string().nullable().optional(),
      slogan: z.string().nullable().optional(),
      seoTitle: z.string().nullable().optional(),
      seoDescription: z.string().nullable().optional(),
      facebookPixel: z.string().nullable().optional(),
      googleAnalytics: z.string().nullable().optional(),
      shippingPolicy: z.string().nullable().optional(),
      refundPolicy: z.string().nullable().optional(),
      serviceTerms: z.string().nullable().optional(),
      companyName: z.string().nullable().optional(),
      phone: z.string().nullable().optional(),
      whatsapp: z.string().nullable().optional(),
      email: z.string().nullable().optional(),
      facebook: z.string().nullable().optional(),
      address: z.string().nullable().optional(),
      wazeLink: z.string().nullable().optional(),
      googleMapLink: z.string().nullable().optional(),
      activeTheme: z.string().optional(),
      customThemeColors: z.any().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateMallSettings(id, data);
    }),

    // Banners
    listBanners: adminProcedure.input(z.object({ type: z.string().optional() })).query(async ({ input }) => {
      return await db.getMallBanners(input.type);
    }),
    createBanner: adminProcedure.input(z.object({
      type: z.enum(["home_16x9", "home_9x16", "home_1x1", "marketing_16x9", "marketing_1x1", "marketing_9x16"]),
      imageUrl: z.string(),
      linkUrl: z.string().optional(),
      displayOrder: z.number().default(0),
      startDate: z.number().optional(),
      endDate: z.number().optional(),
      isEnabled: z.boolean().default(true),
    })).mutation(async ({ input }) => {
      return await db.createMallBanner({
        ...input,
        startDate: input.startDate ? new Date(input.startDate) : null,
        endDate: input.endDate ? new Date(input.endDate) : null,
      });
    }),
    updateBanner: adminProcedure.input(z.object({
      id: z.number(),
      imageUrl: z.string().optional(),
      linkUrl: z.string().nullable().optional(),
      displayOrder: z.number().optional(),
      startDate: z.number().nullable().optional(),
      endDate: z.number().nullable().optional(),
      isEnabled: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      const cleanData: any = { ...data };
      if (data.startDate !== undefined) cleanData.startDate = data.startDate ? new Date(data.startDate) : null;
      if (data.endDate !== undefined) cleanData.endDate = data.endDate ? new Date(data.endDate) : null;
      await db.updateMallBanner(id, cleanData);
      return { success: true };
    }),
    deleteBanner: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteMallBanner(input.id);
      return { success: true };
    }),

    // Quick Contacts
    listQuickContacts: adminProcedure.query(async () => {
      return await db.getMallQuickContacts();
    }),
    createQuickContact: adminProcedure.input(z.object({
      type: z.enum(["whatsapp", "messenger", "facebook_page", "waze", "google_map"]),
      name: z.string(),
      imageUrl: z.string().optional(),
      linkUrl: z.string(),
      isEnabled: z.boolean().default(true),
      displayOrder: z.number().default(0),
    })).mutation(async ({ input }) => {
      return await db.createMallQuickContact(input);
    }),
    updateQuickContact: adminProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(),
      imageUrl: z.string().nullable().optional(),
      linkUrl: z.string().optional(),
      isEnabled: z.boolean().optional(),
      displayOrder: z.number().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateMallQuickContact(id, data);
      return { success: true };
    }),
    deleteQuickContact: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteMallQuickContact(input.id);
      return { success: true };
    }),

    // Notices
    listNotices: adminProcedure.query(async () => {
      return await db.getMallNotices();
    }),
    createNotice: adminProcedure.input(z.object({
      announcement: z.string(),
      announcementEn: z.string().max(500).optional(),
      isEnabled: z.boolean().default(true),
      displayOrder: z.number().default(0),
    })).mutation(async ({ input }) => {
      return await db.createMallNotice(input);
    }),
    updateNotice: adminProcedure.input(z.object({
      id: z.number(),
      announcement: z.string().optional(),
      announcementEn: z.string().max(500).nullable().optional(),
      isEnabled: z.boolean().optional(),
      displayOrder: z.number().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateMallNotice(id, data);
      return { success: true };
    }),
    deleteNotice: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteMallNotice(input.id);
      return { success: true };
    }),

    // Theme Schedules
    listThemeSchedules: adminProcedure.query(async () => {
      return await db.getMallThemeSchedules();
    }),
    createThemeSchedule: adminProcedure.input(z.object({
      themeKey: z.string(),
      startDate: z.number(),
      endDate: z.number(),
      isEnabled: z.boolean().default(true),
    })).mutation(async ({ input }) => {
      return await db.createMallThemeSchedule({
        ...input,
        startDate: new Date(input.startDate),
        endDate: new Date(input.endDate),
      });
    }),
    deleteThemeSchedule: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteMallThemeSchedule(input.id);
      return { success: true };
    }),

    // Product Detail Images
    listDetailImages: adminProcedure.input(z.object({ productId: z.number() })).query(async ({ input }) => {
      return await db.getMallProductDetailImages(input.productId);
    }),
    createDetailImage: adminProcedure.input(z.object({
      productId: z.number(),
      imageUrl: z.string(),
      displayOrder: z.number().default(0),
    })).mutation(async ({ input }) => {
      return await db.createMallProductDetailImage(input);
    }),
    deleteDetailImage: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteMallProductDetailImage(input.id);
      return { success: true };
    }),

    // Product Mall Sync
    updateProductSync: adminProcedure.input(z.object({
      productId: z.number(),
      syncToMall: z.boolean(),
    })).mutation(async ({ input }) => {
      await db.updateProductMallSync(input.productId, input.syncToMall);
      return { success: true };
    }),
  }),

  // ===========================================================================
  // Mall Public (商城公开接口)
  // ===========================================================================
  mall: router({
    // Get mall settings (public)
    settings: publicProcedure.query(async () => {
      const settings = await db.getMallSettings() || await db.createMallSettingsIfNotExists();
      const companySettings = await db.getSystemSettings();
      // Don't expose analytics/pixel IDs to public
      const { facebookPixel, googleAnalytics, ...publicSettings } = settings as any;
      return { ...publicSettings, logoUrl: getCompanyLogoUrl(companySettings) };
    }),

    // Get enabled banners (public)
    banners: publicProcedure.input(z.object({ type: z.string().optional() })).query(async ({ input }) => {
      return await db.getEnabledMallBanners(input.type);
    }),

    // Get enabled quick contacts (public)
    quickContacts: publicProcedure.query(async () => {
      return await db.getEnabledMallQuickContacts();
    }),

    // Get enabled notices (public)
    notices: publicProcedure.query(async () => {
      return await db.getEnabledMallNotices();
    }),

    // Get mall categories (public)
    categories: publicProcedure.query(async () => {
      return await db.getMallCategories();
    }),

    // Get mall products (public)
    products: publicProcedure.input(z.object({
      categoryId: z.number().optional(),
      search: z.string().optional(),
    })).query(async ({ input }) => {
      return await db.getMallProducts(input);
    }),

    // Get mall product detail (public)
    productDetail: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const product = await db.getMallProductById(input.id);
      if (!product) throw new Error("Product not found");
      const [productVariants, productImgs, detailImgs] = await Promise.all([
        db.getMallProductVariants(input.id),
        db.getMallProductImages(input.id),
        db.getMallProductDetailImages(input.id),
      ]);
      return {
        ...product,
        variants: productVariants,
        images: productImgs,
        detailImages: detailImgs,
      };
    }),

    // Checkout (public - guest checkout)
    checkout: publicProcedure.input(z.object({
      customerName: z.string(),
      contactNumber: z.string(),
      whatsappNumber: z.string().optional(),
      email: z.string().optional(),
      addressLine1: z.string(),
      addressLine2: z.string().optional(),
      postcode: z.string(),
      city: z.string(),
      state: z.string(),
      area: z.string(),
      deliveryRemark: z.string().optional(),
      shippingMethod: z.enum(["west_malaysia", "east_malaysia", "east_malaysia_poslaju", "east_malaysia_shopee", "lalamove", "self_pickup"]),
      items: z.array(z.object({
        productId: z.number(),
        bundleId: z.number().int().positive().optional(),
        productName: z.string(),
        productSku: z.string().optional(),
        variationId: z.number().optional(),
        variationName: z.string().optional(),
        productType: z.enum(["physical", "membership", "gift"]).optional(),
        facebookKeyword: z.string().optional(),
        quantity: z.number().min(1),
        unitPrice: z.string(),
        subtotal: z.string(),
        discount: z.string().optional(),
        isSpecial: z.boolean().optional(),
        isStandalone: z.boolean().optional(),
      })),
      paymentMethodId: z.number().optional(),
      paymentMethodName: z.string().optional(),
      mergeIntoOrderId: z.number().optional(),
      repotPairs: z.array(z.object({
        plantProductId: z.number(),
        plantName: z.string(),
        potProductId: z.number(),
        potName: z.string(),
        quantity: z.number().min(1),
      })).optional(),
      customerRemark: z.string().optional(),
    })).mutation(async ({ input }) => {
      try {
        return await db.mallCheckout(input);
      } catch (error) {
        if (error instanceof Error && error.message === "Selected hold order is no longer available for this customer") {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "该保留订单不可合并或不属于当前客户",
          });
        }
        throw error;
      }
    }),

    // 客户从专属结单链接进入商城后的安全加单接口。
    addToSecureOrder: publicProcedure.input(z.object({
      orderNumber: z.string().min(1).max(50),
      token: z.string().min(1).max(128),
      items: z.array(z.object({
        productId: z.number().int().positive(),
        variationId: z.number().int().positive().optional(),
        quantity: z.number().int().min(1).max(99),
      })).min(1),
    })).mutation(async ({ input }) => {
      const order = await db.getOrderBySecureToken(input.orderNumber, input.token);
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在或链接无效" });
      // 与服务层同一白名单：待包货／待备货尚未履约，可继续加单；
      // 已部分发货、已发货、完成、取消及其他关闭状态不可绕过此入口。
      const mergeableStatuses = ["pending", "receipt_uploaded", "hold_order", "partial_payment", "packing"];
      if (!mergeableStatuses.includes(order.physicalStatus || "pending")) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "当前订单状态不允许加单" });
      }

      const checkedItems = await Promise.all(input.items.map(async (item) => {
        const product = await db.getMallProductById(item.productId);
        if (!product || product.status !== "active") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "商品已下架，无法加入订单" });
        }
        let variation: any;
        if (item.variationId) {
          const variants = await db.getMallProductVariants(item.productId);
          variation = variants.find((v: any) => v.id === item.variationId && v.status === "active");
          if (!variation) throw new TRPCError({ code: "BAD_REQUEST", message: "所选商品规格已不可用" });
          if (Number(variation.stockQuantity || 0) < item.quantity) {
            throw new TRPCError({ code: "BAD_REQUEST", message: `${product.name} 库存不足` });
          }
        } else if (!product.isPreOrder && Number(product.stockQuantity || 0) < item.quantity) {
          throw new TRPCError({ code: "BAD_REQUEST", message: `${product.name} 库存不足` });
        }

        const basePrice = variation?.sellingPrice
          ?? ((product.isSpecial || product.isSpecialItem) && product.specialPrice ? product.specialPrice : product.sellingPrice)
          ?? product.regularPrice
          ?? "0.00";
        const price = Number(basePrice).toFixed(2);
        return {
          productId: product.id,
          productName: product.name,
          productSku: variation?.sku || product.sku,
          variationId: variation?.id,
          variationName: variation?.name,
          facebookKeyword: variation?.keyword || product.keyword,
          quantity: item.quantity,
          unitPrice: price,
          subtotal: (Number(price) * item.quantity).toFixed(2),
          isSpecial: Boolean(product.isSpecial || product.isSpecialItem),
        };
      }));

      return await db.addMallItemsToOrder(order.id, checkedItems);
    }),

    // Smart Paste (public)
    smartPaste: publicProcedure.input(z.object({ text: z.string() })).query(async ({ input }) => {
      return db.parseSmartPaste(input.text);
    }),

    // Order query (public - guest)
    queryOrder: publicProcedure.input(z.object({
      orderNumber: z.string(),
      contactNumber: z.string(),
    })).query(async ({ input }) => {
      const order = await db.queryOrderByNumber(input.orderNumber, input.contactNumber);
      if (!order) return null;
      const items = await db.getOrderItems(order.id);
      // Don't expose internal fields
      return {
        orderNumber: order.orderNumber,
        physicalStatus: order.physicalStatus,
        totalAmount: order.totalAmount,
        paidAmount: order.paidAmount,
        shippingMethod: order.shippingMethod,
        trackingNumber: order.trackingNumber,
        createdAt: order.createdAt,
        items: items.map((i: any) => ({
          productName: i.productName,
          variationName: i.variationName,
          quantity: i.quantity,
          unitPrice: i.unitPrice,
          subtotal: i.subtotal,
        })),
      };
    }),

    // Upload payment receipt (public - guest)
    uploadReceipt: publicProcedure.input(z.object({
      orderNumber: z.string().min(1).max(50),
      contactNumber: z.string().min(1).max(50),
      receiptUrl: z.string().min(1).max(500),
      paymentMethodId: z.number().int().positive(),
    })).mutation(async ({ input }) => {

      const dbConn = await db.getDb();
      if (!dbConn) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "数据库暂时不可用" });
      const { orders: ordTable, customers: custTable } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const result = await dbConn.select().from(ordTable).where(eq(ordTable.orderNumber, input.orderNumber)).limit(1);
      if (result.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在或联系电话不匹配" });
      }

      const customerResult = await dbConn.select().from(custTable).where(eq(custTable.id, result[0].customerId)).limit(1);
      if (customerResult.length === 0 || customerResult[0].phoneNumber !== input.contactNumber) {
        throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在或联系电话不匹配" });
      }

      try { await assertReceiptBelongsToOrder(input.receiptUrl, result[0].id); }
      catch { throw new TRPCError({ code: "BAD_REQUEST", message: "付款凭证与订单不匹配" }); }

      const paymentMethod = await db.getPaymentMethodById(input.paymentMethodId);
      if (!paymentMethod?.isEnabled) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "请选择有效的付款方式" });
      }

      const permittedStatuses = ["pending", "receipt_uploaded", "partial_payment"];
      if (!permittedStatuses.includes(result[0].physicalStatus || "")) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "当前订单状态不允许上传付款凭证" });
      }

      // Check if this is a partial payment by comparing order total with any existing payments
      const { orderPayments: opTable } = await import("../drizzle/schema");
      let newStatus = "receipt_uploaded";
      let totalPaidStr = "0";
      try {
        const existingPayments = await dbConn.select().from(opTable).where(eq(opTable.orderId, result[0].id));
        if (Array.isArray(existingPayments) && existingPayments.length > 0) {
          const totalPaid = existingPayments.reduce((sum, p) => sum + parseFloat(String(p.amount)), 0);
          const totalAmount = parseFloat(String(result[0].totalAmount || "0"));
          totalPaidStr = totalPaid.toFixed(2);
          newStatus = totalPaid >= totalAmount ? "receipt_uploaded" : "partial_payment";
        }
      } catch {
        // If query fails (e.g. no existing payments), default to receipt_uploaded
      }
      await db.transitionOrderStatus(result[0].id, newStatus, "商城顾客", "顾客已上传付款凭证");
      await db.updateOrderStatus(result[0].id, {
        receiptUrl: input.receiptUrl,
        paymentMethodId: paymentMethod.id,
        paymentMethodName: paymentMethod.name,
        paidAmount: totalPaidStr,
      });
      return { success: true };
    }),

    // Find mergeable hold orders by customer phone (public)
    findMergeableOrders: publicProcedure.input(z.object({
      contactNumber: z.string(),
    })).query(async ({ input }) => {
      // Find customer by phone
      const dbConn = await db.getDb();
      if (!dbConn) return [];
      const { customers: custTable, holdOrderInfos: holdTable, orders: ordTable } = await import("../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      const customerResult = await dbConn.select().from(custTable).where(eq(custTable.phoneNumber, input.contactNumber)).limit(1);
      if (customerResult.length === 0) return [];
      const customerId = customerResult[0].id;
      return await db.getActiveHoldOrdersByCustomer(customerId);
    }),
  }),

  // ===========================================================================
  // Packing & Shipping (包货发货)
  // ===========================================================================
  packing: router({
    // Get orders by packing status
    // V2.1.26: Support both local and import order statuses
    list: shippingProcedure.input(z.object({
      status: z.enum(["packing", "shipped", "partial_shipped", "completed"]),
    })).query(async ({ input }) => {
      return await db.getPackingOrders(input.status);
    }),
    
    // Get packing detail
    detail: shippingProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getPackingDetail(input.orderId);
    }),
    
    // Get A5 packing slip data
    slipData: shippingProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getPackingSlipData(input.orderId);
    }),

    // Per-order-item dispatched and remaining quantities. package_items is the
    // source of truth, so this stays correct for both ordinary and merged AWBs.
    fulfilmentSummary: shippingProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getOrderFulfilmentSummary(input.orderId);
    }),

    // Only exposes compatible orders (same recipient and shipping method) and
    // their remaining quantities for a single shared physical package.
    mergeCandidates: shippingProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getMergeShippingCandidates(input.orderId);
    }),
  }),
  
  shipping: router({
    // Full shipping - all items in one or more packages
    fullShip: shippingProcedure.input(z.object({
      orderId: z.number(),
      packages: z.array(z.object({
        courier: z.string(),
        shippingType: z.enum(["auto", "manual"]),
        trackingNumber: z.string().optional(),
        shippingLabelUrl: z.string().optional(),
        providerOrderId: z.string().optional(),
        weight: z.string().optional(),
        shippingCost: z.string().optional(),
      })),
    })).mutation(async ({ input }) => {
      try {
        const result = await db.fullShipping(input.orderId, input.packages);
        await recordManualShipmentNotification(input.orderId, input.packages);
        return result;
      } catch (error) {
        return rethrowPackingShippingError(error);
      }
    }),
    
    // Partial shipping - selected items only
    partialShip: shippingProcedure.input(z.object({
      orderId: z.number(),
      itemIds: z.array(z.number()),
      packageData: z.object({
        courier: z.string(),
        shippingType: z.enum(["auto", "manual"]),
        trackingNumber: z.string().optional(),
        shippingLabelUrl: z.string().optional(),
        providerOrderId: z.string().optional(),
        weight: z.string().optional(),
        shippingCost: z.string().optional(),
      }),
      // V2.1.26补充4: Per-item shipped quantity (Issue 7)
      itemQuantities: z.array(z.object({ itemId: z.string(), quantity: z.number() })).optional(),
    })).mutation(async ({ input }) => {
      try {
        const result = await db.partialShipping(input.orderId, input.itemIds, input.packageData, input.itemQuantities);
        await recordManualShipmentNotification(input.orderId, [input.packageData], true);
        return result;
      } catch (error) {
        return rethrowPackingShippingError(error);
      }
    }),

    // Parcel Daily automatic shipment: create order, checkout, retrieve AWB,
    // persist package/order data, and record the customer shipping notification.
    // This is intentionally the only automatic shipping path used by packing.
    autoShipParcelDaily: shippingProcedure.input(z.object({
      orderId: z.number(),
      actualWeight: z.number().positive(),
      mode: z.enum(["full", "partial"]),
      itemIds: z.array(z.number()).optional(),
      itemQuantities: z.array(z.object({ itemId: z.string(), quantity: z.number().positive() })).optional(),
      packages: z.array(z.object({ weightKg: z.number().positive() })).min(1).optional(),
    })).mutation(async ({ input }) => {
      if (!shippingProvider.parcelDailyProvider.isConfigured) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Parcel Daily API 尚未配置，无法自动生成追踪号码和 AWB" });
      }

      const order = await db.getOrderById(input.orderId);
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在" });
      const customer = await db.getCustomerById(order.customerId);
      const settings = await db.getSystemSettings();
      if (!customer || !settings?.defaultShipFromPostcode) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "请先完成寄件人及客户收件资料，才可自动生成运单" });
      }
      if (!customer.postalCode || !(customer.address || order.shippingAddress)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "客户收件地址或邮编不完整，无法自动生成运单" });
      }

      const isEastMalaysia = order.shippingMethod === "east_malaysia_poslaju";
      const courier = isEastMalaysia ? "poslaju" : "line_clear";
      const pickupAddress = {
        fullName: settings.defaultShipFromName || settings.companyName || "Xintian Nursery",
        phone: settings.defaultShipFromPhone || settings.companyPhone || "",
        line1: settings.defaultShipFromAddress || settings.companyAddress || "",
        city: settings.defaultShipFromCity || "",
        postcode: settings.defaultShipFromPostcode,
        state: settings.defaultShipFromState || "",
        country: "Malaysia",
      };
      const deliveryAddress = {
        fullName: customer.name || customer.facebookName || order.facebookName || "Customer",
        phone: customer.phoneNumber || "",
        line1: customer.address || order.shippingAddress || "",
        city: customer.city || "",
        postcode: customer.postalCode,
        state: customer.state || "",
        country: customer.country || "Malaysia",
      };

      try {
        const requestedPackages = input.packages?.length ? input.packages : [{ weightKg: input.actualWeight }];
        if (input.mode === "partial" && requestedPackages.length > 1) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "部分发货请一次建立一个包裹，避免商品归属不明确" });
        }
        const courierLabel = isEastMalaysia ? "Poslaju" : "Line Clear";
        const shipmentResults = await Promise.all(requestedPackages.map(async (requestedPackage, index) => {
          const created = await shippingProvider.parcelDailyProvider.createShipment({
            courier,
            pickupAddress,
            deliveryAddress,
            weightKg: requestedPackage.weightKg,
            price: Number((order as any).actualShippingFee || 0),
            content: "Plants and garden goods",
            contentValue: Number(order.totalAmount || 0),
            reference: `${order.orderNumber}-${index + 1}`,
          });
          const checkedOut = await shippingProvider.parcelDailyProvider.checkoutShipment(created.providerOrderId);
          const awb = await shippingProvider.parcelDailyProvider.getConsignmentNote?.(created.providerOrderId);
          return {
            courier: courierLabel,
            shippingType: "auto" as const,
            trackingNumber: checkedOut.trackingNumber,
            shippingLabelUrl: awb?.url || checkedOut.consignmentNoteUrl || undefined,
            providerOrderId: created.providerOrderId,
            weight: String(requestedPackage.weightKg),
            shippingCost: Number(checkedOut.shippingCost || 0).toFixed(2),
          };
        }));

        if (input.mode === "partial") {
          if (!input.itemIds?.length) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "部分发货必须选择商品" });
          }
          await db.partialShipping(input.orderId, input.itemIds, shipmentResults[0], input.itemQuantities);
        } else {
          await db.fullShipping(input.orderId, shipmentResults);
        }

        const trackingNumbers = shipmentResults.map((shipment) => shipment.trackingNumber).join("、");
        const shippingMessage = `老板娘/老板您好，我们已为您发货啦，收到包裹如有问题记得48小时内发图/视频给我们哦，追踪号码：${trackingNumbers}，快递公司：${courierLabel}`;
        const notice = await autoNotifyCustomer(input.orderId, shippingMessage, customer.messengerId || undefined, customer.phoneNumber || undefined);
        const noticeStatus = notice.status === "sent" ? "sent" : notice.status === "pending" ? "pending" : "failed";
        await db.updateOrderNotificationStatus(input.orderId, noticeStatus, notice.error || null);
        await db.createNotificationLog({
          orderId: input.orderId,
          customerId: order.customerId,
          type: "shipping_notification",
          channel: normalizeNotificationLogChannel(notice.platform),
          message: shippingMessage,
          status: noticeStatus,
          errorMessage: notice.error || null,
        });

        return {
          success: true,
          courier: courierLabel,
          trackingNumber: trackingNumbers,
          trackingNumbers: shipmentResults.map((shipment) => shipment.trackingNumber),
          shippingLabelUrl: shipmentResults[0]?.shippingLabelUrl || null,
          shippingLabelUrls: shipmentResults.map((shipment) => shipment.shippingLabelUrl).filter(Boolean),
          notificationStatus: noticeStatus,
          notificationError: notice.error || null,
        };
      } catch (error) {
        return rethrowPackingShippingError(error);
      }
    }),
    
    // Get packages for an order
    packages: shippingProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getOrderPackages(input.orderId);
    }),

    // Merge compatible orders into one physical package. Delivery costs are
    // persisted per linked order; no inventory change is made at shipping time.
    mergeShip: shippingProcedure.input(z.object({
      orderIds: z.array(z.number()).min(2),
      itemQuantities: z.array(z.object({ itemId: z.string(), quantity: z.number().int().positive() })).min(1),
      packageData: z.object({
        courier: z.string().min(1),
        shippingType: z.enum(["auto", "manual"]),
        trackingNumber: z.string().optional(),
        shippingLabelUrl: z.string().optional(),
        providerOrderId: z.string().optional(),
        weight: z.string().optional(),
        shippingCost: z.string().optional(),
      }),
    })).mutation(async ({ input }) => {
      try {
        const result = await db.shipMergedOrders(input);
        const primaryOrderId = input.orderIds[0];
        await recordManualShipmentNotification(primaryOrderId, [input.packageData], true);
        return result;
      } catch (error) {
        return rethrowPackingShippingError(error);
      }
    }),
    
    // Create ParcelDaily shipment (auto)
    // Create ParcelKing shipment (auto tracking + label)
    createParcelKing: shippingProcedure.input(z.object({
      orderId: z.number(),
      serviceId: z.number(),
      weightKg: z.number(),
      content: z.string().optional(),
      contentValue: z.number().optional(),
      handoverMethod: z.enum(["pickup", "dropoff"]).optional(),
      pickupTime: z.number().optional(),
      pickupTimeRangeId: z.number().optional(),
      // For partial shipping: which item IDs go in this package
      itemIds: z.array(z.number()).optional(),
      isPartial: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Parcel King API key not configured" });
      }
      try {
        // Get order + customer + system settings
        const order = await db.getOrderById(input.orderId);
        if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在" });

        const settings = await db.getSystemSettings();
        if (!settings || !settings.defaultShipFromAddress) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "系统设置中缺少发货地址" });
        }

        const customer = await db.getCustomerById(order.customerId);
        if (!customer) throw new TRPCError({ code: "NOT_FOUND", message: "客户不存在" });

        const senderPhone = parcelking.normalizePhone(settings.defaultShipFromPhone || settings.companyPhone || "");
        const recipientPhone = parcelking.normalizePhone(customer.phoneNumber || "");

        // Call ParcelKing API to create shipment
        const response = await parcelking.createOrder({
          service_id: input.serviceId,
          sender: {
            name: settings.defaultShipFromName || settings.companyName || "Store",
            phone: settings.defaultShipFromPhone || settings.companyPhone || "",
            dial_code: senderPhone.dial_code,
            mobile: senderPhone.mobile,
            line1: settings.defaultShipFromAddress || settings.companyAddress || "",
            city: settings.defaultShipFromCity || "",
            postcode: settings.defaultShipFromPostcode || "",
            state: settings.defaultShipFromState || "",
            country: "Malaysia",
          },
          recipient: {
            name: customer.name || customer.displayName || "Customer",
            phone: customer.phoneNumber || "",
            dial_code: recipientPhone.dial_code,
            mobile: recipientPhone.mobile,
            line1: order.shippingAddress || customer.address || "",
            city: customer.city || "",
            postcode: customer.postalCode || "",
            state: customer.state || "",
            country: "Malaysia",
          },
          parcel: {
            weight_kg: input.weightKg,
            name: input.content || "Goods",
            declared_value: input.contentValue,
          },
          delivery_options: input.handoverMethod ? {
            handover_method: input.handoverMethod,
            pickup_time: input.pickupTime,
            pickup_time_range_id: input.pickupTimeRangeId,
          } : undefined,
          reference: order.orderNumber,
        });

        const trackingNo = response.result.tracking_no;
        const labelUrl = response.result.label_url || null;
        const shippingCost = String(response.result.final_amount || 0);

        // Create package record in database
        if (input.isPartial && input.itemIds && input.itemIds.length > 0) {
          await db.partialShipping(input.orderId, input.itemIds, {
            courier: `ParcelKing #${input.serviceId}`,
            shippingType: "auto",
            trackingNumber: trackingNo,
            shippingLabelUrl: labelUrl || undefined,
            providerOrderId: trackingNo,
            weight: String(input.weightKg),
            shippingCost,
          });
        } else {
          await db.fullShipping(input.orderId, [{
            courier: `ParcelKing #${input.serviceId}`,
            shippingType: "auto",
            trackingNumber: trackingNo,
            shippingLabelUrl: labelUrl || undefined,
            providerOrderId: trackingNo,
            weight: String(input.weightKg),
            shippingCost,
          }]);
        }

        // Send Messenger notification with tracking number
        if (customer.messengerId && settings.notifyOnShipment) {
          try {
            const trackingMsg = `您的订单 ${order.orderNumber} 已发货！\n追踪号码: ${trackingNo}\n物流公司: ParcelKing\n您可在此查询物流状态: https://www.myparcelking.com/tracking/${trackingNo}`;
            await sendTextMessage(customer.messengerId, trackingMsg);
          } catch (msgError: any) {
            // Log but don't fail the shipment creation
            console.error('[ParcelKing] Messenger notification failed:', msgError.message);
          }
        }

        return {
          success: true,
          trackingNumber: trackingNo,
          labelUrl,
          shippingCost,
          testMode: response.result.test_mode,
        };
      } catch (error: any) {
        if (error instanceof ParcelKingError) {
          throw new TRPCError({
            code: error.statusCode >= 500 ? "INTERNAL_SERVER_ERROR" : "BAD_REQUEST",
            message: error.message,
          });
        }
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: error.message });
      }
    }),

    // Re-download shipping label for an existing package
    redownloadLabel: shippingProcedure.input(z.object({
      trackingNo: z.string(),
    })).mutation(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const url = await parcelking.getShippingLabelUrl(input.trackingNo);
        return { success: true, url };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    // Re-sync tracking from ParcelKing
    resyncTracking: shippingProcedure.input(z.object({
      trackingNo: z.string(),
      packageId: z.number(),
    })).mutation(async ({ input }) => {
      if (!parcelking.isParcelKingConfigured()) {
        return { success: false, error: "Parcel King API key not configured" };
      }
      try {
        const tracking = await parcelking.getTracking(input.trackingNo);
        const timeline = tracking.result.timeline || [];
        const latest = timeline[timeline.length - 1];

        let newStatus = "shipped";
        if (latest?.description?.toLowerCase().includes("deliver")) {
          newStatus = "delivered";
        }

        const dbAny = db as any;
        if (dbAny.updatePackageStatus) {
          await dbAny.updatePackageStatus(input.packageId, newStatus);
        }

        return { success: true, timeline, latestEvent: latest, newStatus };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

    createParcelDaily: shippingProcedure.input(z.object({
      orderId: z.number(),
      weight: z.number(),
      courier: z.string().optional(),
    })).mutation(async ({ input }) => {
      // Get order details for shipping info
      const order = await db.getOrderById(input.orderId);
      if (!order) throw new Error("Order not found");
      
      // Call ParcelDaily API to create order
      // Note: ParcelDaily requires specific address format, this is a simplified version
      // In production, parse shippingAddress into components
      const result = await parceldaily.createOrder({
        serviceProvider: input.courier || "poslaju",
        pickupAddress: {
          fullName: "Xintian Nursery",
          phone: "",
          line1: "",
          city: "",
          postcode: "",
          state: "",
          country: "Malaysia",
        },
        clientAddress: {
          fullName: order.facebookName || "",
          phone: "",
          line1: order.shippingAddress || "",
          city: "",
          postcode: "",
          state: "",
          country: "Malaysia",
        },
        kg: input.weight,
        price: 0,
        content: "Plants",
        content_value: parseFloat(order.totalAmount || "0"),
        contentValueCurrency: "MYR",
        reference: order.orderNumber,
      });
      
      return result;
    }),
  }),
  
  // Customer order tracking (public)
  orderTracking: router({
    query: publicProcedure.input(z.object({
      orderNumber: z.string(),
      contactNumber: z.string().optional(),
    })).query(async ({ input }) => {
      return await db.getCustomerOrderTracking(input.orderNumber, input.contactNumber);
    }),
  }),
  
  // Live Order Capture (直播捉单)
  liveCapture: router({
    // Parse comment keywords (admin tool for testing)
    parse: adminProcedure.input(z.object({ comment: z.string() })).query(async ({ input }) => {
      const keywords = db.parseCommentKeywords(input.comment);
      const { matched, unmatched } = await db.matchKeywordsToProducts(keywords);
      return { keywords, matched, unmatched };
    }),
    
    // Create order from live capture
    createOrder: adminProcedure.input(z.object({
      commenterName: z.string(),
      commenterPsid: z.string().optional(),
      commentMessage: z.string(),
      commentId: z.string().optional(),
      postId: z.string().optional(),
      liveVideoId: z.string().optional(),
      matchedProducts: z.array(z.object({
        keyword: z.string(),
        quantity: z.number(),
        productId: z.number(),
        productName: z.string(),
        productSku: z.string(),
        unitPrice: z.string(),
      })),
      sourceName: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.createOrderFromLiveCapture(input);
    }),
    
    // List captures (admin)
    list: adminProcedure.input(z.object({ limit: z.number().optional() })).query(async ({ input }) => {
      return await db.getLiveOrderCaptures(input.limit || 50);
    }),
  }),
  
  // ===========================================================================
  // V1.1: Dashboard V11 (仪表板 V1.1)
  // ===========================================================================
  dashboardV11: router({
    stats: adminProcedure.query(async () => {
      return await db.getDashboardV11Stats();
    }),
  }),

  // ===========================================================================
  // V1.1: Order Remarks (订单备注 - 3种类型)
  // ===========================================================================
  orderRemarks: router({
    list: adminProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getOrderRemarks(input.orderId);
    }),
    create: adminProcedure.input(z.object({
      orderId: z.number(),
      type: z.enum(["live", "customer", "internal"]),
      content: z.string().min(1),
      createdBy: z.string().optional(),
      remarkCategory: z.enum(["repotting", "desired_delivery_date", "select_tree", "other"]).optional(),
      desiredDeliveryDate: z.string().optional(),
      desiredDeliveryReason: z.string().optional(),
      repottingData: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      await db.createOrderRemark({
        orderId: input.orderId,
        type: input.type,
        content: input.content,
        createdBy: input.createdBy || ctx.user?.name || undefined,
        remarkCategory: input.remarkCategory,
        desiredDeliveryDate: input.desiredDeliveryDate,
        desiredDeliveryReason: input.desiredDeliveryReason,
        repottingData: input.repottingData,
      });
      return { success: true };
    }),
    update: adminProcedure.input(z.object({
      id: z.number(),
      content: z.string().optional(),
      remarkCategory: z.enum(["repotting", "desired_delivery_date", "select_tree", "other"]).optional(),
      desiredDeliveryDate: z.string().optional(),
      desiredDeliveryReason: z.string().optional(),
      repottingData: z.string().optional(),
    })).mutation(async ({ input }) => {
      await db.updateOrderRemark(input.id, {
        content: input.content,
        remarkCategory: input.remarkCategory,
        desiredDeliveryDate: input.desiredDeliveryDate,
        desiredDeliveryReason: input.desiredDeliveryReason,
        repottingData: input.repottingData,
      });
      return { success: true };
    }),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteOrderRemark(input.id);
      return { success: true };
    }),
    // V3.0: Get orders with remarks for Dashboard
    ordersWithRemarks: adminProcedure.query(async () => {
      return await db.getOrdersWithRemarks();
    }),
    // V3.0: Get all remarks with order info
    allWithOrder: adminProcedure.input(z.object({ limit: z.number().optional() })).query(async ({ input }) => {
      return await db.getAllRemarksWithOrder(input.limit);
    }),
  }),

  // ===========================================================================
  // V1.1: Order Item Repots (换盆功能)
  // ===========================================================================
  repots: router({
    list: adminProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getOrderItemRepots(input.orderId);
    }),
    create: adminProcedure.input(z.object({
      orderItemId: z.number(),
      orderId: z.number(),
      productId: z.number(),
      productName: z.string(),
      potProductId: z.number(),
      potProductName: z.string(),
      quantity: z.number().min(1),
    })).mutation(async ({ input }) => {
      await db.createOrderItemRepot(input);
      return { success: true };
    }),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteOrderItemRepot(input.id);
      return { success: true };
    }),
    potProducts: adminProcedure.query(async () => {
      return await db.getPotProducts();
    }),
  }),

  // ===========================================================================
  // V1.1: Scheduled Shipping (预约发货)
  // ===========================================================================
  scheduledShipping: router({
    setDate: adminProcedure.input(z.object({
      orderId: z.number(),
      date: z.string().nullable(),
    })).mutation(async ({ input }) => {
      const date = input.date ? new Date(input.date) : null;
      await db.setScheduledShippingDate(input.orderId, date);
      return { success: true };
    }),
    today: adminProcedure.query(async () => {
      return await db.getTodayScheduledShipping();
    }),
    list: adminProcedure.input(z.object({
      dateFrom: z.string().optional(),
      dateTo: z.string().optional(),
    }).optional()).query(async ({ input }) => {
      return await db.getScheduledShippingOrders({
        dateFrom: input?.dateFrom ? new Date(input.dateFrom) : undefined,
        dateTo: input?.dateTo ? new Date(input.dateTo) : undefined,
      });
    }),
  }),

    // ===========================================================================
  // Dashboard (original)
  // ===========================================================================
  dashboard: router({
    stats: adminProcedure.query(async () => {
      return await db.getDashboardStats();
    }),
  }),

  // ===========================================================================
  // V1.2: Order Exceptions (订单异常处理)
  // ===========================================================================
  orderException: router({
    // List exceptions for an order
    list: protectedProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await db.getOrderExceptions(input.orderId);
    }),

    // Create a new exception
    create: protectedProcedure.input(z.object({
      orderId: z.number(),
      orderItemId: z.number().nullable().optional(),
      exceptionType: z.enum(["out_of_stock", "quality_issue", "overcharged_shipping", "delivery_delay", "cancelled_item", "other"]),
      description: z.string().optional(),
      // V2.1.26补充4: New fields for enhanced exception handling
      quantity: z.number().optional(),
      customerAction: z.enum(["replace_product", "wait_restock", "refund", "pending"]).optional(),
    })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || 'Unknown';
      return await db.createOrderException({
        orderId: input.orderId,
        orderItemId: input.orderItemId ?? null,
        exceptionType: input.exceptionType,
        description: input.description,
        createdBy: userName,
        quantity: input.quantity,
        customerAction: input.customerAction,
      });
    }),

    // Edit a pending exception without invoking settlement side effects.
    update: protectedProcedure.input(z.object({
      exceptionId: z.number(),
      orderItemId: z.number().nullable().optional(),
      exceptionType: z.enum(["out_of_stock", "quality_issue", "overcharged_shipping", "delivery_delay", "cancelled_item", "other"]).optional(),
      description: z.string().optional(),
      quantity: z.number().min(0).optional(),
      customerAction: z.enum(["replace_product", "wait_restock", "refund", "pending"]).optional(),
    })).mutation(async ({ input }) => {
      return await db.updateOrderException(input.exceptionId, {
        orderItemId: input.orderItemId,
        exceptionType: input.exceptionType,
        description: input.description,
        quantity: input.quantity,
        customerAction: input.customerAction,
      });
    }),

    // 包货实际重量／运费沟通后，客户取消部分未发货商品的专用原子流程。
    cancelPackingItem: protectedProcedure.input(z.object({
      orderId: z.number().int().positive(),
      orderItemId: z.number().int().positive(),
      quantity: z.number().int().positive(),
      description: z.string().max(5000).optional(),
      refundMethod: z.enum(['credit', 'tng', 'cash']),
      customerRefundDetails: z.string().max(5000).optional(),
      customerRefundQrUrl: z.string().max(500).optional(),
      attachmentUrls: z.string().max(10000).optional(),
      internalNotes: z.string().max(5000).optional(),
    })).mutation(async ({ input, ctx }) => {
      const operator = ctx.user?.name || ctx.user?.email || 'Unknown';
      return await db.cancelPackingOrderItem({ ...input, operator });
    }),

    // Resolve an exception with a chosen resolution type
    resolve: protectedProcedure.input(z.object({
      exceptionId: z.number(),
      resolutionType: z.enum(["replace", "wait_restock", "refund"]),
      scrapCost: z.number().optional(),
      refundAmount: z.number().optional(),
      // For replacement: items to add as new order items
      replacementItems: z.array(z.object({
        productId: z.number(),
        productName: z.string(),
        quantity: z.number(),
        unitPrice: z.number(),
        subtotal: z.number(),
      })).optional(),
      // Items to scrap (mark as quality scrap)
      scrapItems: z.array(z.object({
        orderItemId: z.number(),
        productId: z.number(),
        productName: z.string(),
        quantity: z.number(),
        unitCost: z.number().optional(),
      })).optional(),
      orderId: z.number(),
      // V2.1.26补充4: New fields for enhanced exception handling
      quantity: z.number().optional(),
      customerAction: z.enum(["replace_product", "wait_restock", "refund", "pending"]).optional(),
      replacementProductId: z.number().optional(),
      replacementProductName: z.string().optional(),
      replacementQuantity: z.number().optional(),
      replacementUnitPrice: z.number().optional(),
      refundMethod: z.enum(["credit", "tng", "cash"]).optional(),
      customerRefundDetails: z.string().max(5000).optional(),
      customerRefundQrUrl: z.string().max(500).optional(),
      attachmentUrls: z.string().max(10000).optional(),
      internalNotes: z.string().max(5000).optional(),
    })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || 'Unknown';

      // 1. Resolve the exception record
      const exception = await db.resolveOrderException(
        input.exceptionId,
        input.resolutionType,
        userName,
        {
          scrapCost: input.scrapCost,
          refundAmount: input.refundAmount,
          replacementProductId: input.replacementProductId,
          replacementProductName: input.replacementProductName,
          replacementQuantity: input.replacementQuantity,
          replacementUnitPrice: input.replacementUnitPrice,
          refundMethod: input.refundMethod,
          customerAction: input.customerAction,
          quantity: input.quantity,
          orderId: input.orderId,
          customerRefundDetails: input.customerRefundDetails,
          customerRefundQrUrl: input.customerRefundQrUrl,
          attachmentUrls: input.attachmentUrls,
          internalNotes: input.internalNotes,
        },
      );

      // 2. Handle scrap items (mark as scrapped, deduct stock, log inventory adjustment)
      if (input.scrapItems && input.scrapItems.length > 0) {
        for (const item of input.scrapItems) {
          // Create exception item record
          await db.createOrderExceptionItem({
            exceptionId: input.exceptionId,
            orderItemId: item.orderItemId,
            productId: item.productId,
            productName: item.productName,
            quantity: item.quantity,
            unitCost: item.unitCost ?? 0,
            totalScrapCost: (item.unitCost ?? 0) * item.quantity,
            isScrapped: true,
          });

          // Create inventory adjustment (stock reduction)
          await db.createInventoryAdjustment({
            productId: item.productId,
            adjustmentType: 'quality_issue',
            quantityChange: -item.quantity,
            unitCost: item.unitCost ?? 0,
            totalCost: (item.unitCost ?? 0) * item.quantity,
            orderExceptionId: input.exceptionId,
            adjustedBy: userName,
            reason: '植物品质异常报废',
          });
        }
      }

      // 3. Legacy replacement-items support.
      // New packing flow already performs all order-item, stock and price-difference work
      // atomically inside resolveOrderException via replacementProductId. Repeating it here
      // caused duplicate replacement lines and double inventory deductions.
      if (!input.replacementProductId && input.replacementItems && input.replacementItems.length > 0) {
        for (const item of input.replacementItems) {
          // Add new order item
          const dbAny = db as any;
          if (dbAny.addOrderItem) {
            await dbAny.addOrderItem({
              orderId: input.orderId,
              productId: item.productId,
              productName: item.productName,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              subtotal: item.subtotal,
            });
          }

          // Deduct stock for replacement product
          await db.createInventoryAdjustment({
            productId: item.productId,
            adjustmentType: 'other',
            quantityChange: -item.quantity,
            adjustedBy: userName,
            reason: '异常处理更换商品',
          });
        }

        // Recalculate order totals
        await db.recalculateOrderTotals(input.orderId);
      }

      return { success: true, exception };
    }),

    // Get replacements for an exception
    replacements: protectedProcedure.input(z.object({ exceptionId: z.number() })).query(async ({ input }) => {
      return await db.getOrderExceptionReplacements(input.exceptionId);
    }),

    // V3.3: Exceptions must remain in the audit trail. Keep the legacy RPC
    // name below for existing clients, but perform a traceable cancellation.
    cancel: protectedProcedure.input(z.object({ exceptionId: z.number() })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || "Unknown";
      await db.cancelOrderException(input.exceptionId, userName);
      return { success: true, status: "cancelled" as const };
    }),
    delete: protectedProcedure.input(z.object({ exceptionId: z.number() })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || "Unknown";
      await db.cancelOrderException(input.exceptionId, userName);
      return { success: true, status: "cancelled" as const };
    }),

    // 补货到货后，明确将已入库的数量分配给等待订单并关闭该商品级异常。
    markResolved: protectedProcedure.input(z.object({
      exceptionId: z.number(),
    })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || 'Unknown';
      const exception = await db.allocateRestockedOrderException(input.exceptionId, userName);
      return { success: true, exception };
    }),
  }),

  // ===========================================================================
  // V1.2: Inventory Adjustments (库存手动扣减)
  // ===========================================================================
  inventoryLog: router({
    list: adminProcedure.input(z.object({
      movementType: z.string().optional(),
      dateFrom: z.string().optional(),
      dateTo: z.string().optional(),
    }).optional()).query(async ({ input }) => {
      return await db.getInventoryMovementLogs({
        movementType: input?.movementType,
        dateFrom: input?.dateFrom ? new Date(input.dateFrom) : undefined,
        dateTo: input?.dateTo ? new Date(input.dateTo) : undefined,
      });
    }),
  }),
  inventoryAdjustment: router({
    // List adjustments
    list: adminProcedure.input(z.object({
      productId: z.number().optional(),
      adjustmentType: z.string().optional(),
      dateFrom: z.string().optional(),
      dateTo: z.string().optional(),
    }).optional()).query(async ({ input }) => {
      return await db.getInventoryAdjustments({
        productId: input?.productId,
        adjustmentType: input?.adjustmentType,
        dateFrom: input?.dateFrom ? new Date(input.dateFrom) : undefined,
        dateTo: input?.dateTo ? new Date(input.dateTo) : undefined,
      });
    }),

    // Create a manual stock adjustment
    create: adminProcedure.input(z.object({
      productId: z.number(),
      supplierId: z.number().int().positive(),
      adjustmentType: z.enum(["quality_issue", "plant_death", "pest_disease", "human_damage", "unhealthy", "lost", "other"]),
      quantityChange: z.number(),
      reason: z.string().optional(),
      remark: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || 'Unknown';
      const supplier = await db.getSupplierById(input.supplierId);
      if (!supplier?.isActive) throw new Error("厂家不存在或已停用");
      const latestCost = await db.getLatestSupplierProductCost(input.productId, input.supplierId);
      if (!latestCost) throw new Error("此厂家尚无该商品的已收货成本，无法自动计算损耗成本");
      const unitCost = latestCost.unitCost;
      return await db.createInventoryAdjustment({
        productId: input.productId,
        supplierId: input.supplierId,
        supplierName: supplier.name,
        adjustmentType: input.adjustmentType,
        quantityChange: input.quantityChange,
        unitCost,
        totalCost: Math.abs(input.quantityChange) * unitCost,
        adjustedBy: userName,
        reason: input.reason,
        remark: input.remark,
      });
    }),

    createBatch: adminProcedure.input(z.object({
      adjustmentType: z.enum(["quality_issue", "plant_death", "pest_disease", "human_damage", "unhealthy", "lost", "other"]),
      reason: z.string().trim().max(1000).optional(),
      remark: z.string().trim().max(1000).optional(),
      items: z.array(z.object({
        productId: z.number().int().positive(),
        supplierId: z.number().int().positive(),
        quantityChange: z.number().int().refine((value) => value !== 0, "库存变动数量必须非 0"),
      })).min(1).max(50),
    })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || "Unknown";
      const items = [];
      for (const item of input.items) {
        const supplier = await db.getSupplierById(item.supplierId);
        if (!supplier?.isActive) throw new Error("厂家不存在或已停用");
        const latestCost = await db.getLatestSupplierProductCost(item.productId, item.supplierId);
        if (!latestCost) throw new Error(`商品 #${item.productId} 在所选厂家尚无已收货成本，无法自动计算损耗成本`);
        items.push({
          ...item,
          supplierName: supplier.name,
          unitCost: latestCost.unitCost,
          totalCost: Math.abs(item.quantityChange) * latestCost.unitCost,
        });
      }
      return await db.createInventoryAdjustmentBatch({
        adjustmentType: input.adjustmentType,
        reason: input.reason,
        remark: input.remark,
        items,
        adjustedBy: userName,
      });
    }),

    // A correction is an additional linked movement, never an overwrite of the
    // historical adjustment, so both stock and loss reporting stay auditable.
    correct: adminProcedure.input(z.object({
      adjustmentId: z.number().int().positive(),
      desiredQuantityChange: z.number().int(),
      reason: z.string().trim().min(1, "请填写更正原因").max(1000),
    })).mutation(async ({ input, ctx }) => {
      const userName = ctx.user?.name || ctx.user?.email || "Unknown";
      return await db.correctInventoryAdjustment({ ...input, adjustedBy: userName });
    }),
  }),

  // ===========================================================================
  // V1.2: Profit Analysis Report (利润分析报告)
  // ===========================================================================
  profitAnalysis: router({
    report: adminProcedure.input(z.object({
      dateFrom: z.string(),
      dateTo: z.string(),
    })).query(async ({ input }) => {
      return await db.getProfitAnalysisReport({
        start: new Date(input.dateFrom),
        end: new Date(input.dateTo),
      });
    }),
  }),

  // ===========================================================================
  // V1.2: Loss Analysis Report (损耗分析报告)
  // ===========================================================================
  lossAnalysis: router({
    report: adminProcedure.input(z.object({
      dateFrom: z.string(),
      dateTo: z.string(),
    })).query(async ({ input }) => {
      return await db.getLossAnalysisReport({
        start: new Date(input.dateFrom),
        end: new Date(input.dateTo),
      });
    }),
  }),
  // ===========================================================================
  // V1.2: Shipping Fee & Special Orders (运费与特别订单)
  // ===========================================================================
  shippingV2: router({
    // Calculate shipping fee for checkout
    calculate: publicProcedure.input(z.object({
      items: z.array(z.object({
        productId: z.number(),
        quantity: z.number(),
        isStandalone: z.boolean().optional(),
      })),
    })).mutation(async ({ input }) => {
      // Fetch product details for each item
      const productDetails = await Promise.all(
        input.items.map(async (item) => {
          const product = await db.getProductByIdEnhanced(item.productId);
          return {
            ...item,
            product,
          };
        })
      );
      
      // Split items into normal and standalone
      const normalItems = productDetails.filter(i => !i.product?.allowStandaloneShipping);
      const standaloneItems = productDetails.filter(i => i.product?.allowStandaloneShipping);
      
      // Calculate normal items subtotal and weight
      const normalSubtotal = normalItems.reduce((sum, i) => sum + (Number(i.product?.sellingPrice || 0) * i.quantity), 0);
      const normalWeight = normalItems.reduce((sum, i) => sum + (Number(i.product?.weightKg || 0) * i.quantity), 0);
      
      // Calculate normal shipping
      const normalShipping = db.calculateNormalShippingFee(normalSubtotal, normalWeight);
      
      // Calculate standalone shipping for each standalone item
      const standaloneShipping = standaloneItems.map(i => ({
        productId: i.productId,
        method: i.product?.standaloneShippingMethod || "fixed_fee",
        fee: db.calculateStandaloneShippingFee(
          (i.product?.standaloneShippingMethod as "fixed_fee" | "free_shipping") || "fixed_fee",
          Number(i.product?.standaloneShippingFee || 0)
        ),
      }));
      
      const standaloneTotal = standaloneShipping.reduce((sum, s) => sum + s.fee, 0);
      const totalShipping = normalShipping.shippingFee + standaloneTotal;
      
      return {
        normalParcel: {
          itemsSubtotal: normalSubtotal,
          weight: normalWeight,
          shippingFee: normalShipping.shippingFee,
          isFreeShipping: normalShipping.isFreeShipping,
        },
        standaloneParcels: standaloneShipping,
        totalShipping,
        needsSplit: standaloneItems.length > 0 && normalItems.length > 0,
      };
    }),
    
    // Update actual weight for an order (packing stage)
    updateActualWeight: shippingProcedure.input(z.object({
      orderId: z.number(),
      actualWeight: z.number(),
    })).mutation(async ({ ctx, input }) => {
      // Get order details
      const order = await db.getOrderById(input.orderId);
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
      
      const itemsSubtotal = Number(order.physicalSubtotal || 0);
      const customerPaidShipping = Number(order.customerPaidShipping || order.shippingFee || 0);
      const shippingMethod = (order as any).shippingMethod || "west_malaysia";
      
      let result;
      
      // Lalamove: staff enters the actual delivery fee. The company always bears
      // the first RM15; only the remaining excess is a customer balance.
      if (shippingMethod === "lalamove") {
        const shippingConfig = await db.getControlledShippingConfiguration();
        const companyBearing = shippingConfig.lalamove.companyBearingFee;
        const settlement = calculateLalamoveActualCustomerBalance(input.actualWeight, companyBearing); // actual fee is entered in this field for Lalamove
        result = {
          actualShippingFee: settlement.actualShippingFee,
          difference: settlement.customerBalance,
          needsSpecialOrder: settlement.needsSpecialOrder,
          specialOrderType: settlement.needsSpecialOrder ? "pending_shipping" as const : null,
        };
      } else if (shippingMethod === "east_malaysia_poslaju") {
        // V2.1.28: Use recipient address fields (not shippingAddress which may be a combined text)
        const shippingAddr = (order as any).addressLine1 || (order as any).shippingAddress || "";
        const postcode = (order as any).recipientPostcode || (order as any).postcode || "";
        const state = (order as any).recipientState || "";
        result = await db.processEastMalaysiaPosLajuWeight(
          input.actualWeight,
          customerPaidShipping,
          shippingAddr,
          postcode,
          state,
        );
      } else {
        // 西马实际重量以结账时同一套免邮资格金额重算，避免特价或种植介质改变结果。
        const freeShippingEligibleSubtotal = await db.getOrderFreeShippingEligibleSubtotal(input.orderId);
        const shippingConfig = await db.getControlledShippingConfiguration();
        result = db.processActualWeight(
          input.actualWeight,
          customerPaidShipping,
          freeShippingEligibleSubtotal,
          false,
          null,
          0,
          shippingConfig.westMalaysia,
        );
      }
      
      // Update order with actual weight and shipping details
      await db.updateOrderActualWeight(
        input.orderId,
        input.actualWeight,
        result.actualShippingFee,
        result.difference,
        result.difference < 0 ? Math.abs(result.difference) : null,
        result.difference > 0 ? result.difference : null,
        result.needsSpecialOrder,
        result.specialOrderType
      );
      
      // If special order needed, create notification + send Messenger notification
      let shippingRefund: { id: number; refundNumber: string; status?: string; existing?: boolean } | undefined;
      if (result.needsSpecialOrder) {
        const specialAction = await db.createSpecialOrderAction(
          input.orderId,
          "notify_shortage",
          Math.abs(result.difference),
          ctx.user?.name || "system",
          result.specialOrderType === "pending_shipping"
            ? `Need to collect RM${Math.abs(result.difference).toFixed(2)} additional shipping fee`
            : `Need to refund RM${Math.abs(result.difference).toFixed(2)} shipping fee`
        );
        if (result.specialOrderType === "pending_refund") {
          shippingRefund = await db.ensurePendingShippingDifferenceRefund({
            orderId: input.orderId,
            requestedBy: ctx.user?.name || "system",
            sourceSpecialActionId: specialAction?.actionId || undefined,
          });
        }
        
        // V2.0.84: Auto-send Messenger notification to customer about shipping difference
        if ((order as any).messengerId) {
          try {
            const { sendTextMessage } = await import("./messenger");
            const diff = Math.abs(result.difference);
            const orderNumber = (order as any).orderNumber || "";
            let message: string;
            if (shippingMethod === "lalamove") {
              message = `您好，感恩您的支持 ❤️\n\n您的订单 ${orderNumber} 已完成打包。\nLalamove 实际配送费用超过基础承担金额，尚需补运费 RM${diff.toFixed(2)}。\n完成补款后，我们将尽快安排配送，谢谢。`;
            } else if (result.specialOrderType === "pending_refund") {
              message = `您好，感恩您的支持 ❤️\n\n您的订单 ${orderNumber} 已完成打包。\n实际运费为 RM${result.actualShippingFee.toFixed(2)}，您已预付 RM${customerPaidShipping.toFixed(2)}。\n多收运费 RM${diff.toFixed(2)}，我们将安排退款，或依您的选择转换为 Credit。\n如有疑问欢迎联系我们，谢谢。`;
            } else {
              message = `您好，感恩您的支持 ❤️\n\n您的订单 ${orderNumber} 已完成打包。\n实际运费为 RM${result.actualShippingFee.toFixed(2)}，您已预付 RM${customerPaidShipping.toFixed(2)}。\n尚需补运费 RM${diff.toFixed(2)}。\n完成补款后我们将尽快安排寄出，谢谢。`;
            }
            await sendTextMessage((order as any).messengerId, message);
          } catch (e) {
            console.error("[updateActualWeight] Failed to send Messenger notification:", e);
          }
        }
      }
      
      return {
        success: true,
        actualShippingFee: result.actualShippingFee,
        difference: result.difference,
        needsSpecialOrder: result.needsSpecialOrder,
        specialOrderType: result.specialOrderType,
        shippingRefund,
        apiShippingFee: (result as any).apiShippingFee,
        handlingFee: (result as any).handlingFee,
      };
    }),
    
    // Get special orders list
    specialOrders: adminProcedure.input(z.object({
      status: z.string().optional(),
      type: z.string().optional(),
      limit: z.number().optional(),
      offset: z.number().optional(),
    })).query(async ({ input }) => {
      return await db.getSpecialOrders(input);
    }),
    
    // Get special order actions for an order
    specialOrderActions: protectedProcedure.input(z.object({
      orderId: z.number(),
    })).query(async ({ input }) => {
      return await db.getSpecialOrderActions(input.orderId);
    }),

    setPendingShippingShipmentRelease: shippingProcedure.input(z.object({
      orderId: z.number().int().positive(),
      allowShipping: z.boolean(),
      remark: z.string().max(1000).optional(),
    })).mutation(async ({ ctx, input }) => {
      return await db.setPendingShippingShipmentRelease({
        ...input,
        operator: ctx.user?.name || "staff",
      });
    }),
    
    // Process special order action
    processSpecialOrder: shippingProcedure.input(z.object({
      orderId: z.number(),
      actionType: z.enum(["notify_shortage", "confirm_received", "refund", "company_bear", "remark", "convert_to_credit"]),
      amount: z.number().optional(),
      remark: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      // 运费退款（含转Credit）必须先有退款管理记录；不能由包货工作台直接结案。
      if (input.actionType === "refund" || input.actionType === "convert_to_credit") {
        const refund = await db.ensurePendingShippingDifferenceRefund({
          orderId: input.orderId,
          requestedBy: ctx.user?.name || "staff",
          refundMethod: input.actionType === "convert_to_credit" ? "credit" : "bank_transfer",
        });
        return { success: true, refund, requiresRefundManagement: true };
      }
      if (input.actionType === "confirm_received") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "请先上传客户补运费凭证；补运费须经付款审核确认后才会入账。" });
      }
      const action = await db.createSpecialOrderAction(
        input.orderId,
        input.actionType,
        input.amount || 0,
        ctx.user?.name || "staff",
        input.remark
      );

      // 公司承担可直接解除该财务待办；补运费必须走凭证审核流程。
      if (input.actionType === "company_bear") {
        const dbConn = await db.getDb();
        if (dbConn) {
          const { orders } = await import("../drizzle/schema");
          await dbConn.update(orders).set({
            specialOrderStatus: "resolved",
          }).where(eq(orders.id, input.orderId));
        }
      }
      
      return { success: true };
    }),
    submitSupplementalShippingProof: shippingProcedure.input(z.object({
      orderId: z.number(),
      receiptUrl: z.string().min(1),
      paymentMethod: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      return db.submitSupplementalShippingPaymentProof({
        ...input,
        operatorName: ctx.user?.name || "staff",
      });
    }),
    completeCashShippingRefund: shippingProcedure.input(z.object({
      orderId: z.number().int().positive(),
    })).mutation(async ({ ctx, input }) => {
      return db.completePackingShippingCashRefund({
        orderId: input.orderId,
        processedBy: ctx.user?.name || "staff",
      });
    }),
    
    // Get sub-orders for a parent order
    subOrders: protectedProcedure.input(z.object({
      parentOrderId: z.number(),
    })).query(async ({ input }) => {
            return await db.getSubOrders(input.parentOrderId);
    }),
  }),
  // ===========================================================================
  // V2.0: Live Rooms (直播房间)
  // ===========================================================================
  liveRooms: router({
    list: adminProcedure
      .input(z.object({
        status: z.enum(['preparing', 'live', 'ended', 'closed']).optional(),
        liveType: z.enum(['normal', 'import_preorder']).optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getLiveRooms(input || {});
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const room = await db.getLiveRoomById(input.id);
        if (!room) throw new Error('直播房间不存在');
        return room;
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        liveDate: z.coerce.date(),
        facebookLiveUrl: z.string().optional(),
        facebookVideoId: z.string().optional(),
        liveType: z.enum(['normal', 'import_preorder']).optional(),
        importBatchId: z.number().optional(),
        preorderStartDate: z.coerce.date().optional(),
        preorderEndDate: z.coerce.date().optional(),
        estimatedWaitDays: z.string().optional(),
        status: z.enum(['preparing', 'live', 'ended', 'closed']).optional(),
        notes: z.string().optional(),
        streamerName: z.string().optional(),
        facebookPageId: z.string().optional(),
        estimatedStartTime: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createLiveRoom(input);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        liveDate: z.coerce.date().optional(),
        facebookLiveUrl: z.string().optional(),
        facebookVideoId: z.string().optional(),
        liveType: z.enum(['normal', 'import_preorder']).optional(),
        importBatchId: z.number().optional(),
        preorderStartDate: z.coerce.date().optional(),
        preorderEndDate: z.coerce.date().optional(),
        estimatedWaitDays: z.string().optional(),
        status: z.enum(['preparing', 'live', 'ended', 'closed']).optional(),
        notes: z.string().optional(),
        streamerName: z.string().optional(),
        facebookPageId: z.string().optional(),
        estimatedStartTime: z.string().optional(),
        aiReplyEnabled: z.boolean().optional(),
        continueMonitor: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateLiveRoom(id, data);
        return { success: true };
      }),

    // 直播间备忘录采用专用接口：保存后重新读取数据库记录，前端只以已持久化的内容回显。
    saveRoomNotes: adminProcedure
      .input(z.object({
        liveRoomId: z.number().int().positive(),
        content: z.string().trim().max(5000, "备忘录不可超过 5000 个字"),
      }))
      .mutation(async ({ input }) => {
        const room = await db.getLiveRoomById(input.liveRoomId);
        if (!room) throw new Error("直播间不存在");

        await db.updateLiveRoom(input.liveRoomId, { notes: input.content });
        const savedRoom = await db.getLiveRoomById(input.liveRoomId);
        return {
          notes: savedRoom?.notes || "",
          updatedAt: savedRoom?.updatedAt || new Date(),
        };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteLiveRoom(input.id);
        return { success: true };
      }),

    // --- Live Room Products (直播商品) ---
    getProducts: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveRoomProducts(input.liveRoomId);
      }),

    addProduct: adminProcedure
      .input(z.object({
        liveRoomId: z.number(),
        productId: z.number(),
        variationId: z.number().optional(),
        keyword: z.string().min(1),
        displayName: z.string().min(1),
        price: z.union([z.string(), z.number()]),
        stock: z.number().default(0),
        imageUrl: z.string().optional(),
        specImage: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.addLiveRoomProduct(input);
      }),

    updateProduct: adminProcedure
      .input(z.object({
        id: z.number(),
        price: z.union([z.string(), z.number()]).optional(),
        status: z.enum(['active', 'paused', 'sold_out']).optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateLiveRoomProduct(id, data);
        return { success: true };
      }),

    deleteProduct: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteLiveRoomProduct(input.id);
        return { success: true };
      }),

    adjustProductStock: adminProcedure
      .input(z.object({
        id: z.number(),
        quantityChange: z.number().int().negative(),
        reason: z.enum(["damaged", "scrap", "unhealthy", "other"]),
      }))
      .mutation(async ({ input }) => {
        return await db.adjustLiveRoomProductStock(input.id, input);
      }),

    reorderProducts: adminProcedure
      .input(z.object({
        liveRoomId: z.number(),
        orderedIds: z.array(z.number()),
      }))
      .mutation(async ({ input }) => {
        return await db.reorderLiveRoomProducts(input.liveRoomId, input.orderedIds);
      }),

    // --- Live Room Stats (业绩统计) ---
    getStats: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveRoomStats(input.liveRoomId);
      }),

    getStatsBatch: adminProcedure
      .input(z.object({ liveRoomIds: z.array(z.number()) }))
      .query(async ({ input }) => {
        return await db.getLiveRoomStatsBatch(input.liveRoomIds);
      }),

    // --- Keyword Copy (关键词复制) ---
    copyKeyword: adminProcedure
      .input(z.object({ liveRoomProductId: z.number() }))
      .query(async ({ input }) => {
        // Get live comment footer from system settings
        const settings = await db.getSystemSettings();
        const footer = settings?.liveCommentFooter || '👇 留言关键词即可自动下单';
        return await db.generateKeywordCopyText(input.liveRoomProductId, footer);
      }),

    // --- Live Orders (直播订单) ---
    getOrders: adminProcedure
      .input(z.object({ liveRoomId: z.number(), limit: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.getLiveRoomOrders(input.liveRoomId, input.limit || 100);
      }),

    getOrdersByProduct: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveRoomOrdersByProduct(input.liveRoomId);
      }),

    // --- Product Search & Batch Add ---
    searchProducts: adminProcedure
      .input(z.object({ liveRoomId: z.number(), query: z.string(), categoryId: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.searchProductsForLiveRoom(input.liveRoomId, input.query, input.categoryId);
      }),

    batchAddProducts: adminProcedure
      .input(z.object({
        liveRoomId: z.number(),
        items: z.array(z.object({
          productId: z.number(),
          variationId: z.number().optional(),
          livePrice: z.number().optional(),
        })),
      }))
      .mutation(async ({ input }) => {
        return await db.batchAddProductsToLiveRoom(input.liveRoomId, input.items as any);
      }),

    // --- Preorder Toggle ---
    togglePreorder: adminProcedure
      .input(z.object({ id: z.number(), allowPreorder: z.boolean() }))
      .mutation(async ({ input }) => {
        return await db.toggleLiveRoomProductPreorder(input.id, input.allowPreorder);
      }),

    // --- Live Comments (直播留言) ---
    getComments: adminProcedure
      .input(z.object({
        liveRoomId: z.number(),
        search: z.string().optional(),
        matchResult: z.string().optional(),
        messengerStatus: z.string().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getLiveComments(input.liveRoomId, input);
      }),

    getCommentStats: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveCommentStats(input.liveRoomId);
      }),

    updateCommentMessengerStatus: adminProcedure
      .input(z.object({ commentId: z.number(), status: z.string(), error: z.string().optional() }))
      .mutation(async ({ input }) => {
        return await db.updateLiveCommentMessengerStatus(input.commentId, input.status, input.error);
      }),

    markCommentHandled: adminProcedure
      .input(z.object({ commentId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.markLiveCommentHandled(input.commentId);
      }),

    // --- Live Room Report (直播报告) ---
    getReport: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveRoomReport(input.liveRoomId);
      }),

    // --- Start Live (开始直播) ---
    startLive: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateLiveRoom(input.liveRoomId, {
          status: 'live',
          liveStartTime: new Date(),
        } as any);
        return { success: true };
      }),
    // --- End Live (直播结束) ---
    endLive: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateLiveRoom(input.liveRoomId, {
          status: 'ended',
          liveEndTime: new Date(),
        } as any);
        return { success: true };
      }),

    // --- V2.0: Send Comment to Facebook Live (发送留言) ---
    sendComment: adminProcedure
      .input(z.object({
        videoId: z.string(),
        message: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        return await db.sendLiveComment(input.videoId, input.message);
      }),

    // --- V2.0: Toggle Customer Blacklist (黑名单切换) ---
    toggleBlacklist: adminProcedure
      .input(z.object({
        customerId: z.number(),
        isBlacklisted: z.boolean(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.toggleCustomerBlacklist(
          input.customerId,
          input.isBlacklisted,
          input.reason || '',
          ctx.user?.name || 'Admin',
        );
      }),

    blacklistCommenter: adminProcedure
      .input(z.object({
        commenterName: z.string().trim().min(1),
        commenterPsid: z.string().trim().optional(),
        reason: z.string().trim().min(1),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.blacklistLiveCommenter({
          ...input,
          operatorName: ctx.user?.name || 'Admin',
        });
      }),

    // --- V2.0: Staff Notes (工作人员备注) ---
    getCommentNotes: adminProcedure
      .input(z.object({ liveCommentId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveCommentNotes(input.liveCommentId);
      }),

    getRoomNotes: adminProcedure
      .input(z.object({ liveRoomId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveRoomNotes(input.liveRoomId);
      }),

    createNote: adminProcedure
      .input(z.object({
        liveCommentId: z.number(),
        liveRoomId: z.number(),
        orderId: z.number().optional(),
        customerId: z.number().optional(),
        content: z.string().min(1),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createLiveCommentNote({
          ...input,
          createdBy: ctx.user?.name || 'Admin',
        });
      }),

    deleteNote: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteLiveCommentNote(input.id);
      }),
  }),

  // ===========================================================================
  // V2.0: Import Batches (采购批次)
  // ===========================================================================
  importBatches: router({
    list: adminProcedure
      .input(z.object({
        status: z.enum(['draft', 'in_progress', 'closed', 'purchased', 'preparing', 'in_transit', 'partial_arrived', 'all_arrived', 'completed']).optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getImportBatches(input || {});
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const batch = await db.getImportBatchById(input.id);
        if (!batch) throw new Error('采购批次不存在');
        return batch;
      }),

    create: adminProcedure
      .input(z.object({
        batchNumber: z.string().min(1),
        batchName: z.string().min(1),
        sourceCountry: z.string().optional(),
        supplierName: z.string().optional(),
        liveRoomId: z.number().optional(),
        preorderStartDate: z.coerce.date().optional(),
        preorderEndDate: z.coerce.date().optional(),
        shippingMethod: z.enum(['air', 'sea']).optional(),
        chinaShippingCost: z.string().optional(),
        status: z.enum(['draft', 'in_progress', 'closed', 'purchased', 'preparing', 'in_transit', 'partial_arrived', 'all_arrived', 'completed']).optional(),
        notes: z.string().optional(),
        supplierOrderNumber: z.string().optional(),
        chinaTrackingNumber: z.string().optional(),
        otherFees: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createImportBatch(input);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        batchName: z.string().optional(),
        sourceCountry: z.string().optional(),
        supplierName: z.string().optional(),
        liveRoomId: z.number().optional(),
        preorderStartDate: z.coerce.date().optional(),
        preorderEndDate: z.coerce.date().optional(),
        actualPurchaseDate: z.coerce.date().optional(),
        shippingMethod: z.enum(['air', 'sea']).optional(),
        chinaShippingCost: z.string().optional(),
        status: z.enum(['draft', 'in_progress', 'closed', 'purchased', 'preparing', 'in_transit', 'partial_arrived', 'all_arrived', 'completed']).optional(),
        notes: z.string().optional(),
        supplierOrderNumber: z.string().optional(),
        chinaTrackingNumber: z.string().optional(),
        otherFees: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        await db.updateImportBatch(id, data, ctx.user.id);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteImportBatch(input.id);
        return { success: true };
      }),

    // Get batch items (采购汇总)
    items: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .query(async ({ input }) => {
        return await db.getImportBatchItems(input.batchId);
      }),

    // Upsert batch item (add/update product in batch)
    upsertItem: adminProcedure
      .input(z.object({
        batchId: z.number(),
        productId: z.number(),
        productName: z.string(),
        variantId: z.number().optional(),
        variantName: z.string().optional(),
        paidQuantity: z.number().optional(),
        finalPurchaseQuantity: z.number().optional(),
        actualReceivedQty: z.number().optional(),
        healthyQty: z.number().optional(),
        damagedQty: z.number().optional(),
        deadQty: z.number().optional(),
        missingQty: z.number().optional(),
        itemStatus: z.enum(['pending', 'all_arrived', 'partial_arrived', 'shortage', 'damaged', 'dead', 'missing', 'wrong_item']).optional(),
        unitPurchaseCost: z.string().optional(),
        spotSaleEnabled: z.boolean().optional(),
        spotSaleQty: z.number().optional(),
        notes: z.string().optional(),
        wrongItemQty: z.number().optional(),
        differenceReason: z.enum(['none', 'supplier_short', 'over_supply', 'damaged', 'dead', 'wrong_item', 'not_arrived', 'other']).optional(),
        differenceNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.upsertImportBatchItem(input, ctx.user.id);
      }),

    // Delete batch item
    deleteItem: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteImportBatchItem(input.id, ctx.user.id);
        return { success: true };
      }),

    changeLogs: adminProcedure
      .input(z.object({ ibId: z.number().int().positive() }))
      .query(async ({ input }) => db.getImportBatchChangeLogs(input.ibId)),

    // Allocate shipping cost to items
    allocateShipping: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.allocateShippingCost(input.batchId);
      }),

    // CN 重构：按日期选中国代购直播场次，再合并商品后建立 CN + 初始 IB。
    getCnEligibleLiveSessions: adminProcedure
      .input(z.object({ startDate: z.string().date(), endDate: z.string().date() }))
      .query(async ({ input }) => {
        if (input.startDate > input.endDate) throw new Error('开始日期不可晚于截止日期。');
        return await db.getCNEligibleLiveSessions(input.startDate, input.endDate);
      }),

    getCnMergedProducts: adminProcedure
      .input(z.object({ liveSessionIds: z.array(z.number().int().positive()).min(1) }))
      .query(async ({ input }) => {
        return await db.getCNMergedProducts(input.liveSessionIds);
      }),

    createCnWithAutoIb: adminProcedure
      .input(z.object({
        startDate: z.string().date(),
        endDate: z.string().date(),
        paymentDeadline: z.string().date().optional(),
        batchName: z.string().min(1).optional(),
        supplierName: z.string().optional(),
        supplierOrderNumber: z.string().optional(),
        chinaTrackingNumber: z.string().optional(),
        chinaShippingCost: z.string().optional(),
        otherFees: z.string().optional(),
        notes: z.string().optional(),
        liveSessionIds: z.array(z.number().int().positive()).min(1),
        items: z.array(z.object({
          productId: z.number().int().positive(),
          productName: z.string().min(1),
          variantId: z.number().int().positive().nullable().optional(),
          variantName: z.string().nullable().optional(),
          paidQuantity: z.number().nonnegative(),
          finalPurchaseQuantity: z.number().nonnegative(),
          unitPurchaseCost: z.string().optional(),
          notes: z.string().optional(),
        })).min(1),
      }))
      .mutation(async ({ input, ctx }) => {
        if (input.startDate > input.endDate) throw new Error('开始日期不可晚于截止日期。');
        return await db.createChinaPreorderWithAutoIB({ ...input, operatorId: ctx.user.id });
      }),

    updateCnWithAudit: adminProcedure
      .input(z.object({
        cnId: z.number().int().positive(),
        changes: z.object({
          batchName: z.string().min(1).optional(),
          supplierName: z.string().nullable().optional(),
          supplierOrderNumber: z.string().nullable().optional(),
          chinaTrackingNumber: z.string().nullable().optional(),
          startDate: z.string().date().optional(),
          endDate: z.string().date().optional(),
          paymentDeadline: z.string().date().optional(),
          chinaShippingCost: z.string().optional(),
          otherFees: z.string().optional(),
          notes: z.string().nullable().optional(),
          status: z.string().optional(),
        }).refine(value => Object.keys(value).length > 0, '请至少提供一项要修改的 CN 内容。'),
      }))
      .mutation(async ({ input, ctx }) => {
        const { cnId, changes } = input;
        return await db.updateCNWithAudit(cnId, changes, ctx.user.id);
      }),

    getCnChangeLogs: adminProcedure
      .input(z.object({ cnId: z.number().int().positive() }))
      .query(async ({ input }) => db.getCNChangeLogs(input.cnId)),

    createSplitArrivalIb: adminProcedure
      .input(z.object({ cnId: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => db.createSplitArrivalImportBatch(input.cnId, ctx.user.id)),

    lock: adminProcedure
      .input(z.object({ ibId: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => db.lockImportBatch(input.ibId, ctx.user.id)),

    unlock: adminProcedure
      .input(z.object({ ibId: z.number().int().positive(), reason: z.string().trim().min(1, '解锁 IB 必须填写原因。') }))
      .mutation(async ({ input, ctx }) => db.unlockImportBatch(input.ibId, ctx.user.id, input.reason)),

    getDashboardSummary: adminProcedure
      .query(async () => db.getCnIbDashboardSummary()),

    processExpiredCnOrders: adminProcedure
      .mutation(async () => db.processExpiredCNOrders()),

    // V2.0.97: CN/IB new procedures
    // Generate CN number
    generateCnNumber: adminProcedure.query(async () => {
      return await db.generateCnNumber();
    }),

    // Confirm CN (draft -> purchased, auto-generate IB)
    confirmCn: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.confirmCn(input.batchId);
      }),

    // Complete IB verification (update stock, auto-match XTC orders)
    completeIb: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.completeIbVerification(input.batchId);
      }),

    // Allocate all costs (shipping + other fees)
    allocateAllCosts: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.allocateAllCosts(input.batchId);
      }),

    // Get CN/IB batch detail with items and linked orders
    getCnIbDetail: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCnIbBatchDetail(input.batchId);
      }),

    // Get CN/IB cost-profit analysis
    costProfit: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCnIbCostProfit(input.batchId);
      }),

    // V2.0.98: Priority stock allocation
    allocateStock: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.allocateStockByPriority(input.batchId);
      }),

    // V2.0.98: Create IB difference record
    createIbDifference: adminProcedure
      .input(z.object({
        batchId: z.number(),
        cnBatchNumber: z.string().optional(),
        supplierName: z.string().optional(),
        productId: z.number(),
        productName: z.string(),
        variantId: z.number().optional(),
        variantName: z.string().optional(),
        cnPurchaseQty: z.number(),
        ibReceivedQty: z.number(),
        differenceType: z.string(),
        reason: z.string().optional(),
        evidenceUrl: z.string().optional(),
        needsReplenish: z.boolean().optional(),
        needsRefund: z.boolean().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createIbDifference(input);
      }),

    // V2.0.98: Get IB differences
    getIbDifferences: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .query(async ({ input }) => {
        return await db.getIbDifferences(input.batchId);
      }),

    // V2.0.98: Link CN to parent batch (multiple CNs for same XTC)
    linkCnToParent: adminProcedure
      .input(z.object({ batchId: z.number(), parentBatchId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.linkCnToParentBatch(input.batchId, input.parentBatchId);
      }),

    // V2.0.98: Get linked CNs
    getLinkedCns: adminProcedure
      .input(z.object({ parentBatchId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLinkedCns(input.parentBatchId);
      }),

    // V2.0.98: Complete stock-in and lock costs
    completeStockIn: adminProcedure
      .input(z.object({ batchId: z.number(), operatorName: z.string().optional() }))
      .mutation(async ({ input }) => {
        return await db.completeStockIn(input.batchId, input.operatorName);
      }),

    // V2.0.98: Unlock costs (requires reason)
    unlockCosts: adminProcedure
      .input(z.object({ batchId: z.number(), reason: z.string(), operatorName: z.string() }))
      .mutation(async ({ input }) => {
        return await db.unlockCosts(input.batchId, input.reason, input.operatorName);
      }),

    // V2.0.98: Re-lock costs
    relockCosts: adminProcedure
      .input(z.object({ batchId: z.number(), operatorName: z.string() }))
      .mutation(async ({ input }) => {
        return await db.relockCosts(input.batchId, input.operatorName);
      }),

    // V2.0.98: Manual stock allocation adjustment
    manualAdjustAllocation: adminProcedure
      .input(z.object({
        batchId: z.number(),
        fromOrderId: z.number(),
        toOrderId: z.number(),
        productId: z.number(),
        variantId: z.number().optional(),
        qty: z.number(),
        reason: z.string(),
        operatorName: z.string(),
      }))
      .mutation(async ({ input }) => {
        return await db.manualAdjustAllocation(input);
      }),

    // V2.0.98: Get stock allocation summary
    getStockAllocation: adminProcedure
      .input(z.object({ batchId: z.number() }))
      .query(async ({ input }) => {
        return await db.getStockAllocationSummary(input.batchId);
      }),
  }),

  // ===========================================================================
    // V2.0: Import Preorder Dashboard & Reports
  // ===========================================================================
  importPreorder: router({
    stats: adminProcedure.query(async () => {
      return await db.getImportPreorderStats();
    }),
    profitAnalysis: adminProcedure
      .input(z.object({
        batchId: z.number().optional(),
        liveRoomId: z.number().optional(),
        startDate: z.coerce.date().optional(),
        endDate: z.coerce.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getImportPreorderProfitAnalysis(input || {});
      }),
  }),

  // ===========================================================================
  // V3.1: Product Bundles (组合包管理)
  // ===========================================================================
  productBundles: router({
    list: adminProcedure
      .input(z.object({
        status: z.string().optional(),
        showInMall: z.boolean().optional(),
        search: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getProductBundles(input || {});
      }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
 const bundle = await db.getBundleById(input.id);
        if (!bundle) throw new Error("Bundle not found");
        return bundle;
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string(),
        nameEn: z.string().optional(),
        keyword: z.string(),
        sellingPrice: z.string(),
        originalTotalPrice: z.string().optional(),
        specialPrice: z.string().optional(),
        coverImage: z.string().optional(),
        description: z.string().optional(),
        status: z.string().optional(),
        showInMall: z.boolean().optional(),
        weight: z.string().optional(),
        internalNotes: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          variantId: z.number().optional(),
          productName: z.string(),
          variantName: z.string().optional(),
          qtyPerBundle: z.number(),
          unitCost: z.string(),
          unitPrice: z.string(),
        })),
        bundleQty: z.number(),
        operator: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createBundleWithStock(input);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        nameEn: z.string().optional(),
        keyword: z.string().optional(),
        sellingPrice: z.string().optional(),
        originalTotalPrice: z.string().optional(),
        specialPrice: z.string().optional(),
        coverImage: z.string().optional(),
        description: z.string().optional(),
        status: z.string().optional(),
        showInMall: z.boolean().optional(),
        weight: z.string().optional(),
        internalNotes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateBundle(id, data);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteBundle(input.id);
      }),

    restock: adminProcedure
      .input(z.object({
        bundleId: z.number(),
        restockQty: z.number(),
        operator: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.restockBundle(input);
      }),

    disassemble: adminProcedure
      .input(z.object({
        bundleId: z.number(),
        disassembleQty: z.number(),
        reason: z.string(),
        damagedProducts: z.array(z.number()).optional(),
        operator: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.disassembleBundle(input);
      }),

    stockLogs: adminProcedure
      .input(z.object({ bundleId: z.number() }))
      .query(async ({ input }) => {
        return await db.getBundleStockLogs(input.bundleId);
      }),

    calculateMax: adminProcedure
      .input(z.object({
        items: z.array(z.object({
          productId: z.number(),
          qtyPerBundle: z.number(),
        })),
      }))
      .query(async ({ input }) => {
        return await db.calculateMaxBundleQty(input.items);
      }),

    mallList: publicProcedure
      .query(async () => {
        return await db.getMallBundles();
      }),

    mallDetail: publicProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ input }) => {
        const bundle = await db.getBundleById(input.id);
        // Public mall links may only expose active, visible, sellable bundles.
        if (!bundle || bundle.status !== "active" || !bundle.showInMall || Number(bundle.bundleStock) <= 0) {
          return null;
        }
        return bundle;
      }),

    profitAnalysis: adminProcedure
      .input(z.object({
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getBundleProfitAnalysis(input || {});
      }),
  }),

  // ===========================================================================
  // V2.0 Phase 2.5: Live AI Flows (直播 AI 客服)
  // ===========================================================================
  liveAiFlows: router({
    list: adminProcedure
      .query(async () => {
        return await db.getLiveAiFlows();
      }),
    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiveAiFlowById(input.id);
      }),
    create: adminProcedure
      .input(z.object({
        name: z.string(),
        triggerKeywords: z.string(),
        replyContent: z.string(),
        isEnabled: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createLiveAiFlow(input);
      }),
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        triggerKeywords: z.string().optional(),
        replyContent: z.string().optional(),
        isEnabled: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.updateLiveAiFlow(input.id, input);
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteLiveAiFlow(input.id);
      }),
    duplicate: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.duplicateLiveAiFlow(input.id);
      }),
    reorder: adminProcedure
      .input(z.object({ ids: z.array(z.number()) }))
      .mutation(async ({ input }) => {
        return await db.reorderLiveAiFlows(input.ids);
      }),
    match: publicProcedure
      .input(z.object({ message: z.string() }))
      .query(async ({ input }) => {
        const reply = await db.matchLiveAiFlow(input.message);
        return { matched: reply !== null, reply };
      }),
  }),

  // ===========================================================================
  // V4.0: AI Customer Service — Chat & Handover
  // ===========================================================================
  chat: router({
    listConversations: adminProcedure
      .input(z.object({
        platform: z.string().optional(),
        unreadOnly: z.boolean().optional(),
        needsHuman: z.boolean().optional(),
        aiDisabled: z.boolean().optional(),
        hasOrder: z.boolean().optional(),
        search: z.string().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await db.listChatConversations(input);
      }),

    getMessages: adminProcedure
      .input(z.object({
        conversationId: z.number(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getChatMessages(input.conversationId, input.limit || 100, input.offset || 0);
      }),

    sendMessage: adminProcedure
      .input(z.object({
        conversationId: z.number(),
        content: z.string(),
        messageType: z.enum(["text", "image", "file"]).default("text"),
        mediaUrl: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const operatorName = ctx.user?.name || "Staff";

        // Store message in DB
        await db.addChatMessage({
          conversationId: input.conversationId,
          senderType: "staff",
          senderName: operatorName,
          messageType: input.messageType,
          content: input.content,
          mediaUrl: input.mediaUrl,
          status: "sent",
        });

        // Get conversation to find platform info
        const allConvs = await db.listChatConversations({ limit: 500 });
        const conv = allConvs.find((c: any) => c.id === input.conversationId);
        if (!conv) throw new Error("Conversation not found");

        // Send via Messenger API if platform is messenger
        if (conv.platform === "messenger" && conv.platformId) {
          try {
            await sendTextMessage(conv.platformId, input.content);
          } catch (err: any) {
            await db.addChatMessage({
              conversationId: input.conversationId,
              senderType: "system",
              messageType: "text",
              content: `[Send failed: ${err.message}]`,
              status: "failed",
              errorMessage: err.message,
            });
            throw new Error(`Failed to send via Messenger: ${err.message}`);
          }
        } else if (conv.platform === "whatsapp") {
          await db.addChatMessage({
            conversationId: input.conversationId,
            senderType: "system",
            messageType: "text",
            content: "[WhatsApp API not yet configured — message stored in system only]",
            status: "failed",
            errorMessage: "WhatsApp API not configured",
          });
        }

        return { success: true };
      }),

    markRead: adminProcedure
      .input(z.object({ conversationId: z.number() }))
      .mutation(async ({ input }) => {
        await db.markConversationRead(input.conversationId);
        return { success: true };
      }),

    toggleAI: adminProcedure
      .input(z.object({
        conversationId: z.number(),
        enabled: z.boolean(),
      }))
      .mutation(async ({ input, ctx }) => {
        const operatorName = ctx.user?.name || "Staff";
        await db.toggleConversationAI(input.conversationId, input.enabled, operatorName);
        return { success: true };
      }),

    handover: adminProcedure
      .input(z.object({ conversationId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const operatorName = ctx.user?.name || "Staff";
        await db.claimHandover(input.conversationId, operatorName);
        return { success: true };
      }),

    resumeAI: adminProcedure
      .input(z.object({ conversationId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const operatorName = ctx.user?.name || "Staff";
        await db.resumeConversationAI(input.conversationId, operatorName);
        return { success: true };
      }),

    getCustomerInfo: adminProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input }) => {
        return await db.getChatCustomerInfo(input.customerId);
      }),

    createTrainingFeedback: adminProcedure
      .input(z.object({
        conversationId: z.number(),
        messageId: z.number(),
        category: z.string().trim().min(1, "分类必填"),
        topic: z.string().trim().min(1, "主题必填"),
        triggerKeywords: z.string().trim().min(1, "触发关键词必填"),
        content: z.string().trim().min(1, "修订回复必填"),
        sourceNote: z.string().trim().max(1000).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createChatTrainingFeedback({
          ...input,
          staffName: ctx.user?.name || `Admin #${ctx.user?.id || ""}`,
        });
      }),
  }),

  aiHandover: router({
    list: adminProcedure
      .input(z.object({
        status: z.enum(["pending", "claimed", "all"]).default("pending"),
      }))
      .query(async ({ input }) => {
        const status = input.status === "all" ? undefined : input.status;
        return await db.listHandoverRequests(status);
      }),

    getStats: adminProcedure
      .query(async () => {
        return await db.getHandoverStats();
      }),

    claim: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const operatorName = ctx.user?.name || "Staff";
        const requests = await db.listHandoverRequests("pending");
        const req = requests.find((r: any) => r.id === input.id);
        if (!req) throw new Error("Handover request not found");
        if (req.conversationId) {
          await db.claimHandover(req.conversationId, operatorName);
        }
        return { success: true };
      }),
  }),

  // =========================================================================
  // AI Engine — Reply Rules Management (Admin-maintained fixed replies)
  // =========================================================================
  replyRules: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllReplyRules();
    }),
    create: protectedProcedure.input(z.object({
      name: z.string(),
      triggerKeywords: z.string(),
      replyContent: z.string(),
      priority: z.number().optional(),
      channels: z.string().optional(),
      isEnabled: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      return await db.createReplyRule(input);
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(),
      triggerKeywords: z.string().optional(),
      replyContent: z.string().optional(),
      priority: z.number().optional(),
      channels: z.string().optional(),
      isEnabled: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateReplyRule(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return await db.deleteReplyRule(input.id);
    }),
  }),

  // =========================================================================
  // AI Engine — Knowledge Base Management (Admin-maintained AI knowledge)
  // =========================================================================
  aiKnowledge: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllAiKnowledge();
    }),
    create: protectedProcedure.input(z.object({
      category: z.string(),
      topic: z.string(),
      triggerKeywords: z.string(),
      content: z.string(),
      priority: z.number().optional(),
      useLLM: z.boolean().optional(),
      isEnabled: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      return await db.createAiKnowledge(input);
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      category: z.string().optional(),
      topic: z.string().optional(),
      triggerKeywords: z.string().optional(),
      content: z.string().optional(),
      priority: z.number().optional(),
      useLLM: z.boolean().optional(),
      isEnabled: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateAiKnowledge(id, data);
    }),
    approveChatTrainingFeedback: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      return await db.approveChatTrainingFeedback(input.id, ctx.user?.name || `Admin #${ctx.user?.id || ""}`);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return await db.deleteAiKnowledge(input.id);
    }),
  }),

  // =========================================================================
  // AI Brain — Central management hub for all AI features
  // =========================================================================
  aiBrain: router({
    getStatus: adminProcedure.query(async () => {
      return await db.getAiBrainStatus();
    }),

    getStats: adminProcedure.query(async () => {
      return await db.getAiBrainStats();
    }),

    getAlerts: adminProcedure.query(async () => {
      return await db.getAiBrainAlerts();
    }),

    getPersona: adminProcedure.query(async () => {
      return await db.getAiPersona();
    }),

    updatePersona: adminProcedure.input(z.object({
      aiName: z.string().optional(),
      brandName: z.string().optional(),
      aiSelfReference: z.string().optional(),
      customerAddress: z.string().optional(),
      replyTone: z.string().optional(),
      defaultLanguage: z.string().optional(),
      supportedLanguages: z.string().optional(),
      emojiLevel: z.string().optional(),
      replyLength: z.string().optional(),
      proactiveRecommend: z.boolean().optional(),
      proactiveInquire: z.boolean().optional(),
      enableCTA: z.boolean().optional(),
      ctaTemplate: z.string().optional(),
      customPrompt: z.string().optional(),
      replyPrinciples: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.updateAiPersona(input);
    }),

    previewReply: adminProcedure
      .input(z.object({
        userMessage: z.string().min(1),
        // Preview may use the form's unsaved state. This remains simulation-only
        // and never persists or sends a message to a customer.
        personaOverride: z.object({
          aiName: z.string().optional(),
          brandName: z.string().optional(),
          aiSelfReference: z.string().optional(),
          customerAddress: z.string().optional(),
          replyTone: z.string().optional(),
          defaultLanguage: z.string().optional(),
          supportedLanguages: z.string().optional(),
          emojiLevel: z.string().optional(),
          replyLength: z.string().optional(),
          proactiveRecommend: z.boolean().optional(),
          proactiveInquire: z.boolean().optional(),
          enableCTA: z.boolean().optional(),
          ctaTemplate: z.string().optional(),
          customPrompt: z.string().optional(),
          replyPrinciples: z.string().optional(),
        }).partial().optional(),
      }))
      .mutation(async ({ input }) => {
        const savedPersona = await db.getAiPersona();
        if (!savedPersona) {
          return { reply: "请先设置 AI 人设后再进行预览。" };
        }
        const persona = { ...savedPersona, ...input.personaOverride };

        // Build system prompt from persona settings
        const toneMap: Record<string, string> = {
          warm: "温暖亲切",
          friendly: "友善轻松",
          professional: "专业正式",
          casual: "随性自然",
        };
        const lengthMap: Record<string, string> = {
          short: "简短（1-2句话）",
          medium: "适中（3-5句话）",
          long: "详细（5句以上）",
        };
        const emojiMap: Record<string, string> = {
          none: "不使用 emoji",
          low: "少量 emoji",
          medium: "适度 emoji",
          high: "多使用 emoji",
        };

        const supportedLangs = (() => {
          try { return JSON.parse(persona.supportedLanguages || '[]') as string[]; } catch { return ['zh']; }
        })();

        const systemPrompt = `你是${persona.aiName}，${persona.brandName}的AI客服助手。

人设要求：
- 自称：${persona.aiSelfReference}
- 称呼客户：${persona.customerAddress}
- 语气：${toneMap[persona.replyTone] || persona.replyTone}
- 回复长度：${lengthMap[persona.replyLength] || persona.replyLength}
- Emoji 使用：${emojiMap[persona.emojiLevel] || persona.emojiLevel}
- 默认语言：${persona.defaultLanguage === 'zh' ? '中文' : persona.defaultLanguage === 'en' ? 'English' : persona.defaultLanguage}
- 支持语言：${supportedLangs.join(', ')}
${persona.proactiveRecommend ? '- 主动推荐适合的商品\n' : ''}${persona.proactiveInquire ? '- 主动询问客户需求\n' : ''}${persona.enableCTA && persona.ctaTemplate ? `- 回复结束语：${persona.ctaTemplate}\n` : ''}${persona.replyPrinciples ? `\n不可违反的 AI回复原则（最高优先级；如与前述人设字段冲突，以本区原则为准）：\n${persona.replyPrinciples}\n请逐条严格遵守这些原则。\n` : ''}${persona.customPrompt ? `\n额外要求：\n${persona.customPrompt}\n` : ''}
注意：这是模拟预览，不要提及你是AI模型或ChatGPT。直接以${persona.aiName}的身份回复。`;

        try {
          const { invokeLLM } = await import("./_core/llm");
          // Claude Haiku provides low-latency text output for this interactive
          // preview. GPT-5 may spend the small output budget on reasoning first,
          // which can leave the visible reply empty when max_tokens is capped.
          const result = await invokeLLM({
            model: "claude-haiku-4-5",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: input.userMessage },
            ],
            maxTokens: 500,
          });
          const content = result.choices?.[0]?.message?.content;
          const reply = Array.isArray(content)
            ? content
                .filter((part): part is { type: "text"; text: string } => part.type === "text")
                .map(part => part.text)
                .join("\n")
                .trim()
            : typeof content === "string"
              ? content.trim()
              : "";
          if (!reply) {
            throw new Error("预览模型未生成可用文本，请稍后重试。");
          }
          return { reply };
        } catch (err: any) {
          return { reply: `预览生成失败：${err.message || "未知错误"}` };
        }
      }),
  }),

  // ============================================================================
  // AI Log Center — Phase 2 Task 1
  // ============================================================================
  aiLog: router({
    list: adminProcedure
      .input(z.object({
        page: z.number().min(1).default(1),
        pageSize: z.number().min(1).max(100).default(20),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
        customerName: z.string().optional(),
        platform: z.string().optional(),
        sourceType: z.enum(["private_chat", "facebook_live", "facebook_post", "facebook_reel"]).optional(),
        finalSource: z.string().optional(),
        sendStatus: z.string().optional(),
        isHandover: z.boolean().optional(),
        errorStage: z.string().optional(),
        keyword: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return db.getAiLogs(input);
      }),

    getDetail: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const detail = await db.getAiLogDetail(input.id);
        if (!detail) throw new TRPCError({ code: "NOT_FOUND", message: "日志不存在" });
        return detail;
      }),

    retryDelivery: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        try {
          return await retryFailedAiLogDelivery(input.id);
        } catch (error: any) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: error?.message ?? "AI日志重试失败",
          });
        }
      }),

    getStats: adminProcedure
      .input(z.object({ days: z.number().min(1).max(365).default(1) }))
      .query(async ({ input }) => {
        return db.getAiLogStats(input.days);
      }),

    getCleanupPreview: adminProcedure
      .query(async () => {
        const stats = await db.getAiLogStats(9999);
        const retentionDays = (await import('./_core/env')).ENV.aiLogRetentionDays;
        return {
          totalLogs: stats.total,
          retentionDays,
          message: `当前保留 ${retentionDays} 天，超过的日志将被自动清理`,
        };
      }),

    // Replay an AI log entry through the test engine (dry run, no side effects)
    replay: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => {
        const testedBy = ctx.user?.name || ctx.user?.email || "admin";
        const { replayFromAiLog } = await import("./aiTestRunner");
        const result = await replayFromAiLog(input.id, testedBy);
        if (!result) throw new TRPCError({ code: "NOT_FOUND", message: "AI日志不存在" });
        return result;
      }),
  }),

  // ===========================================================================
  // AI Analysis Center — Admin-only analytics for AI performance optimization
  // ===========================================================================
  aiAnalysis: router({
    // Dashboard overview
    getDashboard: adminProcedure
      .input(z.object({ days: z.number().min(1).max(365).default(1) }))
      .query(async ({ input }) => {
        return db.getAiAnalysisDashboard(input.days);
      }),

    // Source distribution analysis
    getSourceAnalysis: adminProcedure
      .input(z.object({ days: z.number().min(1).max(365).default(7) }))
      .query(async ({ input }) => {
        return db.getSourceAnalysis(input.days);
      }),

    // Knowledge base analysis
    getKnowledgeAnalysis: adminProcedure
      .query(async () => {
        return db.getKnowledgeAnalysis();
      }),

    // Reply rule analysis
    getReplyRuleAnalysis: adminProcedure
      .query(async () => {
        return db.getReplyRuleAnalysis();
      }),

    // No-match analysis
    getNoMatchAnalysis: adminProcedure
      .input(z.object({
        days: z.number().min(1).max(365).default(7),
        limit: z.number().min(1).max(100).default(20),
      }))
      .query(async ({ input }) => {
        return db.getNoMatchAnalysis(input.days, input.limit);
      }),

    // Handover analysis
    getHandoverAnalysis: adminProcedure
      .input(z.object({ days: z.number().min(1).max(365).default(7) }))
      .query(async ({ input }) => {
        return db.getHandoverAnalysis(input.days);
      }),

    // LLM analysis
    getLlmAnalysis: adminProcedure
      .input(z.object({ days: z.number().min(1).max(365).default(7) }))
      .query(async ({ input }) => {
        return db.getLlmAnalysis(input.days);
      }),

    // AI improvement suggestions
    getSuggestions: adminProcedure
      .query(async () => {
        return db.getAiSuggestions();
      }),
  }),

  // ===========================================================================
  // AI Test Center — Admin-only test execution, completely isolated from ai_logs
  // ===========================================================================
  aiTest: router({
    // Run a test — executes production engines in dry_run mode
    run: adminProcedure
      .input(z.object({
        platform: z.enum(["messenger", "whatsapp"]),
        language: z.string().default("auto"),
        aiEnabled: z.boolean().default(true),
        handoverStatus: z.enum(["none", "pending", "claimed"]).default("none"),
        enableLLM: z.boolean().default(true),
        simulatedCustomerName: z.string().optional(),
        isMember: z.boolean().default(false),
        hasOrder: z.boolean().default(false),
        testMessage: z.string().min(1).max(2000),
      }))
      .mutation(async ({ input, ctx }) => {
        const testedBy = ctx.user?.name || ctx.user?.email || "admin";
        const result = await runTest(input, testedBy);
        return result;
      }),

    // List test runs with filtering
    list: adminProcedure
      .input(z.object({
        page: z.number().default(1),
        pageSize: z.number().default(20),
        finalSource: z.string().optional(),
        platform: z.string().optional(),
        testedBy: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getTestRuns(input);
      }),

    // Get test run detail
    getDetail: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const detail = await db.getTestRunDetail(input.id);
        if (!detail) throw new TRPCError({ code: "NOT_FOUND" });
        return detail;
      }),

    // Delete a single test run
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const ok = await db.deleteTestRun(input.id);
        if (!ok) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        return { success: true };
      }),

    // Batch delete test runs
    batchDelete: adminProcedure
      .input(z.object({ ids: z.array(z.number()) }))
      .mutation(async ({ input }) => {
        const count = await db.batchDeleteTestRuns(input.ids);
        return { deleted: count };
      }),

    // Rerun a test (creates new record linked via previousRunId)
    rerun: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const testedBy = ctx.user?.name || ctx.user?.email || "admin";
        const result = await rerunTest(input.id, testedBy);
        if (!result) throw new TRPCError({ code: "NOT_FOUND" });
        return result;
      }),

    // Compare two test runs
    compare: adminProcedure
      .input(z.object({ runIdA: z.number(), runIdB: z.number() }))
      .query(async ({ input }) => {
        const [a, b] = await Promise.all([
          db.getTestRunDetail(input.runIdA),
          db.getTestRunDetail(input.runIdB),
        ]);
        if (!a || !b) throw new TRPCError({ code: "NOT_FOUND" });
        return { runA: a, runB: b };
      }),

    // Convert test result to knowledge draft
    convertToDraft: adminProcedure
      .input(z.object({
        testRunId: z.number(),
        category: z.string().default("faq"),
        topic: z.string().min(1),
        triggerKeywords: z.string().min(1),
        content: z.string().min(1),
        sourceNote: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        // Check for duplicates
        const dupCheck = await db.checkDuplicateKnowledge(
          input.triggerKeywords,
          input.content
        );
        if (dupCheck.isDuplicate) {
          throw new TRPCError({
            code: "CONFLICT",
            message: `关键词与已有知识条目重复（ID: ${dupCheck.existingId}, 主题: ${dupCheck.existingTopic}）`,
          });
        }

        const draftId = await db.createKnowledgeDraft({
          category: input.category,
          topic: input.topic,
          triggerKeywords: input.triggerKeywords,
          content: input.content,
          sourceAiTestRunId: input.testRunId,
          sourceNote: input.sourceNote,
        });

        if (!draftId) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        return { draftId };
      }),
  }),

  // ==========================================================================
  // AI Regression Test Router
  // ==========================================================================
  aiRegression: router({
    // --- Regression Set Management ---
    listSets: adminProcedure.query(async () => {
      return db.getRegressionSets();
    }),

    getSet: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const set = await db.getRegressionSetById(input.id);
      if (!set) throw new TRPCError({ code: "NOT_FOUND" });
      const questions = await db.getRegressionQuestions(input.id);
      return { ...set, questions };
    }),

    createSet: adminProcedure.input(z.object({
      name: z.string().min(1),
      description: z.string().optional(),
      category: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      return db.createRegressionSet({
        name: input.name,
        description: input.description,
        category: input.category,
        createdBy: ctx.user?.name || ctx.user?.openId || "admin",
      });
    }),

    updateSet: adminProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(),
      description: z.string().optional(),
      category: z.string().optional(),
      isEnabled: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateRegressionSet(id, data);
      return { success: true };
    }),

    deleteSet: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteRegressionSet(input.id);
      return { success: true };
    }),

    // --- Question Management ---
    listQuestions: adminProcedure.input(z.object({ setId: z.number() })).query(async ({ input }) => {
      return db.getRegressionQuestions(input.setId);
    }),

    addQuestion: adminProcedure.input(z.object({
      setId: z.number(),
      question: z.string().min(1),
      expectedSource: z.string().optional(),
      expectedKeywords: z.string().optional(),
      expectedReply: z.string().optional(),
      category: z.string().optional(),
      priority: z.enum(["low", "medium", "high"]).optional(),
    })).mutation(async ({ input }) => {
      return db.addRegressionQuestion(input);
    }),

    updateQuestion: adminProcedure.input(z.object({
      id: z.number(),
      question: z.string().optional(),
      expectedSource: z.string().optional(),
      expectedKeywords: z.string().optional(),
      expectedReply: z.string().optional(),
      category: z.string().optional(),
      priority: z.enum(["low", "medium", "high"]).optional(),
      isEnabled: z.boolean().optional(),
      sortOrder: z.number().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateRegressionQuestion(id, data);
      return { success: true };
    }),

    deleteQuestion: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteRegressionQuestion(input.id);
      return { success: true };
    }),

    // --- Run Regression ---
    run: adminProcedure.input(z.object({
      setId: z.number(),
      versionId: z.number().optional(),
    })).mutation(async ({ input, ctx }) => {
      const set = await db.getRegressionSetById(input.setId);
      if (!set) throw new TRPCError({ code: "NOT_FOUND", message: "Regression set not found" });

      const questions = await db.getRegressionQuestions(input.setId);
      const enabledQuestions = questions.filter(q => q.isEnabled);
      if (enabledQuestions.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "No enabled questions in this set" });
      }

      // Check for existing baseline
      const runs = await db.getRegressionRuns(input.setId);
      const baselineRun = runs.find(r => r.isBaseline);
      const isBaseline = !baselineRun;

      // Create run record
      const run = await db.createRegressionRun({
        setId: input.setId,
        versionId: input.versionId,
        isBaseline,
        baselineRunId: baselineRun?.id,
        totalQuestions: enabledQuestions.length,
        runBy: ctx.user?.name || ctx.user?.openId || "admin",
      });

      // Get baseline details if available
      let baseline: BaselineResult[] | null = null;
      if (baselineRun) {
        const baselineDetails = await db.getRegressionRunDetails(baselineRun.id);
        baseline = baselineDetails.map(d => ({
          questionId: d.questionId,
          finalSource: d.finalSource,
          aiReply: d.aiReply,
          matchedRuleId: d.matchedRuleId || undefined,
          matchedKnowledgeId: d.matchedKnowledgeId || undefined,
          matchedProductId: d.matchedProductId || undefined,
          shouldHandover: d.shouldHandover,
        }));
      }

      // Prepare question inputs
      const questionInputs: RegressionQuestionInput[] = enabledQuestions.map(q => ({
        id: q.id,
        question: q.question,
        expectedSource: q.expectedSource || undefined,
        expectedKeywords: q.expectedKeywords || undefined,
        expectedReply: q.expectedReply || undefined,
      }));

      // Execute regression
      const result = await runRegression(questionInputs, baseline, run.id, async (detail) => {
        await db.createRegressionRunDetail(detail);
      });

      // Update run record with results
      await db.updateRegressionRun(run.id, {
        status: "completed",
        passedCount: result.passedCount,
        failedCount: result.failedCount,
        accuracy: result.accuracy.toFixed(2),
        avgProcessingMs: result.avgProcessingMs,
        newHits: result.newHits,
        lostHits: result.lostHits,
        sourceChanged: result.sourceChanged,
        replyChanged: result.replyChanged,
        noMatchIncreased: result.noMatchIncreased,
        noMatchDecreased: result.noMatchDecreased,
        handoverIncreased: result.handoverIncreased,
        llmIncreased: result.llmIncreased,
        llmDecreased: result.llmDecreased,
        completedAt: new Date(),
      });

      return result;
    }),

    // --- Run History & Details ---
    listRuns: adminProcedure.input(z.object({ setId: z.number() })).query(async ({ input }) => {
      return db.getRegressionRuns(input.setId);
    }),

    getRunDetails: adminProcedure.input(z.object({ runId: z.number() })).query(async ({ input }) => {
      const [run, details] = await Promise.all([
        db.getRegressionRunById(input.runId),
        db.getRegressionRunDetails(input.runId),
      ]);
      if (!run) throw new TRPCError({ code: "NOT_FOUND" });
      return { run, details };
    }),
  }),

  // ==========================================================================
  // AI Version Router
  // ==========================================================================
  aiVersion: router({
    list: adminProcedure.query(async () => {
      return db.getAiVersions();
    }),

    get: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const ver = await db.getAiVersionById(input.id);
      if (!ver) throw new TRPCError({ code: "NOT_FOUND" });
      return ver;
    }),

    getLatestPublished: adminProcedure.query(async () => {
      return db.getLatestPublishedVersion();
    }),

    create: adminProcedure.input(z.object({
      versionNumber: z.string().min(1),
      label: z.string().optional(),
      description: z.string().optional(),
      regressionRunId: z.number().optional(),
      regressionAccuracy: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      // Snapshot current knowledge and rules counts
      const { aiKnowledge, replyRules } = await import("../drizzle/schema");
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const knowledgeRows = await database.select().from(aiKnowledge).where(eq(aiKnowledge.isEnabled, true));
      const ruleRows = await database.select().from(replyRules).where(eq(replyRules.isEnabled, true));

      // Get all knowledge and rules for snapshot (for rollback)
      const allKnowledge = await database.select().from(aiKnowledge);
      const allRules = await database.select().from(replyRules);

      return db.createAiVersion({
        versionNumber: input.versionNumber,
        label: input.label,
        description: input.description,
        knowledgeCount: knowledgeRows.length,
        ruleCount: ruleRows.length,
        knowledgeSnapshot: allKnowledge,
        rulesSnapshot: allRules,
        regressionRunId: input.regressionRunId,
        regressionAccuracy: input.regressionAccuracy,
        createdBy: ctx.user?.name || ctx.user?.openId || "admin",
      });
    }),

    publish: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      await db.publishAiVersion(input.id, ctx.user?.name || ctx.user?.openId || "admin");
      return { success: true };
    }),

    rollback: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      const version = await db.getAiVersionById(input.id);
      if (!version) throw new TRPCError({ code: "NOT_FOUND" });
      if (!version.knowledgeSnapshot || !version.rulesSnapshot) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This version does not contain rollback snapshots" });
      }

      // Restore knowledge and rules from snapshot
      const { aiKnowledge, replyRules } = await import("../drizzle/schema");
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // Clear and restore knowledge
      await database.delete(aiKnowledge);
      if (Array.isArray(version.knowledgeSnapshot)) {
        for (const k of version.knowledgeSnapshot) {
          await database.insert(aiKnowledge).values(k);
        }
      }

      // Clear and restore rules
      await database.delete(replyRules);
      if (Array.isArray(version.rulesSnapshot)) {
        for (const r of version.rulesSnapshot) {
          await database.insert(replyRules).values(r);
        }
      }

      // Mark as published
      await db.rollbackToVersion(input.id, ctx.user?.name || ctx.user?.openId || "admin");
      return { success: true };
    }),
  }),

  // ==========================================================================
  // Draft Orders Router (Business AI)
  // ==========================================================================
  draftOrders: router({
    list: adminProcedure.input(z.object({
      status: z.enum(["waiting_approval", "approved", "rejected", "invalid", "all"]).default("all"),
      limit: z.number().default(50),
      offset: z.number().default(0),
    })).query(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      let query = database.select().from(draftOrders).orderBy(desc(draftOrders.createdAt)).limit(input.limit).offset(input.offset);
      if (input.status !== "all") {
        query = database.select().from(draftOrders).where(eqB(draftOrders.status, input.status)).orderBy(desc(draftOrders.createdAt)).limit(input.limit).offset(input.offset) as any;
      }
      return await query;
    }),

    get: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const [draft] = await database.select().from(draftOrders).where(eqB(draftOrders.id, input.id)).limit(1);
      if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
      return draft;
    }),

    approve: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      try {
        const result = await approveDraftOrder(input.id, ctx.user?.name || ctx.user?.openId || "admin");
        return { success: true, ...result };
      } catch (e: any) {
        throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
      }
    }),

    reject: adminProcedure.input(z.object({ id: z.number(), reason: z.string().optional() })).mutation(async ({ input, ctx }) => {
      try {
        await rejectDraftOrder(input.id, ctx.user?.name || ctx.user?.openId || "admin", input.reason);
        return { success: true };
      } catch (e: any) {
        throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
      }
    }),

    markInvalid: adminProcedure.input(z.object({ id: z.number(), reason: z.string().optional() })).mutation(async ({ input, ctx }) => {
      try {
        await markDraftOrderInvalid(input.id, ctx.user?.name || ctx.user?.openId || "admin", input.reason);
        return { success: true };
      } catch (e: any) {
        throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
      }
    }),
  }),

  // ==========================================================================
  // Order Change Requests Router (Business AI)
  // ==========================================================================
  orderChangeRequests: router({
    list: adminProcedure.input(z.object({
      status: z.enum(["waiting_approval", "approved", "rejected", "invalid", "all"]).default("all"),
      limit: z.number().default(50),
      offset: z.number().default(0),
    })).query(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      let query = database.select().from(orderChangeRequests).orderBy(desc(orderChangeRequests.createdAt)).limit(input.limit).offset(input.offset);
      if (input.status !== "all") {
        query = database.select().from(orderChangeRequests).where(eqB(orderChangeRequests.status, input.status)).orderBy(desc(orderChangeRequests.createdAt)).limit(input.limit).offset(input.offset) as any;
      }
      return await query;
    }),

    get: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const [req] = await database.select().from(orderChangeRequests).where(eqB(orderChangeRequests.id, input.id)).limit(1);
      if (!req) throw new TRPCError({ code: "NOT_FOUND" });
      return req;
    }),

    approve: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      try {
        await approveOrderChangeRequest(input.id, ctx.user?.name || ctx.user?.openId || "admin");
        return { success: true };
      } catch (e: any) {
        throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
      }
    }),

    reject: adminProcedure.input(z.object({ id: z.number(), reason: z.string().optional() })).mutation(async ({ input, ctx }) => {
      try {
        await rejectOrderChangeRequest(input.id, ctx.user?.name || ctx.user?.openId || "admin", input.reason);
        return { success: true };
      } catch (e: any) {
        throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
      }
    }),

    markInvalid: adminProcedure.input(z.object({ id: z.number(), reason: z.string().optional() })).mutation(async ({ input, ctx }) => {
      try {
        await markOrderChangeRequestInvalid(input.id, ctx.user?.name || ctx.user?.openId || "admin", input.reason);
        return { success: true };
      } catch (e: any) {
        throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
      }
    }),
  }),

  // ==========================================================================
  // Reservation Records Router (Business AI)
  // ==========================================================================
  reservations: router({
    list: adminProcedure.input(z.object({
      status: z.enum(["active", "converted", "released", "all"]).default("all"),
      productId: z.number().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    })).query(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      let query = database.select().from(reservationRecords).orderBy(desc(reservationRecords.createdAt)).limit(input.limit).offset(input.offset);
      if (input.status !== "all") {
        query = database.select().from(reservationRecords).where(eqB(reservationRecords.status, input.status)).orderBy(desc(reservationRecords.createdAt)).limit(input.limit).offset(input.offset) as any;
      }
      return await query;
    }),
  }),

  // ==========================================================================
  // AI Logistics Router (Business AI)
  // ==========================================================================
  aiLogistics: router({
    queryOrder: adminProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return await queryOrderShipping(input.orderId);
    }),
  }),

  // ==========================================================================
  // V2.0: Public Order Router (客户订单公开查询 - 无需登录)
  // ==========================================================================
  publicOrder: router({
    getByToken: publicProcedure
      .input(z.object({
        orderNumber: z.string(),
        token: z.string(),
      }))
      .query(async ({ input }) => {
        const result = await db.getOrderBySecureToken(input.orderNumber, input.token);
        if (!result) {
          throw new TRPCError({ code: 'NOT_FOUND', message: '订单不存在或链接无效' });
        }
        return result;
      }),
    getCarePackPath: publicProcedure
      .input(z.object({ orderNumber: z.string().min(1), token: z.string().min(32).max(128) }))
      .query(async ({ input }) => {
        const order = await db.getOrderBySecureToken(input.orderNumber, input.token);
        if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在或链接无效" });
        const ensured = await db.ensureOrderCarePack(order.id, "customer_checkout");
        return { path: db.buildCarePackPath(ensured.token) };
      }),
    // V2.0.3: Customer updates shipping address from public order page
    // V2.0.52: Customer can add remark to their order
    updateRemark: publicProcedure
      .input(z.object({
        orderNumber: z.string(),
        token: z.string(),
        remark: z.string().min(1).max(2000),
        remarkCategory: z.enum(["customer_other", "repotting"]).optional(),
        repottingData: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const order = await db.getOrderBySecureToken(input.orderNumber, input.token);
        if (!order) throw new Error("订单不存在或链接无效");
        await db.createOrderRemark({
          orderId: order.id,
          content: input.remark,
          type: "customer",
          remarkCategory: input.remarkCategory || "customer_other",
          createdBy: "customer",
          repottingData: input.repottingData,
        });
        return { success: true };
      }),
    updateAddress: publicProcedure
      .input(z.object({
        orderNumber: z.string(),
        token: z.string(),
        address: z.string().min(1, '请填写收货地址'),
        phone: z.string().optional(),
        shippingMethod: z.enum(['west_malaysia', 'east_malaysia', 'self_pickup', 'lalamove']),
      }))
      .mutation(async ({ input }) => {
        const result = await db.updateOrderShippingAddress(
          input.orderNumber,
          input.token,
          input.address,
          input.phone || '',
          input.shippingMethod,
        );
        if (!result) {
          throw new TRPCError({ code: 'NOT_FOUND', message: '订单不存在或链接无效' });
        }
        return result;
      }),
    // 客户使用专属订单链接提交付款凭证；令牌本身即为订单访问授权。
    submitPaymentReceipt: publicProcedure
      .input(z.object({
        orderNumber: z.string().min(1).max(50),
        token: z.string().min(32).max(128),
        receiptUrl: z.string().min(1).max(500),
        paymentMethodId: z.number().int().positive(),
      }))
      .mutation(async ({ input }) => {

        const order = await db.getOrderBySecureToken(input.orderNumber, input.token);
        if (!order) {
          throw new TRPCError({ code: 'NOT_FOUND', message: '订单不存在或链接无效' });
        }
        if (order.physicalStatus !== 'pending' && order.physicalStatus !== 'partial_payment' && order.physicalStatus !== 'receipt_uploaded') {
          throw new TRPCError({ code: 'BAD_REQUEST', message: '当前订单状态不允许上传付款凭证' });
        }

        try { await assertReceiptBelongsToOrder(input.receiptUrl, order.id); }
        catch { throw new TRPCError({ code: "BAD_REQUEST", message: "付款凭证与订单不匹配" }); }

        const paymentMethod = await db.getPaymentMethodById(input.paymentMethodId);
        if (!paymentMethod?.isEnabled) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: '请选择有效的付款方式' });
        }

        // V2.1.11: Create payment record with paymentSource=customer_upload, reviewStatus=pending
        await db.addOrderPayment({
          orderId: order.id,
          amount: String(order.totalAmount),
          paymentMethod: paymentMethod.name,
          receiptUrl: input.receiptUrl,
          paymentSource: 'customer_upload',
        });
        await db.transitionOrderStatus(order.id, 'receipt_uploaded', '客户结单页', '客户已上传付款凭证');
        await db.updateOrderStatus(order.id, {
          receiptUrl: input.receiptUrl,
          paymentMethodId: paymentMethod.id,
          paymentMethodName: paymentMethod.name,
        });
        return { success: true };
    }),
  }),

  // ===========================================================================
  // V2.2: Public Order Care Pack Router (独立公开知识包；不含订单敏感资料)
  // ===========================================================================
  publicCarePack: router({
    brand: publicProcedure.query(async () => {
      const settings = await db.getSystemSettings();
      return { companyLogoUrl: settings?.companyLogoUrl || null };
    }),
    getByToken: publicProcedure
      .input(z.object({ token: z.string().min(32).max(256) }))
      .query(async ({ input }) => {
        const document = await db.getPublicCarePackByToken(input.token);
        if (!document) {
          throw new TRPCError({ code: "NOT_FOUND", message: "知识包链接无效或已失效" });
        }
        return document;
      }),
    downloadPdf: publicProcedure
      .input(z.object({ token: z.string().min(32).max(256) }))
      .query(async ({ input, ctx }) => {
        const document = await db.getPublicCarePackByToken(input.token);
        if (!document) throw new TRPCError({ code: "NOT_FOUND", message: "知识包链接无效或已失效" });
        const settings = await db.getSystemSettings();
        const requestedHost = String(ctx.req.headers.host || "").toLowerCase();
        let configuredHost = "";
        try { configuredHost = new URL(process.env.ERP_PUBLIC_URL || "").host.toLowerCase(); } catch {}
        const trustedHost = /^(localhost|127\.0\.0\.1)(:\d+)?$/.test(requestedHost)
          || Boolean(configuredHost && requestedHost === configuredHost);
        const assetOrigin = trustedHost ? `${ctx.req.protocol}://${requestedHost}` : null;
        const pdf = await generateCustomerCarePackPdf(document, getCompanyLogoUrl(settings), assetOrigin);
        await db.recordCarePackDeliveryEvent({ token: input.token, action: "customer_save", actorType: "customer", channel: "pdf_download" });
        return { fileName: "心田-商品养护知识包.pdf", contentBase64: pdf.toString("base64") };
      }),
    recordAction: publicProcedure
      .input(z.object({
        token: z.string().min(32).max(256),
        action: z.enum(["customer_view", "customer_save", "customer_print"]),
      }))
      .mutation(async ({ input }) => {
        await db.recordCarePackDeliveryEvent({ token: input.token, action: input.action, actorType: "customer" });
        return { success: true };
      }),
  }),

  // ===========================================================================
  // V2.2: Order Care Pack Administration (订单知识包后台管理)
  // ===========================================================================
  carePacks: router({
    getSettings: adminProcedure.query(async () => db.getCarePackSettings()),
    updateSettings: adminProcedure
      .input(z.object({
        finalizationTrigger: z.enum(["checkout", "packing_start"]).optional(),
        missingContentPolicy: z.enum(["show_notice", "block_finalization", "exclude_item"]).optional(),
        customerTitle: z.string().min(1).max(255).optional(),
        customerIntro: z.string().max(4000).nullable().optional(),
        employeeTitle: z.string().min(1).max(255).optional(),
      }))
      .mutation(async ({ input, ctx }) => db.updateCarePackSettings(input, ctx.user.name || ctx.user.openId)),
    getProductProfiles: adminProcedure
      .input(z.object({ productId: z.number().int().positive() }))
      .query(async ({ input }) => db.getProductCareProfiles(input.productId)),
    upsertProductProfile: adminProcedure
      .input(z.object({
        productId: z.number().int().positive(),
        variationId: z.number().int().nonnegative().default(0),
        profileType: z.enum(["plant", "fertilizer", "pesticide", "medium", "tool", "other"]),
        purpose: z.string().max(5000).nullable().optional(),
        usageMethod: z.string().max(5000).nullable().optional(),
        dosage: z.string().max(5000).nullable().optional(),
        frequency: z.string().max(5000).nullable().optional(),
        suitableFor: z.string().max(5000).nullable().optional(),
        safetyNotes: z.string().max(5000).nullable().optional(),
        additionalNotes: z.string().max(5000).nullable().optional(),
        isEnabled: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => db.upsertProductCareProfile(input, ctx.user.name || ctx.user.openId)),
    getForOrder: adminProcedure
      .input(z.object({ orderId: z.number().int().positive() }))
      .query(async ({ input }) => db.getOrderCarePackForStaff(input.orderId)),
    ensureForOrder: adminProcedure
      .input(z.object({ orderId: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => {
        const ensured = await db.ensureOrderCarePack(input.orderId, ctx.user.name || ctx.user.openId);
        return { pack: ensured.pack, path: db.buildCarePackPath(ensured.token), isNew: ensured.isNew };
      }),
    rebuildForOrder: adminProcedure
      .input(z.object({ orderId: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => {
        const rebuilt = await db.rebuildOrderCarePack(input.orderId, ctx.user.name || ctx.user.openId);
        return { pack: rebuilt.pack, path: db.buildCarePackPath(rebuilt.token), isNew: rebuilt.isNew };
      }),
    revokeForOrder: adminProcedure
      .input(z.object({ orderId: z.number().int().positive(), reason: z.string().min(1).max(1000) }))
      .mutation(async ({ input, ctx }) => db.revokeOrderCarePack(input.orderId, input.reason, ctx.user.name || ctx.user.openId)),
    recordStaffAction: adminProcedure
      .input(z.object({
        orderId: z.number().int().positive(),
        action: z.enum(["manual_resent", "link_copied", "employee_view", "employee_print"]),
      }))
      .mutation(async ({ input, ctx }) => {
        const pack = await db.getOrderCarePackForStaff(input.orderId);
        if (!pack) throw new TRPCError({ code: "NOT_FOUND", message: "订单尚未建立知识包" });
        await db.recordCarePackDeliveryEvent({ carePackId: pack.pack.id, action: input.action, actorType: "staff", actorName: ctx.user.name || ctx.user.openId });
        return { success: true };
      }),
  }),

  // Customer submitted payment proofs, including Messenger screenshots.
  // Approval and rejection stay on order.reviewPayment so balance calculation
  // and audit logging remain centralized.
  paymentProofReviews: router({
    list: adminProcedure.input(z.object({
      status: z.enum(["pending", "approved", "rejected", "all"]).default("pending"),
      limit: z.number().min(1).max(100).default(50),
    })).query(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const conditions = input.status === "all" ? [] : [eqB(orderPayments.reviewStatus, input.status)];
      return await database.select({
        id: orderPayments.id,
        orderId: orderPayments.orderId,
        orderNumber: orders.orderNumber,
        customerName: orders.facebookName,
        amount: orderPayments.amount,
        paymentMethod: orderPayments.paymentMethod,
        receiptUrl: orderPayments.receiptUrl,
        notes: orderPayments.notes,
        paymentSource: orderPayments.paymentSource,
        paymentDate: orderPayments.paymentDate,
        createdAt: orderPayments.createdAt,
        reviewStatus: orderPayments.reviewStatus,
        reviewedBy: orderPayments.reviewedBy,
        reviewedAt: orderPayments.reviewedAt,
        rejectReason: orderPayments.rejectReason,
      }).from(orderPayments)
        .innerJoin(orders, eqB(orderPayments.orderId, orders.id))
        .where(and(...conditions))
        .orderBy(desc(orderPayments.createdAt))
        .limit(input.limit);
    }),
  }),

  // ===========================================================================
  // Facebook Campaign Module (V2.0.21)
  // ===========================================================================
  campaigns: router({
    list: adminProcedure
      .input(z.object({ includeArchived: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        const campaignList = await db.getCampaigns(input?.includeArchived || false);
        // Attach stats for each campaign
        const allStats = await db.getAllCampaignStats();
        const statsMap = new Map(allStats.map((s: any) => [s.campaignId, s]));
        return campaignList.map((c: any) => ({
          ...c,
          stats: statsMap.get(c.id) || { autoOrderCount: 0, mergedOrderCount: 0, totalQuantity: 0, totalRevenue: '0' },
        }));
      }),
    getStats: adminProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCampaignStats(input.campaignId);
      }),
    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const campaign = await db.getCampaignById(input.id);
        if (!campaign) throw new TRPCError({ code: 'NOT_FOUND', message: 'Campaign not found' });
        return campaign;
      }),
    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        type: z.enum(['post', 'reel', 'video']).optional(),
        facebookLink: z.string().optional(),
        facebookPostId: z.string().optional(),
        startDate: z.number().optional(),
        endDate: z.number().optional(),
        autoReplyEnabled: z.boolean().optional(),
        autoReplyText: z.string().optional(),
        messengerFlowEnabled: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createCampaign({
          name: input.name,
          type: input.type as any,
          facebookLink: input.facebookLink,
          facebookPostId: input.facebookPostId,
          startDate: input.startDate ? new Date(input.startDate) : undefined,
          endDate: input.endDate ? new Date(input.endDate) : undefined,
          autoReplyEnabled: input.autoReplyEnabled,
          autoReplyText: input.autoReplyText,
          messengerFlowEnabled: input.messengerFlowEnabled,
        });
      }),
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        type: z.enum(['post', 'reel', 'video']).optional(),
        facebookLink: z.string().optional(),
        facebookPostId: z.string().optional(),
        startDate: z.number().optional(),
        endDate: z.number().optional(),
        status: z.enum(['draft', 'active', 'ended', 'archived']).optional(),
        autoReplyEnabled: z.boolean().optional(),
        autoReplyText: z.string().optional(),
        messengerFlowEnabled: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, startDate, endDate, ...rest } = input;
        const data: any = { ...rest };
        if (startDate !== undefined) data.startDate = new Date(startDate);
        if (endDate !== undefined) data.endDate = new Date(endDate);
        await db.updateCampaign(id, data);
        return { success: true };
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCampaign(input.id);
        return { success: true };
      }),
    duplicate: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.duplicateCampaign(input.id);
      }),
    listFlows: adminProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCampaignFlows(input.campaignId);
      }),
    createFlow: adminProcedure
      .input(z.object({
        campaignId: z.number(),
        sortOrder: z.number().default(0),
        type: z.enum(['text', 'image', 'video', 'audio', 'file', 'product_intro', 'button']),
        text: z.string().optional(),
        mediaUrl: z.string().optional(),
        mediaType: z.string().optional(),
        buttonConfig: z.string().optional(),
        productId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createCampaignFlow(input as any);
      }),
    updateFlow: adminProcedure
      .input(z.object({
        id: z.number(),
        sortOrder: z.number().optional(),
        type: z.enum(['text', 'image', 'video', 'audio', 'file', 'product_intro', 'button']).optional(),
        text: z.string().optional(),
        mediaUrl: z.string().optional(),
        mediaType: z.string().optional(),
        buttonConfig: z.string().optional(),
        productId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCampaignFlow(id, data as any);
        return { success: true };
      }),
    deleteFlow: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCampaignFlow(input.id);
        return { success: true };
      }),
    listButtons: adminProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCampaignButtons(input.campaignId);
      }),
    createButton: adminProcedure
      .input(z.object({
        campaignId: z.number(),
        flowId: z.number().optional(),
        name: z.string().min(1),
        productId: z.number(),
        variantId: z.number().optional(),
        quantity: z.number().min(1).default(1),
        sortOrder: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        return await db.createCampaignButton(input as any);
      }),
    updateButton: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        productId: z.number().optional(),
        variantId: z.number().optional(),
        quantity: z.number().optional(),
        sortOrder: z.number().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCampaignButton(id, data as any);
        return { success: true };
      }),
    deleteButton: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCampaignButton(input.id);
        return { success: true };
      }),
    // Content ID management
    listContentIds: adminProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCampaignContentIds(input.campaignId);
      }),
    addContentId: adminProcedure
      .input(z.object({
        campaignId: z.number(),
        contentType: z.enum(['post', 'reel', 'video']).optional(),
        contentId: z.string().optional(),
        facebookLink: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        // If only link provided, auto-parse
        if (input.facebookLink && !input.contentId) {
          const parsed = db.parseFacebookLink(input.facebookLink);
          const contentId = parsed.facebookPostId || parsed.facebookVideoId || '';
          if (!contentId) throw new TRPCError({ code: 'BAD_REQUEST', message: '无法从链接中解析出内容 ID' });
          return await db.addCampaignContentId({
            campaignId: input.campaignId,
            contentType: parsed.contentType as any,
            contentId,
            facebookLink: input.facebookLink,
          });
        }
        return await db.addCampaignContentId({
          campaignId: input.campaignId,
          contentType: (input.contentType || 'post') as any,
          contentId: input.contentId || '',
          facebookLink: input.facebookLink,
        });
      }),
    removeContentId: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.removeCampaignContentId(input.id);
        return { success: true };
      }),
  }),
  // ===========================================================================
  // 虚拟交付：会员、课程、资料包（Meta 自动私聊后续接入）
  // ===========================================================================
  virtualDelivery: router({
    listProducts: adminProcedure.query(async () => {
      return await db.listVirtualDeliveryProducts();
    }),
    createProduct: adminProcedure
      .input(z.object({
        name: z.string().trim().min(1, "请输入虚拟商品名称"),
        deliveryType: z.enum(["membership", "course", "resource", "material_kit"]),
        keyword: z.string().trim().max(64, "关键词不能超过64个字").optional(),
        description: z.string().optional(),
        defaultDeliveryMessage: z.string().optional(),
        coverImageUrl: z.string().url("商品图片必须是完整网址").optional().or(z.literal("")),
        allowMixedCheckout: z.boolean().default(true),
        syncToMall: z.boolean().default(false),
        packages: z.array(z.object({
          name: z.string().trim(),
          sellingPrice: z.string().regex(/^\d+(\.\d{1,2})?$/, "请输入有效售价"),
          contentCost: z.string().regex(/^\d+(\.\d{1,2})?$/, "请输入有效内容成本"),
          deliveryLink: z.string().url("交付链接必须是完整网址").optional().or(z.literal("")),
          deliveryMessage: z.string().optional(),
          imageUrl: z.string().url("配套图片必须是完整网址").optional().or(z.literal("")),
          weightKg: z.string().regex(/^\d+(\.\d{1,2})?$/, "请输入有效重量").optional(),
          keyword: z.string().trim().max(64, "关键词不能超过64个字").optional(),
        })).min(1, "请至少建立一个交付配套"),
      }).refine((value) => value.deliveryType !== "material_kit" || value.packages.every((pkg) => Number(pkg.weightKg || 0) > 0), {
        message: "实体材料包的每个配套必须填写大于0的单包重量（kg）",
        path: ["packages"],
      }))
      .mutation(async ({ input }) => {
        return await db.createVirtualDeliveryProduct(input);
      }),
    updateProduct: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().trim().min(1, "请输入虚拟商品名称").optional(),
        keyword: z.string().trim().max(64, "关键词不能超过64个字").optional(),
        description: z.string().optional(),
        defaultDeliveryMessage: z.string().optional(),
        coverImageUrl: z.string().url().optional().or(z.literal("")),
        allowMixedCheckout: z.boolean().optional(),
        syncToMall: z.boolean().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateVirtualDeliveryProduct(id, data);
        return { success: true };
      }),
    updatePackage: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().trim().min(1).optional(),
        keyword: z.string().trim().max(64, "关键词不能超过64个字").optional(),
        sellingPrice: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
        contentCost: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
        deliveryLink: z.string().url().optional().or(z.literal("")),
        deliveryMessage: z.string().optional(),
        imageUrl: z.string().url().optional().or(z.literal("")),
        weightKg: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateVirtualDeliveryPackage(id, data);
        return { success: true };
      }),
    listTasks: adminProcedure
      .input(z.object({ status: z.enum(["pending_manual", "sent", "failed", "cancelled"]).optional() }).optional())
      .query(async ({ input }) => {
        return await db.listVirtualDeliveryTasks(input?.status);
      }),
    markTaskSent: adminProcedure
      .input(z.object({ id: z.number(), notes: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        await db.markVirtualDeliveryTaskSent(input.id, ctx.user.id, input.notes);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
