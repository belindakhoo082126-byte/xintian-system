import { mkdtemp, rm, symlink, stat, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { LocalFileStore } from "./localFileStore";

describe("independent filesystem storage", () => {
  let root: string;
  beforeEach(async () => { root = await mkdtemp(path.join(os.tmpdir(), "xintian-files-")); });
  afterEach(async () => { await rm(root, { recursive: true, force: true }); });
  it("persists bytes and private metadata across instances with restrictive permissions", async () => {
    const store = new LocalFileStore(root);
    const item = await store.put(Buffer.from("receipt"), { filename: "../../receipt.png", contentType: "image/png" });
    expect(item.visibility).toBe("private");
    expect(item.filename).toBe("receipt.png");
    const loaded = await new LocalFileStore(root).read(item.id);
    expect(loaded.data.toString()).toBe("receipt");
    expect(loaded.metadata).toEqual(item);
    expect((await stat(path.join(root, item.id, "data"))).mode & 0o777).toBe(0o600);
  });
  it("does not overwrite files sharing an original filename", async () => {
    const store = new LocalFileStore(root);
    const options = { filename: "plant.jpg", contentType: "image/jpeg", visibility: "public" as const };
    const a = await store.put(Buffer.from("one"), options);
    const b = await store.put(Buffer.from("two"), options);
    expect(a.id).not.toBe(b.id);
    expect((await store.read(a.id)).data.toString()).toBe("one");
  });
  it("rejects traversal, empty and oversized uploads", async () => {
    const store = new LocalFileStore(root, 5);
    await expect(store.read("../secret")).rejects.toThrow();
    await expect(store.put(Buffer.alloc(0), { filename: "x", contentType: "image/png" })).rejects.toThrow();
    await expect(store.put(Buffer.alloc(6), { filename: "x", contentType: "image/png" })).rejects.toThrow();
  });
  it("rejects symlink data files and tampered size", async () => {
    const store = new LocalFileStore(root);
    const item = await store.put(Buffer.from("receipt"), { filename: "r", contentType: "image/png" });
    const target = path.join(root, item.id, "data");
    await writeFile(target, "changed-size");
    await expect(store.read(item.id)).rejects.toThrow("size mismatch");
    await rm(target); await symlink(path.join(root, item.id, "metadata.json"), target);
    await expect(store.read(item.id)).rejects.toThrow();
  });
});
