import { describe, expect, it } from 'vitest';
import { compareDatabaseColumns, type AuditColumn } from './databaseSchemaAudit';
const column: AuditColumn = { table: 'orders', name: 'id', type: 'int', notNull: true, primary: true, autoIncrement: true };
describe('read-only schema comparison', () => {
  it('accepts exact metadata and MySQL boolean spelling', () => {
    expect(compareDatabaseColumns([column], [{...column}])).toEqual([]);
    expect(compareDatabaseColumns([{...column,type:'boolean'}], [{...column,type:'tinyint(1)'}])).toEqual([]);
  });
  it('reports missing and unexpected columns', () => {
    expect(compareDatabaseColumns([column], [{...column,name:'other'}])).toEqual(['orders.id: missing','orders.other: unexpected']);
  });
  it('detects type, required, key and generated-id differences', () => {
    expect(compareDatabaseColumns([column], [{...column,type:'bigint',notNull:false,primary:false,autoIncrement:false}])).toHaveLength(4);
  });
  it('preserves enum value case because values are meaningful', () => {
    expect(compareDatabaseColumns([{...column,type:"enum('Cash')"}], [{...column,type:"enum('cash')"}])).toContain('orders.id: type differs');
  });
});
