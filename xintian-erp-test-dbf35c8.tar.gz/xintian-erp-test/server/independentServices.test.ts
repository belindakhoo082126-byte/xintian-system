import { afterEach, describe, expect, it, vi } from "vitest";
import { notifyOwner } from "./_core/notification";
import { createHeartbeatJob } from "./_core/heartbeat";
import { transcribeAudio } from "./_core/voiceTranscription";
import { generateImage } from "./_core/imageGeneration";
import { callDataApi } from "./_core/dataApi";
import { makeRequest } from "./_core/map";

afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); vi.resetModules(); });

describe("independent service adapters", () => {
  it("fails explicitly without making network calls for unconnected capabilities", async () => {
    const fetch = vi.fn(); vi.stubGlobal("fetch", fetch);
    for (const call of [
      () => notifyOwner({ title: "t", content: "c" }),
      () => createHeartbeatJob({ name: "t", cron: "0 0 9 * * *", path: "/api/scheduled/test" }, ""),
      () => transcribeAudio({ audioUrl: "https://example.com/audio.ogg" }),
      () => generateImage({ prompt: "plant" }),
      () => callDataApi("test"),
      () => makeRequest("/maps/api/test"),
    ]) await expect(call()).rejects.toMatchObject({ code: "PRECONDITION_FAILED" });
    expect(fetch).not.toHaveBeenCalled();
  });
  it("does not fall back to a cloud endpoint or use legacy keys", async () => {
    vi.stubEnv("LLM_BASE_URL", ""); vi.stubEnv("LLM_API_KEY", "");
    vi.stubEnv("BUILT_IN_FORGE_API_URL", "https://forge.manus.im"); vi.stubEnv("BUILT_IN_FORGE_API_KEY", "legacy");
    vi.resetModules();
    const { invokeLLM } = await import("./_core/llm");
    const fetch = vi.fn(); vi.stubGlobal("fetch", fetch);
    await expect(invokeLLM({ messages: [{ role: "user", content: "test" }] })).rejects.toThrow("未配置");
    expect(fetch).not.toHaveBeenCalled();
  });
  it("resolves an explicitly configured compatible API and rejects Manus endpoints", async () => {
    vi.stubEnv("LLM_BASE_URL", "https://provider.example/v1"); vi.stubEnv("LLM_API_KEY", "own-key"); vi.resetModules();
    const first = await import("./_core/llm");
    expect(first.resolveLlmEndpoint("chat/completions")).toBe("https://provider.example/v1/chat/completions");
    expect(first.resolveLlmEndpoint("models")).toBe("https://provider.example/v1/models");
    vi.stubEnv("LLM_BASE_URL", "https://forge.manus.im/v1"); vi.resetModules();
    const second = await import("./_core/llm");
    expect(() => second.resolveLlmEndpoint("models")).toThrow("不允许");
  });
});
