export type AuditColumn = { table: string; name: string; type: string; notNull: boolean; primary: boolean; autoIncrement: boolean };
const normalize = (value: string) => value.replace(/^[a-z]+/i, keyword => keyword.toLowerCase()).replace(/^integer$/, 'int').replace(/^boolean$/, 'tinyint(1)');
export function compareDatabaseColumns(expected: AuditColumn[], actual: AuditColumn[]) {
  const key = (column: AuditColumn) => `${column.table}.${column.name}`;
  const actualMap = new Map(actual.map(column => [key(column), column]));
  const expectedKeys = new Set(expected.map(key));
  const differences: string[] = [];
  for (const column of expected) {
    const found = actualMap.get(key(column));
    if (!found) { differences.push(`${key(column)}: missing`); continue; }
    if (normalize(column.type) !== normalize(found.type)) differences.push(`${key(column)}: type differs`);
    for (const field of ['notNull', 'primary', 'autoIncrement'] as const) {
      if (column[field] !== found[field]) differences.push(`${key(column)}: ${field} differs`);
    }
  }
  for (const column of actual) if (!expectedKeys.has(key(column))) differences.push(`${key(column)}: unexpected`);
  return differences;
}
