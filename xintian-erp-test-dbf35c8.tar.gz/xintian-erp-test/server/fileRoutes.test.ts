import express from "express";
import type { Server } from "node:http";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { LocalFileStore } from "./localFileStore";
import { assertReceiptBelongsToOrder, registerFileRoutes } from "./fileRoutes";

describe("local HTTP file authorization", () => {
  let root: string, base: string, server: Server;
  let store: LocalFileStore;
  const token = "a".repeat(64);
  const tokenOrder = vi.fn(async (number: string, value: string) => value === token && number === "XT1" ? { id: 1, physicalStatus: "pending" } : null);
  beforeEach(async () => {
    root = await mkdtemp(path.join(os.tmpdir(), "xintian-http-files-"));
    store = new LocalFileStore(root);
    vi.stubEnv("ERP_STORAGE_DIR", root);
    const app = express(); app.use(express.json());
    registerFileRoutes(app, { store, staff: async req => req.get("x-test-staff") === "yes" ? { id: 1 } : null, tokenOrder, phoneOrder: async () => null });
    await new Promise<void>(resolve => { server = app.listen(0, "127.0.0.1", resolve); });
    const address = server.address(); if (!address || typeof address === "string") throw new Error("Missing address");
    base = `http://127.0.0.1:${address.port}`;
  });
  afterEach(async () => {
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
    await rm(root, { recursive: true, force: true });
    vi.unstubAllEnvs();
  });
  const image = { filename: "plant.png", file: `data:image/png;base64,${Buffer.from([137,80,78,71,13,10,26,10,1]).toString("base64")}` };
  const post = (endpoint: string, body: unknown, staff = false) => fetch(base + endpoint, { method: "POST", headers: { Origin: base, "Content-Type": "application/json", ...(staff ? { "x-test-staff": "yes" } : {}) }, body: JSON.stringify(body) });
  it("requires staff authentication for generic uploads and rejects cross-origin requests", async () => {
    expect((await post("/api/upload", image)).status).toBe(401);
    const r = await fetch(base + "/api/upload", { method: "POST", headers: { Origin: "https://other.example", "Content-Type": "application/json", "x-test-staff": "yes" }, body: JSON.stringify(image) });
    expect(r.status).toBe(403);
  });
  it("serves public product images but blocks anonymous receipt access", async () => {
    const publicUpload = await post("/api/upload", image, true);
    expect(publicUpload.status).toBe(200);
    const publicFile = await publicUpload.json();
    expect((await fetch(base + publicFile.url)).status).toBe(200);
    const privateUpload = await post("/api/upload", { ...image, purpose: "private" }, true);
    const privateFile = await privateUpload.json();
    expect((await fetch(base + privateFile.url)).status).toBe(404);
    const authorized = await fetch(base + privateFile.url, { headers: { "x-test-staff": "yes" } });
    expect(authorized.status).toBe(200);
    expect(authorized.headers.get("cache-control")).toBe("no-store");
    expect(authorized.headers.get("x-content-type-options")).toBe("nosniff");
  });
  it("binds customer uploads to verified orders and requires the matching order on download", async () => {
    expect((await post("/api/receipts/upload", { ...image, orderNumber: "XT1", token: "wrong" })).status).toBe(403);
    const upload = await post("/api/receipts/upload", { ...image, orderNumber: "XT1", token });
    expect(upload.status).toBe(200);
    const file = await upload.json();
    expect((await store.read(file.key)).metadata).toMatchObject({ orderId: 1, visibility: "private" });
    await expect(assertReceiptBelongsToOrder(file.url, 1)).resolves.toBeUndefined();
    await expect(assertReceiptBelongsToOrder(file.url, 2)).rejects.toThrow("不匹配");
    expect((await fetch(base + file.url)).status).toBe(404);
    expect((await fetch(base + file.url + `?orderNumber=XT2&token=${token}`)).status).toBe(404);
    expect((await fetch(base + file.url + `?orderNumber=XT1&token=${token}`)).status).toBe(200);
  });
  it("rejects disguised active content and does not contact old cloud storage", async () => {
    const r = await post("/api/upload", { filename: "x.png", file: `data:image/png;base64,${Buffer.from("<script>alert(1)</script>").toString("base64")}` }, true);
    expect(r.status).toBe(400);
    expect((await fetch(base + "/manus-storage/old/file.png")).status).toBe(410);
  });
});
