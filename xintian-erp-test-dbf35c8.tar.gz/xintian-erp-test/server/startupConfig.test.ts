import { describe, expect, it } from 'vitest';
import { getListenConfig } from './_core/startupConfig';
describe('isolated ERP listener', () => {
  it('defaults to dedicated loopback port 8003', () => {
    expect(getListenConfig({})).toEqual({host:'127.0.0.1',port:8003});
    expect(getListenConfig({HOST:'::1',PORT:'8010'})).toEqual({host:'::1',port:8010});
  });
  it('rejects malformed ports instead of truncating or selecting an alternate', () => {
    for(const PORT of ['', '0','65536','8003abc','3.5','-1',' 8003']) expect(()=>getListenConfig({PORT})).toThrow();
  });
  it('requires the reverse proxy for public access', () => {
    for(const HOST of ['0.0.0.0','::','example.com','']) expect(()=>getListenConfig({HOST})).toThrow();
  });
});
