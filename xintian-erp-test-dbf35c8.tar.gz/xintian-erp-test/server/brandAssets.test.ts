// Include shared asset contract checks in the configured server/client suite.
import "../shared/brandAssets.test";
