import type { Express } from 'express';
import { authenticateStaff } from './localAuth';
import { addSSEClient } from './realtime';

export function registerSyncRoute(app: Express) {
  app.get('/api/sync', async (req, res) => {
    res.set('Cache-Control', 'no-store');
    try {
      if (!await authenticateStaff(req)) { res.status(401).json({ error: '请先登录员工账号' }); return; }
    } catch {
      res.status(503).json({ error: '登录验证暂不可用' }); return;
    }
    if (req.destroyed || res.destroyed) return;
    const cleanup = addSSEClient(res);
    // Reconnect regularly so logout, password reset and expiry are rechecked.
    const expiry = setTimeout(() => res.end(), 60_000);
    expiry.unref();
    res.on('close', () => { clearTimeout(expiry); cleanup(); });
  });
}
