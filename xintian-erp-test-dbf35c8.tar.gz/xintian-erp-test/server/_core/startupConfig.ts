export function getListenConfig(env: NodeJS.ProcessEnv = process.env) {
  const value = env.PORT ?? '8003';
  if (!/^[0-9]+$/.test(value) || Number(value) < 1 || Number(value) > 65535) throw new Error('PORT must be an integer from 1 to 65535');
  const host = env.HOST ?? '127.0.0.1';
  if (!['127.0.0.1', '::1'].includes(host)) throw new Error('HOST must be a loopback address; expose ERP through the reverse proxy');
  return { port: Number(value), host };
}
