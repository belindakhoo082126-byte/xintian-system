import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerLocalAuthRoutes } from "./localAuth";
import { registerFileRoutes } from "../fileRoutes";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { registerSyncRoute } from "./syncRoute";
import { getListenConfig } from "./startupConfig";

async function startServer() {
  const { host, port } = getListenConfig();
  const app = express();
  app.set("trust proxy", 1);
  const server = createServer(app);

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerFileRoutes(app);
  registerLocalAuthRoutes(app);

  registerSyncRoute(app);

  // Meta/Facebook Webhook 与任何周期任务均在用户明确授权并完成配置前不注册。
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => {
      server.off("error", reject);
      resolve();
    });
  });
  console.log(`ERP listening on ${host}:${port}`);
}

startServer().catch(() => {
  console.error("ERP startup failed. Check configured port, local address and build files; no alternate port was selected.");
  process.exitCode = 1;
});
