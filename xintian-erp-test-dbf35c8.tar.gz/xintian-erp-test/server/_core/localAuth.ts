import { createHash, randomBytes } from "node:crypto";
import { and, eq, gt } from "drizzle-orm";
import { parse } from "cookie";
import type { Express, Request } from "express";
import { COOKIE_NAME } from "../../shared/const";
import { staffCredentials, staffSessions, users } from "../../drizzle/schema";
import { getDb } from "../db";
import { getSessionCookieOptions } from "./cookies";
import { hashPassword, verifyPassword } from "./password";

const SESSION_MS = 8 * 60 * 60 * 1000;
const digest = (value: string) => createHash("sha256").update(value).digest("hex");
const attempts = new Map<string, { count: number; expires: number }>();
let dummyHash: Promise<string> | undefined;

export function normalizeUsername(value: string): string {
  const username = value.trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9._-]{2,63}$/.test(username)) throw new Error("账号须为3至64位英文字母、数字、点、下划线或短横线");
  return username;
}

function tokenFrom(req: Request) {
  const token = parse(req.headers.cookie ?? "")[COOKIE_NAME];
  return token && /^[a-f0-9]{64}$/.test(token) ? token : null;
}

export async function authenticateStaff(req: Request) {
  const token = tokenFrom(req);
  if (!token) return null;
  const database = await getDb();
  if (!database) throw new Error("Database unavailable");
  const [row] = await database.select({ user: users }).from(staffSessions)
    .innerJoin(staffCredentials, eq(staffSessions.userId, staffCredentials.userId))
    .innerJoin(users, eq(staffSessions.userId, users.id))
    .where(and(eq(staffSessions.tokenHash, digest(token)), gt(staffSessions.expiresAt, new Date()), eq(staffCredentials.enabled, true))).limit(1);
  return row?.user ?? null;
}

export async function revokeStaffSession(req: Request) {
  const token = tokenFrom(req);
  if (!token) return;
  const database = await getDb();
  if (!database) throw new Error("Database unavailable");
  await database.delete(staffSessions).where(eq(staffSessions.tokenHash, digest(token)));
}

export function registerLocalAuthRoutes(app: Express) {
  app.post("/api/auth/login", async (req, res) => {
    // The browser login uses JSON and an exact same-origin request.
    const origin = req.get("origin");
    if (!req.is("application/json") || !origin || origin !== `${req.protocol}://${req.get("host")}`) {
      res.status(403).json({ error: "请从心田系统登录页面提交" }); return;
    }
    const now = Date.now();
    attempts.forEach((value, key) => { if (value.expires <= now) attempts.delete(key); });
    const key = req.ip ?? "unknown";
    const attempt = attempts.get(key) ?? { count: 0, expires: now + 15 * 60 * 1000 };
    if (attempt.count >= 10 || (!attempts.has(key) && attempts.size >= 10000)) {
      res.set("Retry-After", "900").status(429).json({ error: "尝试次数过多，请稍后再试" }); return;
    }
    attempt.count += 1; attempts.set(key, attempt);
    const { username, password } = req.body ?? {};
    if (typeof username !== "string" || typeof password !== "string" || username.length > 64 || Buffer.byteLength(password) > 1024) {
      res.status(400).json({ error: "请输入有效账号和密码" }); return;
    }
    try {
      let normalized: string;
      try { normalized = normalizeUsername(username); } catch { normalized = ""; }
      const database = await getDb();
      if (!database) throw new Error("Database unavailable");
      const [credential] = await database.select().from(staffCredentials).where(eq(staffCredentials.username, normalized)).limit(1);
      dummyHash ??= hashPassword(randomBytes(32).toString("hex"));
      const valid = await verifyPassword(password, credential?.passwordHash ?? await dummyHash);
      if (!valid || !credential?.enabled) { res.status(401).json({ error: "账号或密码错误" }); return; }
      const [user] = await database.select().from(users).where(eq(users.id, credential.userId)).limit(1);
      if (!user) { res.status(401).json({ error: "账号或密码错误" }); return; }
      await revokeStaffSession(req);
      const token = randomBytes(32).toString("hex");
      await database.insert(staffSessions).values({ userId: user.id, tokenHash: digest(token), expiresAt: new Date(now + SESSION_MS) });
      await database.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));
      res.set("Cache-Control", "no-store");
      res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(req), maxAge: SESSION_MS });
      res.json({ success: true });
    } catch {
      res.status(503).json({ error: "登录服务暂不可用，请检查数据库初始化及服务状态" });
    }
  });
}
