import { TRPCError } from "@trpc/server";

// Independent deployment: this capability must be connected explicitly.

export type NotificationPayload = {
  title: string;
  content: string;
};

export async function notifyOwner(
  payload: NotificationPayload
): Promise<boolean> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "管理员外部通知尚未配置，功能未执行" }); }
