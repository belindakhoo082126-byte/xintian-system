import { TRPCError } from "@trpc/server";

// Independent deployment: this capability must be connected explicitly.

export type GenerateImageOptions = {
  prompt: string;
  originalImages?: Array<{
    url?: string;
    b64Json?: string;
    mimeType?: string;
  }>;
  /** Forge image model enum, e.g. "MODEL_GPT_IMAGE_2". Defaults to GPT Image 2. */
  model?: string;
  /** Generation quality, e.g. "medium" | "high". Defaults to "medium" for GPT Image 2. */
  quality?: string;
};

export type GenerateImageResponse = {
  url?: string;
};

export async function generateImage(
  options: GenerateImageOptions
): Promise<GenerateImageResponse> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "ERP内置做图（独立做图系统尚未对接）尚未配置，功能未执行" }); }

export type ImageModelInfo = {
  /** Forge model enum, e.g. "MODEL_GPT_IMAGE_2". Pass into generateImage({ model }). */
  model?: string;
  /** Stable model id, e.g. "gpt-image-2". */
  id?: string;
};

export type ListImageModelsResponse = {
  models: ImageModelInfo[];
};

export async function listImageModels(): Promise<ListImageModelsResponse> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "ERP内置做图（独立做图系统尚未对接）尚未配置，功能未执行" }); }
