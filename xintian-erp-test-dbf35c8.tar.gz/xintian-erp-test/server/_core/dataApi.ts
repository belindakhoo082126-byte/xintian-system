import { TRPCError } from "@trpc/server";

// Independent deployment: this capability must be connected explicitly.

export type DataApiCallOptions = {
  query?: Record<string, unknown>;
  body?: Record<string, unknown>;
  pathParams?: Record<string, unknown>;
  formData?: Record<string, unknown>;
};

export async function callDataApi(
  apiId: string,
  options: DataApiCallOptions = {}
): Promise<unknown> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "外部资料查询尚未配置，功能未执行" }); }
