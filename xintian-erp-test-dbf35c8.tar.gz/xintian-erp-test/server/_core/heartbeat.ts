import { TRPCError } from "@trpc/server";

// Independent deployment: this capability must be connected explicitly.

export type HeartbeatJob = {
  name: string;
  /**
   * 6-field cron with seconds (`sec min hour dom mon dow`), UTC, min interval 60s.
   * Use `0` for the seconds field — e.g. `"0 0 9 * * *"` is daily 09:00 UTC.
   * See /home/ubuntu/skills/webdev-periodic-updates/SKILL.md.
   */
  cron: string;
  /** Callback path. MUST start with `/api/scheduled/`. */
  path: string;
  method?: "POST" | "PUT";
  payload?: unknown;
  description?: string;
};

export type HeartbeatJobUpdate = Partial<Omit<HeartbeatJob, "name">> & {
  enable?: boolean;
};

export type HeartbeatJobInfo = {
  taskUid: string;
  name: string;
  userId: string;
  description: string;
  cronExpression: string;
  callbackPath: string;
  callbackMethod: string;
  callbackPayload: string;
  isEnable: boolean;
  createdAt?: string | null;
  lastExecutedAt?: string | null;
  nextExecutionAt?: string | null;
};

export async function createHeartbeatJob(
  job: HeartbeatJob,
  userSession: string
): Promise<{ taskUid: string; nextExecutionAt?: string | null }> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "自动排程尚未配置，功能未执行" }); }

export async function updateHeartbeatJob(
  taskUid: string,
  patch: HeartbeatJobUpdate,
  userSession: string
): Promise<{ nextExecutionAt?: string | null }> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "自动排程尚未配置，功能未执行" }); }

export async function deleteHeartbeatJob(
  taskUid: string,
  userSession: string
): Promise<void> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "自动排程尚未配置，功能未执行" }); }

export async function listHeartbeatJobs(
  userSession: string,
  pagination?: { page?: number; pageSize?: number }
): Promise<{ total: number; actorUserId: string; jobs: HeartbeatJobInfo[] }> { throw new TRPCError({ code: "PRECONDITION_FAILED", message: "自动排程尚未配置，功能未执行" }); }
