import { EventEmitter } from 'node:events';
import { afterEach, describe, expect, it, vi } from 'vitest';
vi.mock('./_core/localAuth',()=>({authenticateStaff:vi.fn()}));
vi.mock('./_core/realtime',()=>({addSSEClient:vi.fn()}));
import {authenticateStaff} from './_core/localAuth';
import {addSSEClient} from './_core/realtime';
import {registerSyncRoute} from './_core/syncRoute';
function setup(){
  let handler: any;
  registerSyncRoute({get: (_path: string, callback: any)=>{handler=callback;}} as any);
  const res=Object.assign(new EventEmitter(),{set:vi.fn(),status:vi.fn().mockReturnThis(),json:vi.fn(),end:vi.fn(),destroyed:false});
  return {handler,res};
}
afterEach(()=>{vi.resetAllMocks();vi.useRealTimers();});
describe('staff-only realtime stream',()=>{
  it('rejects anonymous callers without registering a stream',async()=>{
    vi.mocked(authenticateStaff).mockResolvedValue(null);
    const {handler,res}=setup();await handler({},res);
    expect(res.status).toHaveBeenCalledWith(401);expect(addSSEClient).not.toHaveBeenCalled();
  });
  it('returns unavailable when authentication fails',async()=>{
    vi.mocked(authenticateStaff).mockRejectedValue(Error('database unavailable'));
    const {handler,res}=setup();await handler({},res);
    expect(res.status).toHaveBeenCalledWith(503);expect(addSSEClient).not.toHaveBeenCalled();
  });
  it('reconnects authenticated streams and cleans up closed responses',async()=>{
    vi.useFakeTimers();vi.mocked(authenticateStaff).mockResolvedValue({id:1} as any);
    const cleanup=vi.fn();vi.mocked(addSSEClient).mockReturnValue(cleanup);
    const {handler,res}=setup();await handler({},res);
    expect(addSSEClient).toHaveBeenCalledWith(res);
    vi.advanceTimersByTime(60_000);expect(res.end).toHaveBeenCalledOnce();
    res.emit('close');expect(cleanup).toHaveBeenCalledOnce();expect(vi.getTimerCount()).toBe(0);
  });
});
