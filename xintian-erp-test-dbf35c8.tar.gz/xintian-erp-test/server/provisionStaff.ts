import "dotenv/config";
import { eq } from "drizzle-orm";
import { getDb } from "./db";
import { staffCredentials, staffSessions, users } from "../drizzle/schema";
import { normalizeUsername } from "./_core/localAuth";
import { hashPassword } from "./_core/password";

async function main() {
  const username = normalizeUsername(process.env.ERP_STAFF_USERNAME ?? "");
  const passwordHash = await hashPassword(process.env.ERP_STAFF_PASSWORD ?? "");
  delete process.env.ERP_STAFF_PASSWORD;
  const role = process.env.ERP_STAFF_ROLE;
  if (role !== "admin" && role !== "user") throw new Error("ERP_STAFF_ROLE must be admin or user");
  const database = await getDb();
  if (!database) throw new Error("Database unavailable");
  await database.transaction(async tx => {
    const [existing] = await tx.select().from(staffCredentials).where(eq(staffCredentials.username, username)).limit(1);
    let userId = existing?.userId;
    if (!userId) {
      const result = await tx.insert(users).values({ openId: `local:${username}`, name: process.env.ERP_STAFF_NAME || username, loginMethod: "password", role }).$returningId();
      userId = result[0].id;
      await tx.insert(staffCredentials).values({ userId, username, passwordHash, enabled: true });
    } else {
      await tx.update(staffCredentials).set({ passwordHash, enabled: true }).where(eq(staffCredentials.userId, userId));
      await tx.update(users).set({ role, name: process.env.ERP_STAFF_NAME || username }).where(eq(users.id, userId));
      await tx.delete(staffSessions).where(eq(staffSessions.userId, userId));
    }
  });
  console.log("Staff account provisioned; existing sessions revoked on password reset.");
}

main().then(() => process.exit(0)).catch(() => {
  console.error("Staff provisioning failed: check database, migration, username, role and password (minimum 12 characters). No credentials are printed.");
  process.exit(1);
});
