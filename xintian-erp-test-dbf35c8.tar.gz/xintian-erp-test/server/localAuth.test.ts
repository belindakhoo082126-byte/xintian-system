import express from "express";
import type { Server } from "node:http";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./_core/password";
import { authenticateStaff, normalizeUsername, registerLocalAuthRoutes } from "./_core/localAuth";
import { COOKIE_NAME } from "../shared/const";

describe("local staff credentials", () => {
  it("salts password hashes and rejects incorrect passwords and malformed hashes", async () => {
    const password = "unique-long-password-2026";
    const first = await hashPassword(password);
    const second = await hashPassword(password);
    expect(first).not.toEqual(second);
    expect(first).not.toContain(password);
    expect(await verifyPassword(password, first)).toBe(true);
    expect(await verifyPassword("wrong-password", first)).toBe(false);
    expect(await verifyPassword(password, "scrypt$invalid$invalid")).toBe(false);
    await expect(hashPassword("short")).rejects.toThrow();
  });
  it("normalizes usernames and rejects ambiguous or invalid identifiers", () => {
    expect(normalizeUsername("  Nana.01 ")).toBe("nana.01");
    expect(() => normalizeUsername("../admin")).toThrow();
    expect(() => normalizeUsername("a")).toThrow();
  });
  it("does not accept old JWT cookies or Authorization preview tokens", async () => {
    expect(await authenticateStaff({ headers: { authorization: "Bearer preview-token" } } as any)).toBeNull();
    expect(await authenticateStaff({ headers: { cookie: `${COOKIE_NAME}=eyJ.legacy.jwt` } } as any)).toBeNull();
  });
});

describe("login HTTP boundaries without a database", () => {
  let server: Server;
  let base: string;
  beforeAll(async () => {
    const app = express(); app.use(express.json()); registerLocalAuthRoutes(app);
    await new Promise<void>(resolve => { server = app.listen(0, "127.0.0.1", resolve); });
    const address = server.address();
    if (!address || typeof address === "string") throw new Error("Missing test address");
    base = `http://127.0.0.1:${address.port}`;
  });
  afterAll(async () => { await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve())); });
  it("rejects cross-origin and form login requests before looking up credentials", async () => {
    const crossOrigin = await fetch(`${base}/api/auth/login`, { method: "POST", headers: { Origin: "https://untrusted.example", "Content-Type": "application/json" }, body: "{}" });
    expect(crossOrigin.status).toBe(403);
    const form = await fetch(`${base}/api/auth/login`, { method: "POST", headers: { Origin: base, "Content-Type": "application/x-www-form-urlencoded" }, body: "username=admin" });
    expect(form.status).toBe(403);
  });
  it("rejects malformed input and limits repeated attempts", async () => {
    const statuses = [];
    for (let i = 0; i < 11; i++) {
      const response = await fetch(`${base}/api/auth/login`, { method: "POST", headers: { Origin: base, "Content-Type": "application/json" }, body: "{}" });
      statuses.push(response.status);
    }
    expect(statuses[0]).toBe(400);
    expect(statuses[10]).toBe(429);
  });
});
