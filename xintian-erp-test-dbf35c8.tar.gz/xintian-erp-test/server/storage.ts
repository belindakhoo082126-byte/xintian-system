import { fileStore, fileUrl } from "./fileRoutes";

export async function storagePut(relKey: string, data: Buffer | Uint8Array | string, contentType = "application/octet-stream", options: { visibility?: "public" | "private"; orderId?: number } = {}) {
  const stored = await fileStore().put(Buffer.from(data), { filename: relKey, contentType, ...options });
  return { key: stored.id, url: fileUrl(stored.id) };
}
export async function storageGet(key: string) {
  await fileStore().read(key);
  return { key, url: fileUrl(key) };
}
export async function storageGetSignedUrl(key: string) {
  const { metadata } = await fileStore().read(key);
  if (metadata.visibility !== "public") throw new Error("Private files require authorized access");
  return fileUrl(key);
}
