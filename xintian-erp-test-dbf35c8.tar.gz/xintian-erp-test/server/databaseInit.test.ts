import { execFileSync, spawnSync } from "node:child_process";
import { describe, expect, it } from "vitest";

describe("empty ERP database initializer safety", () => {
  const env = { ...process.env, DATABASE_URL: "", ERP_DATABASE_NAME: "" };
  it("plans all migrations without a database connection or credentials", () => {
    const result = JSON.parse(execFileSync(process.execPath, ["scripts/init-database.mjs", "--plan"], { encoding: "utf8", env }));
    expect(result.mode).toBe("plan");
    expect(result.schemaTables).toBe(121);
    expect(result.migrations).toHaveLength(20);
    expect(result.migrations.at(-1).file).toMatch(/0052_local_staff_auth/);
    expect(result.migrations.every((item: any) => /^[a-f0-9]{64}$/.test(item.sha256))).toBe(true);
  });
  it("removes Drizzle delimiters before MySQL execution while preserving ordinary comments", () => {
    const script = `import { executableMigrationSql } from './scripts/migration-sql.mjs';
      process.stdout.write(executableMigrationSql('-- ordinary comment\\nCREATE TABLE a (id int);--> statement-breakpoint\\nALTER TABLE a ADD name text;'));`;
    const sql = execFileSync(process.execPath, ["--input-type=module", "-e", script], { encoding: "utf8", env });
    expect(sql).not.toContain("--> statement-breakpoint");
    expect(sql).toContain("-- ordinary comment");
    expect(sql).toContain("ALTER TABLE a ADD name text;");
  });
  it("refuses application when the explicit database name does not match, without leaking credentials", () => {
    const result = spawnSync(process.execPath, ["scripts/init-database.mjs", "--apply"], { encoding: "utf8", env: { ...env, DATABASE_URL: "mysql://owner:test-secret@127.0.0.1/membership", ERP_DATABASE_NAME: "erp_test" } });
    expect(result.status).toBe(1);
    expect(result.stderr).toContain("ERP_DATABASE_NAME");
    expect(result.stderr + result.stdout).not.toContain("test-secret");
  });
  it("rejects unknown flags and the previous automatic schema command", () => {
    expect(spawnSync(process.execPath, ["scripts/init-database.mjs", "--force"], { env }).status).toBe(1);
    const old = spawnSync(process.execPath, ["scripts/disabled-db-push.mjs"], { encoding: "utf8", env });
    expect(old.status).toBe(1);
    expect(old.stderr).toContain("disabled");
  });
});
