console.error("Automatic schema generation is disabled. Review db:init --plan and DATABASE_INIT.md first.");
process.exitCode = 1;
