import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import mysql from 'mysql2/promise';
import 'dotenv/config';
import { executableMigrationSql } from './migration-sql.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = [
  'drizzle/0000_romantic_clea.sql',
  'drizzle/0001_initial_formal_schema.sql',
  'drizzle/0002_tidb_text_defaults.sql',
  'drizzle/0003_tidb_reply_rule_channels.sql',
  'drizzle/0037_seed_default_sales_units.sql',
  'drizzle/0038_align_sales_units_and_mall_display.sql',
  'drizzle/0039_virtual_delivery.sql',
  'drizzle/0040_inventory_movement_ledger.sql',
  'drizzle/0041_fifo_inventory_lots.sql',
  'drizzle/0042_notification_log_system_channel.sql',
  'drizzle/0043_refund_special_action_link.sql',
  'drizzle/0044_waiting_restock_variant_allocation.sql',
  'drizzle/0045_waiting_restock_partial_allocation.sql',
  'drizzle/0046_refund_number_sequence.sql',
  'drizzle/0047_packing_shipping_release_actions.sql',
  'drizzle/0048_order_care_packs.sql',
  'drizzle/0049_import_order_prefix_xtd.sql',
  'drizzle/migrations/0050_controlled_shipping_config.sql',
  'drizzle/migrations/0051_virtual_delivery_material_kit.sql',
  'drizzle/migrations/0052_local_staff_auth.sql',
];

async function main() {
  const args = process.argv.slice(2);
  if (args.some(arg => !['--plan', '--apply'].includes(arg)) || args.length > 1) throw new Error('Use --plan or --apply');
  const plan = await Promise.all(files.map(async file => {
    const sql = await readFile(path.join(root, file), 'utf8');
    if (!sql.trim()) throw new Error(`Empty migration: ${file}`);
    return { file, sql, hash: createHash('sha256').update(sql).digest('hex') };
  }));
  const schema = await readFile(path.join(root, 'drizzle/schema.ts'), 'utf8');
  const expected = [...schema.matchAll(/mysqlTable\("([^"]+)"/g)].map(match => match[1]);
  const definitions = new Set(plan.flatMap(item => [...item.sql.matchAll(/CREATE TABLE(?: IF NOT EXISTS)?\s+`([^`]+)`/gi)].map(match => match[1])));
  const missing = expected.filter(name => !definitions.has(name));
  if (missing.length) throw new Error(`Missing CREATE definitions: ${missing.join(', ')}`);
  console.log(JSON.stringify({ mode: args[0] === '--apply' ? 'apply' : 'plan', schemaTables: expected.length, migrations: plan.map(({ file, hash }) => ({ file, sha256: hash })) }, null, 2));
  if (args[0] !== '--apply') return;

  const url = new URL(process.env.DATABASE_URL || '');
  const database = decodeURIComponent(url.pathname.slice(1));
  if (url.protocol !== 'mysql:' || !database || process.env.ERP_DATABASE_NAME !== database) {
    throw new Error('DATABASE_URL must be mysql:// and ERP_DATABASE_NAME must exactly match its dedicated ERP database');
  }
  if (url.search || url.hash) throw new Error('Use explicit connection settings; URL query/hash options are not accepted by this initializer');
  let connection;
  try {
    connection = await mysql.createConnection({ host: url.hostname, port: Number(url.port || 3306), user: decodeURIComponent(url.username), password: decodeURIComponent(url.password), database, multipleStatements: true, charset: 'utf8mb4', connectTimeout: 10000 });
    const [tables] = await connection.query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?', [database]);
    if (tables.length) throw new Error('Target database is not empty. No migrations were applied. Use a new dedicated empty ERP database; do not delete existing tables.');
    await connection.query('CREATE TABLE `_erp_init_log` (`file` varchar(255) PRIMARY KEY, `sha256` char(64) NOT NULL, `status` varchar(16) NOT NULL, `updatedAt` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)');
    for (const item of plan) {
      await connection.execute('INSERT INTO `_erp_init_log` (`file`, `sha256`, `status`) VALUES (?, ?, ?)', [item.file, item.hash, 'running']);
      try {
        await connection.query(executableMigrationSql(item.sql));
        await connection.execute('UPDATE `_erp_init_log` SET `status` = ? WHERE `file` = ?', ['applied', item.file]);
        console.log(`Applied: ${item.file}`);
      } catch (error) {
        await connection.execute('UPDATE `_erp_init_log` SET `status` = ? WHERE `file` = ?', ['failed', item.file]);
        throw new Error(`Stopped at ${item.file} (${error.code || 'SQL_ERROR'}). DDL may already be committed; no automatic rollback or resume. Inspect the dedicated test database before proceeding.`);
      }
    }
    const [actual] = await connection.query('SELECT TABLE_NAME AS name FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?', [database]);
    const actualNames = new Set(actual.map(row => row.name));
    if (expected.some(name => !actualNames.has(name))) throw new Error('Post-initialization table check failed');
    console.log(`Initialized ${expected.length} ERP tables plus migration log. Column/index equivalence and business flows still require validation.`);
  } finally { if (connection) await connection.end(); }
}

main().catch(error => {
  // Print controlled messages only; never echo connection errors containing credentials.
  const controlled = /^(Use |Empty migration|Missing CREATE|DATABASE_URL|Target database|Stopped at|Post-initialization|Use explicit)/.test(error.message || '');
  console.error(controlled ? error.message : 'Database initialization failed. Check the configuration and database availability; credentials are not printed.');
  process.exitCode = 1;
});
