// Drizzle's statement delimiter is metadata, not a valid MySQL SQL comment.
// Preserve ordinary SQL and source bytes used for migration audit hashes.
export function executableMigrationSql(sql) {
  return sql.replace(/^--> statement-breakpoint[ \t]*(?:\r?\n|$)/gm, '')
    .replace(/--> statement-breakpoint(?=\s*(?:ALTER|CREATE|INSERT|UPDATE|DELETE|DROP|$))/g, '');
}
