import 'dotenv/config';
import { readFile } from 'node:fs/promises';
import mysql from 'mysql2/promise';
import { is, Table } from 'drizzle-orm';
import { getTableConfig } from 'drizzle-orm/mysql-core';
import * as schema from '../drizzle/schema';
import { compareDatabaseColumns, type AuditColumn } from '../server/databaseSchemaAudit';

async function main() {
  const args = process.argv.slice(2);
  if (!(args.length === 1 && args[0] === '--live') && !(args.length === 2 && args[0] === '--columns')) throw Error('Use --live or --columns /absolute/path/to/columns.tsv');
  const tables = Object.values(schema).filter(value => is(value, Table)).map(table => getTableConfig(table as any));
  const expected: AuditColumn[] = tables.flatMap(table => table.columns.map(column => ({ table: table.name, name: column.name, type: column.getSQLType(), notNull: column.notNull, primary: column.primary, autoIncrement: Boolean((column as any).autoIncrement) })));
  let rows: string[][];
  if (args[0] === '--columns') {
    const input = await readFile(args[1], 'utf8');
    rows = input.replace(/\r?\n$/, '').split('\n').map(line => line.replace(/\r$/, '').split('\t'));
  } else {
    const url = new URL(process.env.DATABASE_URL || '');
    const database = decodeURIComponent(url.pathname.slice(1));
    if (url.protocol !== 'mysql:' || !database || database !== process.env.ERP_DATABASE_NAME || url.search || url.hash) throw Error('Dedicated ERP database configuration required');
    const connection = await mysql.createConnection({ host: url.hostname, port: Number(url.port || 3306), user: decodeURIComponent(url.username), password: decodeURIComponent(url.password), database, connectTimeout: 10000 });
    try {
      const [result] = await connection.execute<mysql.RowDataPacket[]>('SELECT TABLE_NAME,COLUMN_NAME,COLUMN_TYPE,IS_NULLABLE,COLUMN_KEY,EXTRA FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME <> ?', [database, '_erp_init_log']);
      rows = result.map(row => [row.TABLE_NAME,row.COLUMN_NAME,row.COLUMN_TYPE,row.IS_NULLABLE,row.COLUMN_KEY,row.EXTRA]);
    } finally { await connection.end(); }
  }
  if (rows.some(row => row.length !== 6)) throw Error('Invalid columns metadata');
  const actual: AuditColumn[] = rows.map(([table,name,type,nullable,key,extra]) => ({ table,name,type,notNull: nullable === 'NO',primary: key === 'PRI',autoIncrement: extra.includes('auto_increment') }));
  const differences = compareDatabaseColumns(expected, actual);
  console.log(JSON.stringify({ tables: tables.length, expectedColumns: expected.length, actualColumns: actual.length, differences, scope: 'Names, SQL types, nullability, primary keys and auto-increment only; defaults, indexes, foreign keys and business flows are not verified.' }, null, 2));
  if (differences.length) process.exitCode = 1;
}
main().catch(() => { console.error('Schema audit failed: check arguments, metadata or dedicated database configuration. Credentials are not printed.'); process.exitCode = 1; });
