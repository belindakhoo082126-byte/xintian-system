# ERP independence baseline — 2026-10-16

## Source

- Repository: belindakhoo082126-byte/xintian-order-system
- Repository HEAD at download: a57e90cb7d7c318c8bc33b5f8ebe439e2f178535
- Source: xintian-system-version2-f7dc9de-source.zip (version label supplied by the archive; not an independently verified Git commit).
- Archive SHA256: f916e6c545793eea58faabebb82e6f370861acf0376fc1bdb9a35666a2403ef8
- Local branch: codex/erp-independent. No remote push or deployment performed.
- Source business logic has not been changed for this baseline.

## Reproduction and results

Environment: Node 24.19.0, Corepack pnpm 10.4.1. The handover recommends Node 22 LTS; deployment must also be checked on its selected runtime.

| Command | Result |
| --- | --- |
| `corepack pnpm install --frozen-lockfile --ignore-scripts` | Passed, 793 packages installed; dependency lifecycle scripts were not run. |
| `corepack pnpm check` | Passed, TypeScript reported no errors. |
| `corepack pnpm test` | 89 files: 88 passed, 1 failed. 222 tests: 221 passed, 1 failed. |
| `corepack pnpm build` | Passed. Existing large frontend chunk warning; backend bundle generated. |

The failed test is `server/carePackPdf.test.ts`: it reads `/usr/share/fonts/opentype/noto/NotoSansCJKsc-Light.otf`, which does not exist in this environment. This is a missing environment asset, not a verified PDF business-logic failure. Do not skip the test or claim a fully passing suite. The production PDF module also references a font at `/manus-storage/NotoSansCJKsc-Light_85634da1.otf`; replacing font delivery is part of removing Manus.

## Database findings

- `drizzle/schema.ts` declares 119 tables.
- There are 17 top-level SQL files plus 2 in `drizzle/migrations`.
- Two journal entries lack `tag`; do not run the existing `db:push` script blindly.
- `shipping_config_values` is defined in `drizzle/migrations/0050_controlled_shipping_config.sql`, not the top-level migration directory.
- The handover explicitly documents manual migration ordering and an incomplete historical journal. Use that documented ordering as input to a reviewed initialization process.
- No MySQL server or Docker CLI was available during this check. Empty-database migration execution, schema equivalence, seed data and transaction behavior remain unverified.

## Integration findings

- Facebook webhook code exists in `server/facebook.ts`, but the main server does not register it. Credentials alone do not enable it.
- Authentication, file storage, AI adapters, frontend session fallback and development tooling still reference Manus.
- Existing tests are a regression baseline, not evidence that Facebook, ParcelDaily, membership, Telegram or image-generation integrations work end to end.
- No external credentials, production database, live webhook subscription, shipment purchase or customer messaging was used.

## Ownership and next work

ERP owner: authentication, private/public file access, Manus removal, ERP frontend changes, import-order disabling, database initialization and ERP integration endpoints.

MasterD: existing Telegram/membership/image system interface documentation and implementation on those systems, hosting configuration and service-account setup. Avoid simultaneous edits to ERP authentication, schema and frontend until file ownership is agreed.

Next implementation slice: independent staff authentication and local file storage, with authorization tests and a portable Chinese PDF font. Then remove Manus runtime and optional service fallbacks. Keep original archive intact and preserve database compatibility while disabling new import orders.
